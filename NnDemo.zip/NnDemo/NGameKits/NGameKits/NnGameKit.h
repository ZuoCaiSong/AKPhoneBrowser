
@interface NnGameKit : NSObject

//获取实例
+(NnGameKit *)GetInstance;

/****************************************************
 *  函数名:  Init
 *  功  能:
 *  入  参:
 *			(NSString *)    strAppId    分配的参数appid
 *			(NSString *)    strAppkey   分配的参数appkey
 *  出  参:
 *  		无
 *  说  明:  初始化；必须对接
 ****************************************************/
- (void)Init:(NSString *)strAppId Appkey:(NSString *)strAppkey;

/****************************************************
 *  函数名:  printVersion
 *  功  能:  打印当前版本号
 *  入  参:
 *			无
 *  出  参:
 *  		无
 *  说  明:  用于查看当前版本号
 ****************************************************/
-(void)printVersion;

/****************************************************
 *  函数名:  login
 *  功  能:  登陆
 *  入  参:
 *			无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)login;


/****************************************************
 *  函数名:  AppleIap
 *  功  能:  
 *  入  参:
 *			 (NSString *) strExtraInfo    游戏方自定义内容
 *           (NSInteger)  ijin               花费
 *			 (NSInteger)  iServerID 	  玩家登录的服务器的id，服务器id确保选择发元宝时，服务器核实的那个id，避免合服后，出现问题
             (NSString *) strServerName   玩家登录的区服名称
 *           (NSString *) strRoleName     玩家角色名字
             (NSString *) strRoleID       游戏角色id
 *           (NSString *) strProductId
             (NSString *) strProductName
             (NSString *) strProductDes
 *  出  参:
 *  		无
 *  说  明: 
 ****************************************************/
-(void)AppleIap:(NSString *)strExtraInfo jin:(NSInteger)iJin serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleName:(NSString *)strRoleName roleID:(NSString*)strRoleID productId:(NSString *)strProductId productName:(NSString *)strProductName productDes:(NSString *)strProductDes;

/****************************************************
 *  函数名:  submitServerID
 *  功  能:  登陆游戏日志记录,在玩家选择服务器之后调用此接口
 *  入  参:
 *			 (NSInteger)  iServerID            服务器iD
 *  出  参:
 *  		无
 *  说  明: 必须对接
 ****************************************************/
- (void)submitServerID:(NSInteger)iServerID;

/****************************************************
 *  函数名:  submitExtendData
 *  功  能:  数据上报统计
 *  入  参:
 *			 (NSString *) strDataType          统计类型
 *			 (NSString *)  strRoleName 		   角色名字
 *			 (NSInteger)  iServerID            服务器iD
 *           (NSString *) strServerName        服务器名字
 *			 (NSString *)  strRoleLevel 	   角色等级
 *           (NSString *) strUserID            分配的用户id，登陆成功后可以获取到
 *			 (NSString *)  strRoleID 		   游戏角色id
 *           (NSString *) strJinNum            当前角色身上拥有的游戏币数量
 *  出  参:
 *  		无
 *  说  明: 有些参数可能不能立即获取到，请选择适当时机调用即可；必须对接
 ****************************************************/
- (void)submitExtendData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum;


//绑定手机号
-(void)bindPhone;

/****************************************************
 *  函数名:  logout
 *  功  能:  注销
 *  入  参:
 *			无
 *  出  参:
 *  		无
 *  说  明:  如贵方游戏里有“注销账号”等退出游戏的按钮，请调用此接口
 ****************************************************/
-(void)logout;

/****************************************************
 *  函数名:  isBindPhone
 *  功  能:  是否绑定手机
 *  入  参:
 *			无
 *  出  参:
 *  		无
 *  说  明:  如贵方游戏需要判断是否绑定手机，请在登录成功之后调用此接口
 ****************************************************/
-(BOOL)isBindPhone;

-(BOOL)handleResult:(NSURL*)url;

-(void)becomActiveToHandle;

- (UIInterfaceOrientationMask)gameSupportedInterfaceOrientationsForWindow:(UIInterfaceOrientationMask)direction;

@end
