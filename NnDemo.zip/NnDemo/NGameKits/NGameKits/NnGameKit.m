#import "NnGameKit.h"
#import "NnnbIAPManager.h"
#import "NnnbLoadingHUD.h"
#import "NnnbUpdate.h"

static NnGameKit *_twKitInstance = nil;

@interface NnGameKit ()

@end

@implementation NnGameKit

+(NnGameKit *)GetInstance
{
    @synchronized(self)
    {
        if (_twKitInstance == nil) {
            _twKitInstance = [[NnGameKit alloc] init];
        }
    }
    
    return _twKitInstance;
}

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    
    return self;
}

#pragma mark - 初始化
- (void)Init:(NSString *)strAppId Appkey:(NSString *)strAppkey
{
    if (strAppId == nil || [strAppId isEqualToString:@""])
    {
        [NnnbTips depictCenterWithText:@"初始化异常，APPId为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (strAppkey == nil || [strAppkey isEqualToString:@""])
    {
        [NnnbTips depictCenterWithText:@"初始化异常，APPKey为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    [DataManger getInstance].systemInfo.strAppId = strAppId;
    [DataManger getInstance].systemInfo.strAppKey = strAppkey;
    
    //安装激活
    [[NnnbFacade getInstance] nnInstallActive];
    
    [[NnnbFacadeCenter defaultFacade] getConfig:^(BOOL success, NSNotification *notifi) {
        if (success)
        {
            NSDictionary *configDict = notifi.userInfo;
            
            NSInteger flag = [configDict[@"updateflag"] integerValue];
            [[NnnbUpdate getInstance] updateAppWithFlag:flag url:configDict[@"url"]];
            
            [CommonData GetCommonDataInstance].cusDict = [NSDictionary dictionaryWithDictionary:configDict[@"kf_info"]];
            
            BOOL bHadLogin = [CommonData GetCommonDataInstance].bHadLogin;
            NSDictionary *dataDic = [configDict objectForKey:@"config"];
            
            if (!bHadLogin && (dataDic != nil) && ([NnnbCommons isNSDictionaryObject:dataDic]) && dataDic[@"sPac"])
            {
                [CommonData GetCommonDataInstance].packageState = [dataDic[@"sPac"] integerValue];
            }
            else
            {
                [CommonData GetCommonDataInstance].packageState = -1;
            }
            
            if (!bHadLogin && (dataDic != nil) && ([NnnbCommons isNSDictionaryObject:dataDic]) && dataDic[@"sPub"])
            {
                [CommonData GetCommonDataInstance].sPub = [dataDic[@"sPub"] integerValue];
            }
            else
            {
                [CommonData GetCommonDataInstance].sPub = -1;
            }
            
            if (!bHadLogin && (dataDic != nil) && ([NnnbCommons isNSDictionaryObject:dataDic]) && dataDic[@"UIType"])
            {
                [CommonData GetCommonDataInstance].sVersion = [dataDic[@"UIType"] integerValue];
            }
            else
            {
                [CommonData GetCommonDataInstance].sVersion = -1;
            }
            [CommonData GetCommonDataInstance].sVersion = -1;
            
            if (!bHadLogin && (dataDic != nil) && ([NnnbCommons isNSDictionaryObject:dataDic]) && dataDic[@"sCus"])
            {
                [CommonData GetCommonDataInstance].sCur = [dataDic[@"sCus"] integerValue];
            }
            else
            {
                [CommonData GetCommonDataInstance].sCur = -1;
            }
            
            if (!bHadLogin && (dataDic != nil) && ([NnnbCommons isNSDictionaryObject:dataDic]) && dataDic[@"sRec"])
            {
                [CommonData GetCommonDataInstance].sRecr = [dataDic[@"sRec"] integerValue];
            }
            else
            {
                [CommonData GetCommonDataInstance].sRecr = -1;
            }
        }
        else
        {
            [CommonData GetCommonDataInstance].packageState = -1;
            [CommonData GetCommonDataInstance].sVersion = -1;
            [CommonData GetCommonDataInstance].sCur = -1;
            [CommonData GetCommonDataInstance].sRecr = -1;
        }
    }];
    
    NSLog(@"当前版本:%@",NN_CURRENT_VERSION);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_INIT_SUCCESS
                                                        object:nil];
}

#pragma mark - 登录
-(void)login
{
    if([NnnbCommons isFastDoubleClickInSecond:0.5 TagStr:@"login"])
    {
        return;
    }
    
    [CommonData GetCommonDataInstance].bHadLogin = YES;
    
    if ([CommonData GetCommonDataInstance].sVersion == 1)
    {
        [MainWindow addSubview:[NnnbSFloatW getInstance].loginViewController.view];
    }
    else
    {
        [MainWindow addSubview:[NnnbFloatWindow getInstance].loginViewController.view];
    }
}

-(void)AppleIap:(NSString *)strExtraInfo jin:(NSInteger)iJin serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleName:(NSString *)strRoleName roleID:(NSString*)strRoleID productId:(NSString *)strProductId productName:(NSString *)strProductName productDes:(NSString *)strProductDes
{
    if([NnnbCommons isFastDoubleClickInSecond:1.0 TagStr:@"DoubleClick"]){
        return;
    }
    
    if (strExtraInfo == nil || [strExtraInfo  isEqual: @""]) {
        [NnnbTips depictCenterWithText:@"出现异常，ext为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (iServerID == 0) {
        [NnnbTips depictCenterWithText:@"出现异常，服务器id为0" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (strServerName == nil || [strServerName isEqual:@""]){
        [NnnbTips depictCenterWithText:@"出现异常，服务器名字为空" duration:NN_TIPS_TIME2];
        
        return;
    }
        
    
    if (iJin <= 0) {
        [NnnbTips depictCenterWithText:@"出现异常，iJin为0" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (strProductId == nil || [strProductId isEqual:@""]){
        [NnnbTips depictCenterWithText:@"出现异常，Id为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (strProductName == nil || [strProductName isEqual:@""]){
        [NnnbTips depictCenterWithText:@"出现异常，名为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (strRoleName == nil || [strRoleName isEqual:@""]){
        [NnnbTips depictCenterWithText:@"出现异常，角色名为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([CommonData GetCommonDataInstance].bIsBuying == YES) {
        [NnnbLoadingHUD depictLoading:@"请稍候"];
        
        [NSTimer scheduledTimerWithTimeInterval:1.5f target:self selector:@selector(dismissKeyHUD) userInfo:nil repeats:NO];
        
        return;
    }
    
    if ([CommonData GetCommonDataInstance].sVersion == 1) {
        [[NnnbSFloatW getInstance] removeWindow];
    }else{
        [[NnnbFloatWindow getInstance] removeWindow];
    }
    
    [CommonData GetCommonDataInstance].bIsBuying = YES;
    
    [[CommonData GetCommonDataInstance] saveExt:strExtraInfo jin:iJin serverID:iServerID serverName:strServerName roleName:strRoleName roleID:strRoleID productID:strProductId productName:strProductName productDes:strProductDes];
    
    [[NnnbFacadeCenter defaultFacade] getVersionRequest:^(BOOL success, NSNotification *notifi) {
        if (success) {
            [self swiResultHandler:notifi];
        }
        else {
            [self swiErrorHandler:notifi];
        }
    }];
}

- (void)dismissKeyHUD{
    [NnnbLoadingHUD removeInKeyWindow];
}

-(void)swiResultHandler:(NSNotification*)notif{
    NSDictionary *dict = nil;
    if((notif != nil) &&([NnnbCommons isNSNotificationObject:notif])){
        dict = notif.userInfo;
    }
    
    CommonData *commonData = [CommonData GetCommonDataInstance];

    if ((dict != nil) && [NnnbCommons isNSDictionaryObject:dict] && [dict objectForKey:@"zt"] && ([[dict objectForKey:@"zt"] integerValue] == 1)) {
        commonData.bIsBuying = NO;
        commonData.pmdStr = dict[@"title"];

        commonData.iSAppleRecharge = [[dict objectForKey:@"pgCz"] integerValue];

        if ([CommonData GetCommonDataInstance].sVersion == 1) {
            [MainWindow addSubview:[NnnbSFloatW getInstance].topUpCenterController.view];
        }else{
            [MainWindow addSubview:[NnnbFloatWindow getInstance].topUpCenterController.view];
        }
    } else {
        [[NnnbIAPManager sharedManager] makeIAP];
    }
}

-(void)swiErrorHandler:(NSNotification*)notif
{
    NSString* errorString = [notif.userInfo objectForKey:KEY_ERROR_TEXT];
    [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
    
    if ([CommonData GetCommonDataInstance].sVersion == 1) {
        [[NnnbSFloatW getInstance] depictWindow];
    }else{
        [[NnnbFloatWindow getInstance] depictWindow];
    }
    
    [CommonData GetCommonDataInstance].bIsBuying = NO;
}

#pragma mark - 登录游戏日志记录
- (void)submitServerID:(NSInteger)iServerID
{
    [[NnnbFacade getInstance] collectGameData:iServerID];
}

#pragma mark - 创建角色
- (void)submitExtendData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum
{
    [[NnnbFacade getInstance] submitExtendData:strDataType roleName:strRoleName serverID:iServerID serverName:strServerName roleLevel:strRoleLevel userID:strUserID roleID:strRoleID jinNum:strJinNum];
}

-(void)printVersion{
    NSString *str = @"当前版本:";
    NSString *currentVersion = [NSString stringWithFormat:@"%@%@",str,NN_CURRENT_VERSION];
    
    // 打印版本日志
    NSLog(@"%@",currentVersion);
}

#pragma mark - 绑定手机
-(void)bindPhone{
    if ([DataManger getInstance].currentUserInfo.isBind) {
        [NnnbTips depictCenterWithText:@"此账号已经绑定手机" duration:NN_TIPS_TIME2];
    } else {
        if ([CommonData GetCommonDataInstance].sVersion == 1) {
            NnnbSBindPhoneCtrl* sBindPhoneController = [[NnnbSFloatW getInstance] bindPhoneController];
            sBindPhoneController.closeBtnRemove = NO;
            [MainWindow addSubview:sBindPhoneController.view];
        }else{
            NnnbBindPhoneViewController* bindPhoneController = [[NnnbFloatWindow getInstance] bindPhoneController];
            bindPhoneController.closeBtnRemove = NO;
            [MainWindow addSubview:bindPhoneController.view];
        }
    }
}

-(void)twisdepictFloat:(BOOL)bS{
    if ([CommonData GetCommonDataInstance].sVersion == 1) {
        [[NnnbSFloatW getInstance] setIsdepictFloat:bS];
    }else{
        [[NnnbFloatWindow getInstance] setIsdepictFloat:bS];
    }
}

#pragma mark - 注销
-(void)logout{
    if([NnnbCommons isFastDoubleClickInSecond:0.5 TagStr:@"logout"])
    {
        return;
    }
    
    if ([CommonData GetCommonDataInstance].sVersion == 1) {
        [[NnnbSFloatW getInstance] removeWindow];
    }else{
        [[NnnbFloatWindow getInstance] removeWindow];
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_LOGOUT_SUCCESS
                                                        object:nil];
}

#pragma mark - 是否绑定手机
-(BOOL)isBindPhone{
    return [DataManger getInstance].currentUserInfo.isBind;
}

-(BOOL)handleResult:(NSURL*)url
{
    NSRange testRange = [url.host rangeOfString:@"a70_"];
    if (testRange.length < 1) {
        return NO;
    }
    
    NSString * strStateFlag = @"0";
    NSRange flagRange = [url.host rangeOfString:@"a70_1"];
    if (flagRange.length > 0) {
        strStateFlag = @"1";
    }
    
    NSDictionary *flagD = [NSDictionary dictionaryWithObject:strStateFlag forKey:@"stateFlag"];
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_APPLE
                                                        object:self userInfo:flagD];
    
    return YES;
}

-(void)becomActiveToHandle
{
    NSString *succReturn = [NSString stringWithFormat:@"chSuccReturn%@", [DataManger getInstance].systemInfo.strAppId];
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    bool chSuccFlag = [userDef boolForKey:succReturn];
    if (chSuccFlag) {
        [userDef setBool:NO forKey:succReturn];
        [userDef synchronize];
        return;
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_BECOMEACTIVE_HANDLE
                                                        object:self userInfo:nil];
}

- (UIInterfaceOrientationMask)gameSupportedInterfaceOrientationsForWindow:(UIInterfaceOrientationMask)direction
{
    NSInteger directionResult = [CommonData GetCommonDataInstance].currentDirection;
    
    if (directionResult == 1) {
        return UIInterfaceOrientationMaskPortrait;
    }else{
        return direction;
    }
}

@end
