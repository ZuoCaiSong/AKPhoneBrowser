//
//  NnnbSRegisterV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"
#import "NnnbTextField.h"

@protocol NnnbSRegisterVDelegate <NSObject>

-(void)backToLastView:(NSString *)account andPsw:(NSString *)psw;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

-(void)backToAccountLoginView;

-(void)presentPhoneLoginView;

@end

@interface NnnbSRegisterV : NnnbSSuperV<UITextFieldDelegate>
@property (nonatomic,weak) id<NnnbSRegisterVDelegate> delegate;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *psw;
@end
