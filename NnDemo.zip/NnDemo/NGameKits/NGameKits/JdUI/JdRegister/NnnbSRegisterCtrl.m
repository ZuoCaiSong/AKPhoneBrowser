//
//  NnnbSRegisterCtrl.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSRegisterCtrl.h"
#import "NnnbSFgPassWordViewCtrl.h"

@interface NnnbSRegisterCtrl ()

@end

@implementation NnnbSRegisterCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    [[NnnbSFloatW getInstance] removeWindow];
    
    [self depictLoginView];
}

- (void)depictLoginView{
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"账号注册" font:[UIFont systemFontOfSize:20]];
    UILabel *title  = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width - titleWidth)/2, 2.5, titleWidth, 40)];
    title.text = @"账号注册";
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    _registerView = [[NnnbSRegisterV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _registerView.delegate = self;
    [self.bgView addSubview:_registerView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)backToLastView:(NSString *)account andPsw:(NSString *)psw{
    [self popView];
    [self.delegate registerSuccessWithAccount:account andPsw:psw];
}

- (void)backToAccountLoginView{
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (void)presentPhoneLoginView{
    [self dismissViewControllerAnimated:NO completion:nil];
    
    if (_delegate && [_delegate respondsToSelector:@selector(registerVCPresentPhoneLoginVC)]) {
        [self.delegate registerVCPresentPhoneLoginVC];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
