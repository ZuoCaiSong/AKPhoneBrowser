//
//  NnnbSRegisterV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSRegisterV.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbLabelSizeToFit.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 10

#define BottomBtnTag 100

#define UPDATA_COUNT 40

#define FIELDBgHeight 40

@interface NnnbSRegisterV ()
@property (nonatomic,strong) UIImageView *accFieldBgIv;
@property (nonatomic,strong) UIImageView *pwdFieldBgIv;
@property (nonatomic,assign) NSInteger direction;
@property (nonatomic,strong) UIImage *img;
@property (nonatomic,strong) UIButton *eyeBtn;
@property (nonatomic,strong) NnnbTextField *accountField;
@property (nonatomic,strong) NnnbTextField *pswField;
@property (nonatomic,strong) UIButton *registerBtn;
@end

@implementation NnnbSRegisterV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
        [self getAccountAndPsw];
    }
    return self;
}

#pragma mark - 初始化界面
- (void)initView{
    _direction = [[CommonData GetCommonDataInstance] judgeDirection];
    
    _img = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    _img = [_img stretchableImageWithLeftCapWidth:_img.size.width/2 topCapHeight:_img.size.height/2];
    
    _accFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _accFieldBgIv.userInteractionEnabled = YES;
    _accFieldBgIv.image = _img;
    [self addSubview:_accFieldBgIv];
    
    CGFloat fieldWidth = _accFieldBgIv.width;
    CGFloat fieldHeight = _accFieldBgIv.height;
    
    //账号------------------------------------------
    UIImageView *accountleftView = [[UIImageView alloc]init];
    accountleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    accountleftView.image = [UIImage nnGetPlatImage:@"TygUser.png"];
    [_accFieldBgIv addSubview:accountleftView];
    
    //账号
    if (!_accountField) {
        _accountField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _accountField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight -(2*fieldHeight/3+15), fieldHeight-1);
    }
    _accountField.layer.cornerRadius = 6.0f;
    _accountField.borderStyle = UITextBorderStyleNone;
    _accountField.adjustsFontSizeToFitWidth = YES;
    _accountField.delegate = self;
    _accountField.placeholder = @"请输入账号";
    _accountField.font = [UIFont systemFontOfSize:15];
    _accountField.returnKeyType = UIReturnKeyNext;
    _accountField.keyboardType = UIKeyboardTypeASCIICapable;
    [_accFieldBgIv addSubview:_accountField];
    
    UIButton *refreshBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    refreshBtn.frame = CGRectMake(fieldWidth - (2*fieldHeight/3+15), fieldHeight/6, 2*fieldHeight/3, 2*fieldHeight/3);
    [refreshBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygRefresh.png"] forState:UIControlStateNormal];
    [refreshBtn addTarget:self action:@selector(refreshBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_accFieldBgIv addSubview:refreshBtn];
    
    //密码--------------------------------------------------------
    _pwdFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _accFieldBgIv.tp_bottom+offTop_x_height, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _pwdFieldBgIv.userInteractionEnabled = YES;
    _pwdFieldBgIv.image = _img;
    [self addSubview:_pwdFieldBgIv];
    UIImageView *pswleftView = [[UIImageView alloc]init];
    pswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    pswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_pwdFieldBgIv addSubview:pswleftView];
    
    if (!_pswField) {
        _pswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _pswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight -(2*fieldHeight/3+15), fieldHeight-1);
    }
    _pswField.layer.cornerRadius = 6.0f;
    _pswField.borderStyle = UITextBorderStyleNone;
    _pswField.adjustsFontSizeToFitWidth = YES;
    _pswField.delegate = self;
    _pswField.placeholder = @"请输入密码";
    _pswField.font = [UIFont systemFontOfSize:15];
    _pswField.returnKeyType = UIReturnKeyDone;
    _pswField.keyboardType = UIKeyboardTypeASCIICapable;
    [_pwdFieldBgIv addSubview:_pswField];
    
    _eyeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _eyeBtn.frame = CGRectMake(fieldWidth - (2*fieldHeight/3+15), fieldHeight/6, 2*fieldHeight/3, 2*fieldHeight/3);
    [_eyeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygEyeO.png"] forState:UIControlStateNormal];
    [_eyeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygEyeC.png"] forState:UIControlStateSelected];
    [_eyeBtn addTarget:self action:@selector(eyeBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_pwdFieldBgIv addSubview:_eyeBtn];
    
    UIImageView *tipImg = [[UIImageView alloc] initWithFrame:CGRectMake(_pwdFieldBgIv.left+5, _pwdFieldBgIv.tp_bottom+offTop_x_height+5, _pwdFieldBgIv.height-25, _pwdFieldBgIv.height-25)];
    tipImg.image = [UIImage nnGetPlatImage:@"TygTips.png"];
    [self addSubview:tipImg];
    
    CGFloat tipLabWidth = [NnnbLabelSizeToFit getWidthWithtext:@"账号和密码可手动修改" font:[UIFont systemFontOfSize:15]];
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake(tipImg.tp_right+5, tipImg.top, tipLabWidth, tipImg.height)];
    tipLab.text = @"账号和密码可手动修改";
    tipLab.textColor = [UIColor lightGrayColor];
    tipLab.font = [UIFont systemFontOfSize:15];
    [self addSubview:tipLab];
    
    //注册按钮
    _registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _registerBtn.frame = CGRectMake(_pwdFieldBgIv.left, tipImg.tp_bottom+ offTop_x_height+5, fieldWidth, FIELDBgHeight);
    UIImage *img2 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img2 = [img2 stretchableImageWithLeftCapWidth:img2.size.width/2 topCapHeight:img2.size.height/2];
    [_registerBtn setBackgroundImage:img2 forState:UIControlStateNormal];
    [_registerBtn setTitle:@"一键注册" forState:UIControlStateNormal];
    _registerBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [_registerBtn addTarget:self action:@selector(registerClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_registerBtn];
    
    NSArray *titleArr = @[@"手机号登录", @"已有账号"];
    
    for (int i = 0; i < titleArr.count; i++) {
        UIButton *bottomBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        bottomBtn.frame = CGRectMake(_registerBtn.left+(i%2)*(_registerBtn.width-120), _registerBtn.tp_bottom+5, 120, _registerBtn.height);
        [bottomBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [bottomBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
        bottomBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
        [bottomBtn addTarget:self action:@selector(bottomBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        bottomBtn.tag = BottomBtnTag +i;
        [bottomBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygLightGray.png"] forState:UIControlStateHighlighted];
        [self addSubview:bottomBtn];
    }
}

- (void)bottomBtnClick:(UIButton *)button
{
    if (button.tag == BottomBtnTag)
    {
        if (_delegate && [_delegate respondsToSelector:@selector(presentPhoneLoginView)]) {
            [_delegate presentPhoneLoginView];
        }
    }
    else
    {
        if (_delegate && [_delegate respondsToSelector:@selector(backToAccountLoginView)]) {
            [_delegate backToAccountLoginView];
        }
    }
}

- (void)refreshBtnClick
{
    [_accountField resignFirstResponder];
    [_pswField resignFirstResponder];
    
    _eyeBtn.selected = NO;
    _pswField.secureTextEntry = NO;
    
    [self getAccountAndPsw];
}

- (void)eyeBtnClick
{
    if (_eyeBtn.selected == YES) {
        _eyeBtn.selected = NO;
        _pswField.secureTextEntry = NO;
    } else {
        _eyeBtn.selected = YES;
        _pswField.secureTextEntry = YES;
    }
}

#pragma mark - 请求随机账号
- (void)getAccountAndPsw
{
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] getRegistAccount:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            NSString *userName = [notifi.userInfo objectForKey:@"uname"];
            NSString *psw = [notifi.userInfo objectForKey:@"pwd"];
            if (notifi.userInfo.allValues.count > 0) {
                _accountField.text = userName;
                _pswField.text = psw;
            }
        } 
    }];
}

#pragma mark - 注册按钮点击
- (void)registerClick{
    if ([_accountField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text])
    {
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if ([_accountField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"账号长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_accountField.text length] > 20)
    {
        [NnnbTips depictCenterWithText:@"账号长度不能大于20个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(doRegister) withObject:nil afterDelay:0.5];
}

- (void)doRegister{
    [self registerBtnClick:_accountField.text andPsw:_pswField.text];
}

- (void)registerBtnClick:(NSString *)account andPsw:(NSString *)psw{
    [self depictLoadView];
    
    _userName = account;
    _psw = psw;
    //注册
    [[NnnbFacadeCenter defaultFacade] registWithAccount:account andPsd:psw result:^(BOOL success, NSNotification *notifi) {
        //等待界面
        [self removeLoadView];
        if (success) {
            [CommonData GetCommonDataInstance].autoRememberAndLogin = YES;
            [self screenshotToAlbum];
        }
        else {
            //提示错误
            NSString* errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)screenshotToAlbum {
    _eyeBtn.selected = NO;
    _pswField.secureTextEntry = NO;
    
    // 判断是否为retina屏, 即retina屏绘图时有放大因子
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
        UIGraphicsBeginImageContextWithOptions([UIScreen mainScreen].bounds.size, NO, [UIScreen mainScreen].scale);
    } else {
        UIGraphicsBeginImageContext([UIScreen mainScreen].bounds.size);
    }
    
    [self.window.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //写入相册中
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}

//写入相册回调方法
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    [self.delegate backToLastView:_userName andPsw:_psw];
    
    if(error != NULL){
        NSLog(@"保存图片失败");
    }else{
        NSLog(@"保存图片成功");
        [NnnbTips depictCenterWithText:@"账号密码已保存到相册" duration:3.0];
    }
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField) {
        [_accountField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else {
        [_pswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField){
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
