//
//  NnnbSRegisterCtrl.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbSSuperVCtrl.h"
#import "NnnbSRegisterV.h"

@protocol NnnbSRegisterViewCtrlDelegate <NSObject>

-(void)registerSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw;

- (void)registerVCPresentPhoneLoginVC;

@end

@interface NnnbSRegisterCtrl : NnnbSSuperVCtrl<NnnbSRegisterVDelegate>
@property (nonatomic,strong) NnnbSRegisterV *registerView;
@property (nonatomic,weak) id<NnnbSRegisterViewCtrlDelegate> delegate;
@end
