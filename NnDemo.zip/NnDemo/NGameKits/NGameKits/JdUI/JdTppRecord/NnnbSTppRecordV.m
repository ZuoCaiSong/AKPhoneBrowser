//
//  NnnbSTppRecordV.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSTppRecordV.h"
#import "NnnbDatePicker.h"
#import "NnnbLabelSizeToFit.h"
#import "NnnbSTppRecordC.h"

@interface NnnbSTppRecordV ()<NnnbDatePickerDelegate,UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UIView *headBgV;
@property (nonatomic,strong) NSString *currentDate;
@property (nonatomic,strong) UITableView *topUpRecordTableView;
@property (nonatomic,strong) NSArray *dataArr;
@property (nonatomic,strong) UILabel *dateLab;
@property (nonatomic,strong) UILabel *addUpLab;
@property (nonatomic,assign) NSInteger pickYear;
@property (nonatomic,assign) NSInteger pickMonth;
@end

@implementation NnnbSTppRecordV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    _dataArr = [NSArray array];
    
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate* dt = [NSDate date];
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay | NSCalendarUnitHour |  NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday;
    NSDateComponents *comp = [gregorian components: unitFlags
                                          fromDate:dt];
    
    _currentDate = [NSString stringWithFormat:@"%ld年%ld月",(long)comp.year,(long)comp.month];
    _pickYear = (long)comp.year;
    _pickMonth = (long)comp.month;
    
    NSString *dateStr = [NSString new];
    
    if (comp.month < 10) {
        dateStr = [NSString stringWithFormat:@"%ld-0%ld",(long)comp.year,(long)comp.month];
    } else {
        dateStr = [NSString stringWithFormat:@"%ld-%ld",(long)comp.year,(long)comp.month];
    }
    
    [self requestTopUpRecordDataWithDate:dateStr];
}

#pragma mark - 请求数据
- (void)requestTopUpRecordDataWithDate:(NSString *)dateStr{
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] getTopUpRecordWithDateStr:dateStr result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [self topUpRecordResultHandler:notifi];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)topUpRecordResultHandler:(NSNotification*)notif {

    NSDictionary *dict = notif.userInfo;
    
    if (_headBgV) {
        NSString *dateStr = [NSString stringWithFormat:@"%ld年%ld月",(long)_pickYear,(long)_pickMonth];
        CGFloat dateLabWid = [NnnbLabelSizeToFit getWidthWithtext:dateStr font:[UIFont systemFontOfSize:17]];
        
        CGRect d = _dateLab.frame;
        d.size.width = dateLabWid;
        _dateLab.frame = d;
        
        _dateLab.text = dateStr;
        
        NSInteger allmon = [[dict objectForKey:@"allM"] integerValue];
        
        NSString *chongStr = @"充";
        NSString *zhiStr = @"值";
        
        NSString *addUpStr = [NSString stringWithFormat:@"该月累计%@%@￥%ld.00",chongStr,zhiStr,(long)allmon];
        CGFloat addUpLabWid = [NnnbLabelSizeToFit getWidthWithtext:addUpStr font:[UIFont systemFontOfSize:17]];
        
        CGRect a = _addUpLab.frame;
        a.size.width = addUpLabWid;
        _addUpLab.frame = a;
        
        _addUpLab.text = addUpStr;
    } else {
        [self initHeaderViewWithDict:notif.userInfo];
    }

    if (dict[@"data"] && [dict[@"data"] isKindOfClass:[NSArray class]]){
        _dataArr = dict[@"data"];
        
        if (_dataArr.count != 0) {
            
            if (_topUpRecordTableView) {
                [_topUpRecordTableView reloadData];
            } else {
                [self initTableView];
            }
            
        } else {
            if (_topUpRecordTableView) {
                [_topUpRecordTableView reloadData];
            }
            
            NSString *chongStr = @"充";
            NSString *zhiStr = @"值";
            NSString *tipsStr = [NSString stringWithFormat:@"亲，该月还没有进行过%@%@哦!",chongStr,zhiStr];
            [NnnbTips depictCenterWithText:tipsStr duration:NN_TIPS_TIME3];
        }
    } else {
        if (_topUpRecordTableView) {
            _dataArr = [NSArray array];
            [_topUpRecordTableView reloadData];
        }
        
        NSString *chongStr = @"充";
        NSString *zhiStr = @"值";
        NSString *tipsStr = [NSString stringWithFormat:@"亲，该月还没有进行过%@%@哦!",chongStr,zhiStr];
        [NnnbTips depictCenterWithText:tipsStr duration:NN_TIPS_TIME3];
    }
}


#pragma mark - 初始化头部
- (void)initHeaderViewWithDict:(NSDictionary *)dict{
    _headBgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 60)];
    _headBgV.backgroundColor = RGBCOLOR(0, 171, 227);
    [self addSubview:_headBgV];
    
    CGFloat dateLabWid = [NnnbLabelSizeToFit getWidthWithtext:_currentDate font:[UIFont systemFontOfSize:17]];
    _dateLab = [[UILabel alloc] initWithFrame:CGRectMake(20, 10, dateLabWid, 20)];
    _dateLab.text = _currentDate;
    _dateLab.textColor = [UIColor whiteColor];
    [self addSubview:_dateLab];
    
    NSString *StrM1 = @"allm";
    NSString *StrM2 = @"oney";
    NSString *StrM3 = [NSString stringWithFormat:@"%@%@",StrM1,StrM2];
    NSInteger allMon = [[dict objectForKey:StrM3] integerValue];
    NSString *chongStr = @"充";
    NSString *zhiStr = @"值";
    NSString *addUpStr = [NSString stringWithFormat:@"该月累计%@%@￥%ld.00",chongStr,zhiStr,(long)allMon];
    CGFloat addUpLabWid = [NnnbLabelSizeToFit getWidthWithtext:addUpStr font:[UIFont systemFontOfSize:17]];
    _addUpLab = [[UILabel alloc] initWithFrame:CGRectMake(_dateLab.left, _dateLab.top+_dateLab.height, addUpLabWid, _dateLab.height)];
    _addUpLab.text = addUpStr;
    _addUpLab.textColor = [UIColor whiteColor];
    [self addSubview:_addUpLab];
    
    UIButton *dateBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    dateBtn.frame = CGRectMake(self.width-30-20, 15, 30, 30);
    [dateBtn setImage:[UIImage nnGetPlatImage:@"TygTopUpDate.png"] forState:UIControlStateNormal];
    [dateBtn addTarget:self action:@selector(dateBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_headBgV addSubview:dateBtn];
}

#pragma mark - 选择日期
- (void)dateBtnClick{
    NnnbDatePicker *datePicker = [[NnnbDatePicker alloc]init];
    datePicker.delegate = self;
    [datePicker showWithShadeBackgroud];
    datePicker.datePickerType = NnnbPickerViewType3;
    datePicker.datePickerMode = NnnbDatePickerModeYearAndMonth;
    
    datePicker.minimumDate = [NSDate setYear:2015 month:1];
    
    //获取当前年月
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate* dt = [NSDate date];
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay | NSCalendarUnitHour |  NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday;
    NSDateComponents *comp = [gregorian components: unitFlags
                                          fromDate:dt];
    
    datePicker.maximumDate = [NSDate setYear:comp.year month:comp.month];
}

//NnnbDatePickerDelegate
- (void)datePicker:(NnnbDatePicker *)datePicker didSelectDate:(NSDateComponents *)dateComponents {
    
    _pickYear = [dateComponents year];
    _pickMonth = [dateComponents month];
    
    NSString *yMStr = [NSString new];
    
    if (_pickMonth < 10) {
        yMStr = [NSString stringWithFormat:@"%ld-0%ld",(long)_pickYear,(long)_pickMonth];
    } else {
        yMStr = [NSString stringWithFormat:@"%ld-%ld",(long)_pickYear,(long)_pickMonth];
    }
    
    [self requestTopUpRecordDataWithDate:yMStr];
}

#pragma mark - 表格记录
- (void)initTableView{
    _topUpRecordTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, _headBgV.top+_headBgV.height, self.width, self.height-_headBgV.height) style:UITableViewStylePlain];
    _topUpRecordTableView.delegate = self;
    _topUpRecordTableView.dataSource = self;
//    _topUpRecordTableView.showsVerticalScrollIndicator = NO;
    _topUpRecordTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _topUpRecordTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self addSubview:_topUpRecordTableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"topUpRecordCell";
    
    NnnbSTppRecordC *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[NnnbSTppRecordC alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row];
    
    cell.nameLab.text = dict[@"prdN"];
    
    cell.dateLab.text = dict[@"date"];
    
    NSInteger mon = [[dict objectForKey:@"oiM"] integerValue];
    cell.monLab.text = [NSString stringWithFormat:@"%ld.00",(long)mon];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle ==UITableViewCellEditingStyleDelete) {
        NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row];
        
        [self depictLoadView];
        
        [[NnnbFacadeCenter defaultFacade] deleteTopUpRecord:dict[@"oi"] result:^(BOOL success, NSNotification *notifi) {
            [self removeLoadView];
            
            if (success && [notifi.userInfo[@"ret"] intValue] == 1)
            {
                NSMutableArray *arr = [NSMutableArray arrayWithArray:_dataArr];
                
                //删除数据源当前行数据
                [arr removeObjectAtIndex:indexPath.row];
                
                _dataArr = arr;
                
                //删除单元格
                [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
                
                NSString *yMDateStr = [NSString new];
                
                if (_pickMonth < 10)
                {
                    yMDateStr = [NSString stringWithFormat:@"%ld-0%ld",(long)_pickYear,(long)_pickMonth];
                }
                else
                {
                    yMDateStr = [NSString stringWithFormat:@"%ld-%ld",(long)_pickYear,(long)_pickMonth];
                }
                [self requestTopUpRecordDataWithDate:yMDateStr];
                [NnnbTips depictCenterWithText:@"删除成功" duration:NN_TIPS_TIME2];
            }
            else
            {
                NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
            }
        }];
    }
}

@end
