//
//  NnnbSTppRecordC.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSTppRecordC.h"
#import "NnnbLabelSizeToFit.h"

@implementation NnnbSTppRecordC

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        _nameLab = [[UILabel alloc] init];
        [self.contentView addSubview:_nameLab];
        
        _dateLab = [[UILabel alloc] init];
        _dateLab.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_dateLab];
        
        _monLab = [[UILabel alloc] init];
        _monLab.font = [UIFont systemFontOfSize:20];
        [self.contentView addSubview:_monLab];
        
        _line = [[UIImageView alloc] init];
        _line.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_line];
    }
    
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];

    CGFloat nameLabWid = [NnnbLabelSizeToFit getWidthWithtext:_nameLab.text font:[UIFont systemFontOfSize:17]];
    _nameLab.frame = CGRectMake(20, 10, nameLabWid, 20);
    
    CGFloat dateLabWid = [NnnbLabelSizeToFit getWidthWithtext:_dateLab.text font:[UIFont systemFontOfSize:17]];
    _dateLab.frame = CGRectMake(_nameLab.left, _nameLab.top+_nameLab.height, dateLabWid, _nameLab.height);
    
    CGFloat monLabWid = [NnnbLabelSizeToFit getWidthWithtext:_monLab.text font:[UIFont systemFontOfSize:20]];
    _monLab.frame = CGRectMake(self.contentView.width-monLabWid-20, _nameLab.top+5, monLabWid, 30);
    
    _line.frame = CGRectMake(0, _dateLab.top+_dateLab.height+9, self.contentView.width, 1);
}

@end
