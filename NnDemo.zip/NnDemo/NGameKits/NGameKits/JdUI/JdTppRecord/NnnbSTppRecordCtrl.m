//
//  NnnbSTppRecordCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSTppRecordCtrl.h"

@interface NnnbSTppRecordCtrl ()
@property (nonatomic,strong) NnnbSTppRecordV *topUpRecordView;
@end

@implementation NnnbSTppRecordCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    [[NnnbSFloatW getInstance] removeWindow];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    NSString *chongStr = @"充";
    NSString *zhiStr = @"值记录";
    NSString *topUpStr = [NSString stringWithFormat:@"%@%@",chongStr,zhiStr];
    title.text = topUpStr;
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.bgView addSubview:self.closeBtn];
    
    [self depicttopUpRecordView];
}

- (void)depicttopUpRecordView{
    _topUpRecordView = [[NnnbSTppRecordV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.frame.size.width, self.bgView.frame.size.height-45)];
    _topUpRecordView.delegate = self;
    [self.bgView addSubview:_topUpRecordView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
