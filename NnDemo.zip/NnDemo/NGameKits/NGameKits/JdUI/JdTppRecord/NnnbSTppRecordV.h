//
//  NnnbSTppRecordV.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSTppRecordVDelegate <NSObject>

@end

@interface NnnbSTppRecordV : NnnbSSuperV
@property (nonatomic,weak) id<NnnbSTppRecordVDelegate> delegate;
@end
