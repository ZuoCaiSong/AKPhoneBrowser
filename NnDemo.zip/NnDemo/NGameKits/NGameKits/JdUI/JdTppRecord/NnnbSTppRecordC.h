//
//  NnnbSTppRecordC.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import <UIKit/UIKit.h>

@interface NnnbSTppRecordC : UITableViewCell
@property (nonatomic,strong) UILabel *nameLab;
@property (nonatomic,strong) UILabel *dateLab;
@property (nonatomic,strong) UILabel *monLab;
@property (nonatomic,strong) UIImageView *line;
@end
