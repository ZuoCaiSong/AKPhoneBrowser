//
//  NnnbSOnlineCusCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSOnlineCusCtrl.h"
#import <WebKit/WebKit.h>

@interface NnnbSOnlineCusCtrl ()<WKNavigationDelegate,WKUIDelegate,UINavigationControllerDelegate,WKScriptMessageHandler>

@end

@implementation NnnbSOnlineCusCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    WKUserContentController *userContentController = [[WKUserContentController alloc]init];
    [userContentController addScriptMessageHandler:self name:@"back"];
    configuration.userContentController = userContentController;
    
    WKPreferences *preferences = [WKPreferences new];
    preferences.javaScriptCanOpenWindowsAutomatically = YES;
    preferences.minimumFontSize = 10.0;
    configuration.preferences = preferences;
    
    WKWebView *onlineWebview = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height) configuration:configuration];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@?device=ios",_urlStr]];
    NSURLRequest *request =[NSURLRequest requestWithURL:url];
    [onlineWebview loadRequest:request];
    onlineWebview.UIDelegate = self;
    onlineWebview.navigationDelegate = self;
    [self.view addSubview:onlineWebview];
}

- (void)returnToLastView
{
    [self.navigationController popViewControllerAnimated:YES];
    
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    mainWindow.rootViewController = self.originalRootVC;
    
    [[NnnbSFloatW getInstance] depictWindow];
}

#pragma mark - WKNavigationDelegate
-(void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    [self depictLoadView];
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [self removeLoadView];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    [self removeLoadView];
    [self returnToLastView];
    
    [NnnbTips depictCenterWithText:@"请求错误,请检查网络" duration:NN_TIPS_TIME3];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    if (navigationAction.targetFrame == nil) {
        [webView loadRequest:navigationAction.request];
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

#pragma mark - WKUIDelegate
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提醒" message:message preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - WKScriptMessageHandler
/**
 * JS 调用 OC 触发此方法
 */
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    if ([message.name isEqualToString:@"back"])
    {
        [CommonData GetCommonDataInstance].currentDirection = -1;
        [self returnToLastView];
    }
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
