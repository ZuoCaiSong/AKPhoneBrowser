//
//  NnnbSCustomerCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSCustomerCtrl.h"
#import "NnnbSCustomerV.h"

#define offLeft_x_width 10

@interface NnnbSCustomerCtrl ()
@property (nonatomic,strong) NnnbSCustomerV *customerView;
@end

@implementation NnnbSCustomerCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    [[NnnbSFloatW getInstance] removeWindow];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    title.text = @"联系客服";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.bgView addSubview:self.closeBtn];
    
    [self showCustomerView];
}

- (void)showCustomerView{
    _customerView = [[NnnbSCustomerV alloc] initWithFrame:CGRectMake(0, self.titleIg.tp_bottom+10, self.bgView.frame.size.width, self.bgView.frame.size.height-(self.titleIg.height+10))];
    [self.bgView addSubview:_customerView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
