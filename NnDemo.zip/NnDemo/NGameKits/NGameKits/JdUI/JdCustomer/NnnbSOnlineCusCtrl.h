//
//  NnnbSOnlineCusCtrl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperVCtrl.h"

@interface NnnbSOnlineCusCtrl : NnnbSSuperVCtrl
@property (nonatomic,copy) NSString *urlStr;
@property (nonatomic,strong) UIViewController *originalRootVC;
@end
