//
//  NnnbSCustomerV.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSCustomerV.h"
#import "NnnbSOnlineCusCtrl.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 40

#define btnHeight 50

@interface NnnbSCustomerV ()<UIAlertViewDelegate>
@end

@implementation NnnbSCustomerV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

#pragma mark - 渲染界面
- (void)initView
{
    if (![CommonData GetCommonDataInstance].cusDict || [CommonData GetCommonDataInstance].cusDict == nil || ![NnnbCommons isNSDictionaryObject:[CommonData GetCommonDataInstance].cusDict])
    {
        [NnnbTips depictCenterWithText:@"暂无相关信息" duration:NN_TIPS_TIME2];
        return;
    }
    
    NSMutableArray *iconArr = [NSMutableArray arrayWithArray:@[@"TygCusPhone.png",@"TygCusGzh.png",@"TygCusOlkf.png",@"TygCusPyg.png"]];
    
    NSString *str1 = @"拨打客";
    NSString *str2 = @"服热线";
    NSString *customer1 = [NSString stringWithFormat:@"%@%@",str1,str2];
    
    NSString *str3 = @"添加客";
    NSString *str4 = @"服公众号";
    NSString *customer2 = [NSString stringWithFormat:@"%@%@",str3,str4];
    
    NSString *str5 = @"咨询在线客";
    NSString *str6 = @"服";
    NSString *customer3 = [NSString stringWithFormat:@"%@%@",str5,str6];
    
    NSString *str7 = @"加入玩家Q";
    NSString *str8 = @"群";
    NSString *customer4 = [NSString stringWithFormat:@"%@%@",str7,str8];
    
    NSMutableArray *titleArr = [NSMutableArray arrayWithArray:@[customer1,customer2,customer3,customer4]];
    
    if ([[CommonData GetCommonDataInstance].cusDict[@"kft"] isEqualToString:@"0"])
    {
        [iconArr removeObject:@"TygCusPhone.png"];
        [titleArr removeObject:customer1];
    }
    
    if ([[CommonData GetCommonDataInstance].cusDict[@"kfq_url"] isEqualToString:@"0"])
    {
        [iconArr removeObject:@"TygCusGzh.png"];
        [titleArr removeObject:customer2];
    }
    
    if ([[CommonData GetCommonDataInstance].cusDict[@"contactURL"] isEqualToString:@"0"])
    {
        [iconArr removeObject:@"TygCusOlkf.png"];
        [titleArr removeObject:customer3];
    }
    
    if ([[CommonData GetCommonDataInstance].cusDict[@"pyq_url"] isEqualToString:@"0"])
    {
        [iconArr removeObject:@"TygCusPyg.png"];
        [titleArr removeObject:customer4];
    }
    
    if (iconArr.count == 0 && titleArr.count == 0) {
        [NnnbTips depictCenterWithText:@"暂无相关信息" duration:NN_TIPS_TIME2];
        return;
    }
    
    for (int i = 0; i < titleArr.count; i ++) {
        NnnbSButton *btn = [NnnbSButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, i*btnHeight, self.width, btnHeight);
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage nnGetPlatImage:@"TygLightGray.png"] forState:UIControlStateHighlighted];
        [btn setImage:[UIImage nnGetPlatImage:iconArr[i]] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        
        UIImageView *arrowImg = [[UIImageView alloc] initWithFrame:CGRectMake(btn.width-11-20, (btnHeight-18)/2, 11, 18)];
        arrowImg.image = [UIImage nnGetPlatImage:@"TygRightJianTou.png"];
        [btn addSubview:arrowImg];
        
        UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(btn.titleLabel.left, btnHeight-1, btn.width-btn.titleLabel.left-20, 1)];
        line.backgroundColor = [UIColor lightGrayColor];
        line.alpha = 0.3;
        [btn addSubview:line];
    }
}

- (void)btnClick:(UIButton *)button
{
    NSString *str1 = @"拨打客";
    NSString *str2 = @"服热线";
    NSString *customer1 = [NSString stringWithFormat:@"%@%@",str1,str2];
    NSString *customer11 = [NSString stringWithFormat:@"是否%@",customer1];
    
    NSString *str3 = @"添加客";
    NSString *str4 = @"服公众号";
    NSString *customer2 = [NSString stringWithFormat:@"%@%@",str3,str4];
    NSString *customer22 = [NSString stringWithFormat:@"是否%@",customer2];
    
    NSString *str5 = @"咨询在线客";
    NSString *str6 = @"服";
    NSString *customer3 = [NSString stringWithFormat:@"%@%@",str5,str6];
    NSString *customer33 = [NSString stringWithFormat:@"是否%@",customer3];
    
    NSString *str7 = @"加入玩家Q";
    NSString *str8 = @"群";
    NSString *customer4 = [NSString stringWithFormat:@"%@%@",str7,str8];
    NSString *customer44 = [NSString stringWithFormat:@"是否%@",customer4];
    
    if ([button.titleLabel.text isEqualToString:customer1])
    {
        [self depictAlertViewWithTip:customer11 Tag:1000];
    }
    
    else if ([button.titleLabel.text isEqualToString:customer2])
    {
        [self depictAlertViewWithTip:customer22 Tag:1001];
    }
    
    else if ([button.titleLabel.text isEqualToString:customer3])
    {
        [self depictAlertViewWithTip:customer33 Tag:1002];
    }
    
    else if ([button.titleLabel.text isEqualToString:customer4])
    {
        [self depictAlertViewWithTip:customer44 Tag:1003];
    }
}

#pragma mark - AlertView
- (void)depictAlertViewWithTip:(NSString *)tipStr Tag:(NSInteger)iTag
{
    UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:tipStr
                                                      delegate:self
                                             cancelButtonTitle:@"取消"
                                             otherButtonTitles:@"确定",nil];
    alertView.tag = iTag;
    
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        if (alertView.tag == 1000)
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",[CommonData GetCommonDataInstance].cusDict[@"kft"]]]];
        }
        else if (alertView.tag == 1001)
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[CommonData GetCommonDataInstance].cusDict[@"kfq_url"]]];
        }
        else if (alertView.tag == 1002)
        {
            if ([[UIDevice currentDevice].systemVersion doubleValue] < 11.0)
            {
                [CommonData GetCommonDataInstance].currentDirection = 1;
            }
            NnnbSOnlineCusCtrl *onlineCtrl = [[NnnbSOnlineCusCtrl alloc] init];
            onlineCtrl.urlStr = [CommonData GetCommonDataInstance].cusDict[@"contactURL"];
            UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
            onlineCtrl.originalRootVC = mainWindow.rootViewController;
            UINavigationController *nav = [[UINavigationController alloc] init];
            nav.navigationBarHidden = YES;
            mainWindow.rootViewController = nav;
            [nav pushViewController:onlineCtrl animated:YES];
        }
        else if (alertView.tag == 1003)
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[CommonData GetCommonDataInstance].cusDict[@"pyq_url"]]];
        }
    }
}

@end
