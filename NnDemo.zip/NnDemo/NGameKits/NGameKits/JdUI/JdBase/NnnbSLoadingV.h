//
//  NnnbSLoadingV.h
//

#import <UIKit/UIKit.h>

@interface NnnbSLoadingV : UIView
{
@private
    UIActivityIndicatorView *_indicatorView;
}

/**
  展现到指定视图中
  @param view 视图对象
 **/
- (void)depictInView:(UIView *)view;

/**
  移除视图
 **/
- (void)remove;

@end
