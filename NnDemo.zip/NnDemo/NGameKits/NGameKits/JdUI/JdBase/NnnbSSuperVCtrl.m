
#import "NnnbSSuperVCtrl.h"
#import "NnnbColorEx.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 5
//btn宽度
#define btn_width 40
//btn高度
#define btn_height 40
//背景图宽度
#define fixWidth 360
//背景图高度
#define fixHeight 280
// 关闭视图的动画时间
#define closeViewAnimatedTime 0.3

@interface NnnbSSuperVCtrl ()
@end

@implementation NnnbSSuperVCtrl

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    direction = [[CommonData GetCommonDataInstance] judgeDirection];
    
    //  是否是iPad
    self.isiPad = [self isiPad];
    
    CGSize bgViewSize = CGSizeZero;
    CGRect backBtnFrame = CGRectZero;
    CGRect closeBtnFrame = CGRectZero;
    
    // 横竖屏判断
    if (direction == 1)
    {
        bgViewSize = CGSizeMake(fixWidth, fixHeight);
    }else{
        // iPad采用横屏布局
        if (self.isiPad) {
            bgViewSize = CGSizeMake(fixWidth, fixHeight);
        } else {
            //iPhone5系列，5、5s、5c、SE
            if(isIPhone55S5CSE){
                bgViewSize = CGSizeMake(fixHeight, fixHeight);
            } else {
                bgViewSize = CGSizeMake(UIScreenWidth - 50*portraitAutoSizeScale_5, fixHeight);
            }
        }
    }
    
    backBtnFrame = CGRectMake(offLeft_x_width, offTop_x_height, btn_width, btn_height);
    closeBtnFrame = CGRectMake(bgViewSize.width-btn_width-offRight_x_width, offTop_x_height, btn_width, btn_height);
    
    self.bgView = [[UIView alloc] init];
    self.bgView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
    self.bgView.center = self.view.center;
    self.bgView.bounds = CGRectMake(0, 0, bgViewSize.width, bgViewSize.height);
    self.bgView.layer.masksToBounds = YES;
    self.bgView.layer.cornerRadius = 9.0f;
    self.bgViewFrame = self.bgView.frame;
    
    self.titleIg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.bgView.width, 45)];
    self.titleIg.image = [UIImage nnGetPlatImage:@"TygTitleBg.png"];
    [self.bgView addSubview:self.titleIg];
    
    // 返回按钮
    self.backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.backBtn.frame = backBtnFrame;
    [self.backBtn setImage:[UIImage nnGetPlatImage:@"TygBackGray.png"] forState:UIControlStateNormal];
    [self.backBtn addTarget:self action:@selector(popView) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.backBtn];
    
    // 关闭按钮
    self.closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.closeBtn.frame = closeBtnFrame;
    [self.closeBtn setImage:[UIImage nnGetPlatImage:@"TygClose.png"] forState:UIControlStateNormal];
    [self.closeBtn addTarget:self action:@selector(closeView) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.closeBtn];
}

#pragma mark - 判断是否iPad
- (BOOL)isiPad
{
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
        return YES;
    }else {
        return NO;
    }
}

#pragma mark - 返回上个页面
- (void)popView{
  [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 关闭视图
- (void)closeView{
    [UIView animateWithDuration:closeViewAnimatedTime animations:^{
        self.bgView.alpha = 0;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, UIScreenHeight, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        self.view.hidden = YES;
        [self.view removeFromSuperview];
    }];
    
    [[NnnbSFloatW getInstance] depictWindow];
}

#pragma mark - 关闭键盘
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self removeKeyboard:self.view];
}

- (void)removeKeyboard:(UIView *)view
{
    for (UIView *subview in view.subviews) {
        if ([subview isKindOfClass:[UITextField class]]) {
            if ([subview isFirstResponder]) {
                [subview resignFirstResponder];
            }
        } else {
            [self removeKeyboard:subview];
        }
    }
}

-(void)depictLoadView{
    if (_twLoadingView == nil)
    {
        _twLoadingView = [[NnnbSLoadingV alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    }
    
    self.view.userInteractionEnabled = NO;
    [_twLoadingView depictInView:self.view];
}

-(void)removeLoadView{
    if (_twLoadingView)
    {
        [_twLoadingView remove];
    }
    
    self.view.userInteractionEnabled = YES;
}

#pragma mark - 旋转
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_6_0
- (BOOL)shouldAutorotate
{
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    if (direction == 1) {
        return UIInterfaceOrientationMaskLandscape;
    } else {
        return UIInterfaceOrientationMaskPortrait;
    }
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return [UIApplication sharedApplication].statusBarOrientation;
}
#endif

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
