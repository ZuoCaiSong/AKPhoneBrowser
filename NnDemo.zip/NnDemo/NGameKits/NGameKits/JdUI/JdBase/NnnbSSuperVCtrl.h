
#import <UIKit/UIKit.h>
#import "NnnbSLoadingV.h"

@interface NnnbSSuperVCtrl : UIViewController {
@private
    UIView *_bgView;
    BOOL    _isNext;
    BOOL    _isRotation;
    NnnbSLoadingV       *_twLoadingView;
    
    //用于判断横竖屏方向
    NSInteger direction;
}
@property (nonatomic, assign) BOOL isNext;
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIButton *backBtn;
@property (nonatomic, strong) UIButton *closeBtn;
@property (nonatomic, assign) BOOL isiPad;
@property (nonatomic, strong) UIImageView *titleIg;
@property (nonatomic, assign) CGRect bgViewFrame;

- (void)popView;

- (void)closeView;

-(void)depictLoadView;

-(void)removeLoadView;

@end
