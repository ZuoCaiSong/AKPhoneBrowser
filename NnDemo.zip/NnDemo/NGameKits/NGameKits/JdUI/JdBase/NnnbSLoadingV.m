//
//  U6SimpleLoadingView.m

#import "NnnbSLoadingV.h"

@implementation NnnbSLoadingV

#define LEFT_PADDING 10.0
#define RIGHT_PADDING 10.0
#define TOP_PADDING 5.0
#define BOTTOM_PADDING 5.0
#define HORIZONTAL_GAP 5.0

#define MAX_WIDTH 550
#define MIN_WIDTH 175
#define MAX_HEIGHT 120
#define MIN_HEIGHT 70

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = RGBACOLOR(0x33,0x33,0x33,0.5);
        self.layer.cornerRadius = 10;
        self.layer.masksToBounds = YES;
        
        _indicatorView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        _indicatorView.frame=CGRectMake((self.width-_indicatorView.width)/2, (self.height-_indicatorView.height)/2, _indicatorView.width, _indicatorView.height);
        [_indicatorView startAnimating];
        [self addSubview:_indicatorView];
    }
    return self;
}

-(void)depictInView:(UIView *)view
{
    self.alpha=0;
    [self sizeToFit];
    self.frame = CGRectMake((view.width-self.width)/2,
                          ((view.height-self.height)/2)-10,
                          self.width,
                          self.height);
    [_indicatorView startAnimating];
    [view addSubview:self];
    [view bringSubviewToFront:self];
    [UIView beginAnimations:@"LoadingPanelAnimation" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    self.alpha=1;
    [UIView commitAnimations];
}


-(void)remove
{
    [UIView beginAnimations:@"LoadingPanelAnimation" context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(removeAnimationComplete)];
    self.alpha=0;
    [UIView commitAnimations];
}

-(void)removeAnimationComplete
{
    [_indicatorView stopAnimating];
    [self removeFromSuperview];
}

@end
