//
//  NnnbSFloatW.h
//  testTab
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbSRegisterCtrl.h"
#import "NnnbSTppCenterCtrl.h"
#import "NnnbSUserCenterCtrl.h"
#import "NnnbSBindPhoneCtrl.h"
#import "NnnbSCustomerCtrl.h"
#import "NnnbSPublicNotCtrl.h"
#import "NnnbSPackageCtrl.h"
#import "NnnbSTppRecordCtrl.h"
#import "NnnbSFgPassWordViewCtrl.h"
#import "NnnbSLoginCtrl.h"
#import "NnnbSFastRegisterCtrl.h"
#import "NnnbSChangePswCtrl.h"
#import "NnnbSRealNameCheckCtrl.h"
#import "NnnbSBindPhoneCtrl.h"
#import "NnnbSTelLoginVCtrl.h"

@interface NnnbSFloatW : UIView<UIAlertViewDelegate>

+(NnnbSFloatW *)getInstance;

// 设置
- (void)setIsdepictFloat:(BOOL)bdepictFloat;

- (void)depictWindow;

- (void)removeWindow;

@property (nonatomic,strong) NnnbSLoginCtrl *loginViewController;
@property (nonatomic,strong) NnnbSTppCenterCtrl *topUpCenterController;
@property (nonatomic,strong) NnnbSUserCenterCtrl *userCenterController;
@property (nonatomic,strong) NnnbSBindPhoneCtrl *bindPhoneController;
@property (nonatomic,strong) NnnbSCustomerCtrl *customerController;
@property (nonatomic,strong) NnnbSPublicNotCtrl *publicNotController;
@property (nonatomic,strong) NnnbSPackageCtrl *packageViewController;
@property (nonatomic,strong) NnnbSTppRecordCtrl *topUpRecordViewController;
@property (nonatomic,strong) NnnbSFgPassWordViewCtrl *fgPassWordViewController;
@property (nonatomic,strong) NnnbSRegisterCtrl *registerViewController;
@property (nonatomic,strong) NnnbSFastRegisterCtrl *fastRegisterViewController;
@property (nonatomic,strong) NnnbSChangePswCtrl *changePswViewController;
@property (nonatomic,strong) NnnbSRealNameCheckCtrl *realNameCheckViewController;
@property (nonatomic,strong) NnnbSBindPhoneCtrl * bindPhoneViewController;
@property (nonatomic,strong) NnnbSTelLoginVCtrl * phoneViewController;

@end
