//
//  NnnbSFloatW.m
//  testTab
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSFloatW.h"
#import "UIView+NnnbBadge.h"

#define WIDTH self.frame.size.width
#define HEIGHT self.frame.size.height
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

#define animateDuration 0.3       //位置改变动画时间
#define showDuration 0.2          //展开动画时间
#define statusChangeDuration  3.0    //状态改变时间
#define normalAlpha  1.0           //正常状态时背景alpha值
#define sleepAlpha  0.3           //移动到边缘时的背景alpha值
#define myBorderWidth 1.0         //外框宽度
#define marginWith  5             //间隔
#define closeViewAnimatedTime 0.3 // 关闭视图的动画时间
#define WZFlashInnerCircleInitialRaius  20
#define LOGIN_OUT_BTN_TAG 1000

static NnnbSFloatW *_twfloatWindow = nil;

@interface NnnbSFloatW()
@property (nonatomic) NSInteger frameWidth;
@property (nonatomic) BOOL  isdepictTab;
@property (nonatomic) BOOL  isdepictFloat;
@property (nonatomic) BOOL  bIsInitUI;
@property (nonatomic,strong) UIPanGestureRecognizer *pan;
@property (nonatomic,strong) UITapGestureRecognizer *tap;
@property (nonatomic,strong) UIButton *mainImageButton;
@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) UIColor *bgcolor;
@property (nonatomic,strong) CAAnimationGroup *animationGroup;
@property (nonatomic,strong) CAShapeLayer *circleShape;
@property (nonatomic,strong) UIColor *animationColor;
@property (nonatomic,strong) NSMutableArray *imageArray;
@property (nonatomic,strong) NSMutableArray *titleArray;
@property (nonatomic,assign) CGPoint lastPoint;
@property (nonatomic,assign) NSInteger iXLandscapeExt;
@property (nonatomic,assign) NSInteger iXPortraitExt;
@property (nonatomic,assign) NSInteger iDirection;

@end

@implementation NnnbSFloatW

+(NnnbSFloatW *)getInstance{
    @synchronized (self) {
        if (_twfloatWindow == nil) {
            _twfloatWindow = [[NnnbSFloatW alloc] init];
        }
    }
    
    return _twfloatWindow;
}

-(id)init{
    _isdepictFloat = YES;
    _bIsInitUI = NO;
    _iDirection = [[CommonData GetCommonDataInstance] judgeDirection];
    if (_iDirection == 1 && isIPhoneX) {
        _iXLandscapeExt = 25;
        _iXPortraitExt = 0;
    }else if (_iDirection == 0 && isIPhoneX)
    {
        _iXLandscapeExt = 0;
        _iXPortraitExt = 25;
    }else{
        _iXLandscapeExt = 0;
        _iXPortraitExt = 0;
    }
    
    //重要：所有图片都要是圆形的，程序里并没有自动处理成圆形
    //warning: frame的长宽必须相等
    CGRect frame = CGRectZero;
    CGFloat originX = 0;
    CGFloat originY = (UIScreenHeight/2)-25;
    
    if (_iDirection == 1 && isIPhoneX) {
        originX = 25;
    }
    frame = CGRectMake(originX, originY, 50, 50);
    
    if (self = [super initWithFrame:frame]) {
        _isdepictTab = FALSE;
        _frameWidth = frame.size.width;
        
        _mainImageButton =  [UIButton buttonWithType:UIButtonTypeCustom];
        [_mainImageButton setFrame:(CGRect){0, 0,frame.size.width, frame.size.height}];
        [_mainImageButton setImage:[UIImage nnGetPlatImage:@"TygLogo.png"] forState:UIControlStateNormal];
        _mainImageButton.alpha = normalAlpha;
        [_mainImageButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        
        [MainWindow addSubview:self];
    }
    
    self.hidden = YES;
    return self;
}

-(void)initUI{
    self.backgroundColor = [UIColor clearColor];
    
    _bgcolor = [UIColor whiteColor];
    _animationColor = RGBCOLOR(102, 165, 252);
    
    NSString *liStr = @"礼";
    NSString *bagStr = @"包";
    NSString *lgStr = [NSString stringWithFormat:@"%@%@",liStr,bagStr];
    
    _titleArray = [NSMutableArray array];
    _imageArray = [NSMutableArray array];
    
    [_titleArray addObject:@"账户"];
    [_imageArray addObject:@"TygCenterUser.png"];
    
    if ([CommonData GetCommonDataInstance].packageState == 1) {
        [_titleArray addObject:lgStr];
        [_imageArray addObject:@"TygPackage.png"];
    }
    
    if ([CommonData GetCommonDataInstance].sPub == 1) {
        [_titleArray addObject:@"公告"];
        [_imageArray addObject:@"TygPublicNot.png"];
    }
    
    if ([CommonData GetCommonDataInstance].sCur == 1) {
        [_titleArray addObject:@"客服"];
        [_imageArray addObject:@"TygCustomerService.png"];
    }
    
    [_titleArray addObject:@"注销"];
    [_imageArray addObject:@"TygLogOut.png"];
    
    _contentView = [[UIView alloc] initWithFrame:(CGRect){_frameWidth ,0,_titleArray.count * (_frameWidth + 5),_frameWidth}];
    _contentView.alpha  = 0;
    [self addSubview:_contentView];
    //添加按钮
    [self setButtons];
    
    if (_animationColor) {
        [_mainImageButton addTarget:self action:@selector(mainBtnTouchDown) forControlEvents:UIControlEventTouchDown];
    }
    
    [self addSubview:_mainImageButton];
    
    [self doBorderWidth:myBorderWidth color:nil cornerRadius:_frameWidth/2];
    
    _pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(locationChange:)];
    _pan.delaysTouchesBegan = NO;
    [self addGestureRecognizer:_pan];
    _tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(click:)];
    [self addGestureRecognizer:_tap];
    //设备旋转的时候收回按钮
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willOrientChange:) name:UIApplicationWillChangeStatusBarOrientationNotification object:nil];
    //设备旋转的时候收回按钮
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didOrientChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
    
    [self performSelector:@selector(changeStatus) withObject:nil afterDelay:statusChangeDuration];
}

- (void)setIsdepictFloat:(BOOL)bdepictFloat
{
    _isdepictFloat = bdepictFloat;
}

- (void)depictWindow{
    if (!_bIsInitUI) {
        [self initUI];
        _bIsInitUI = YES;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(closeViewAnimatedTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if(nil != _loginViewController){
            [_loginViewController.view removeFromSuperview];
            _loginViewController = nil;
        }
        
        if(nil != _topUpCenterController){
            [_topUpCenterController.view removeFromSuperview];
            _topUpCenterController = nil;
        }
        
        if (nil != _userCenterController) {
            [_userCenterController.view removeFromSuperview];
            _userCenterController = nil;
        }
        
        if (nil != _bindPhoneController) {
            [_bindPhoneController.view removeFromSuperview];
            _bindPhoneController = nil;
        }
        
        if (nil != _customerController) {
            [_customerController.view removeFromSuperview];
            _customerController = nil;
        }
        
        if (nil != _publicNotController) {
            [_publicNotController.view removeFromSuperview];
            _publicNotController = nil;
        }
        
        if (nil != _packageViewController) {
            [_packageViewController.view removeFromSuperview];
            _packageViewController = nil;
        }
        
        if (nil != _topUpRecordViewController) {
            [_topUpRecordViewController.view removeFromSuperview];
            _topUpRecordViewController = nil;
        }
        
        if (nil != _fgPassWordViewController) {
            [_fgPassWordViewController.view removeFromSuperview];
            _fgPassWordViewController = nil;
        }
        
        if (nil != _registerViewController) {
            [_registerViewController.view removeFromSuperview];
            _registerViewController = nil;
        }
        
        if (nil != _fastRegisterViewController) {
            [_fastRegisterViewController.view removeFromSuperview];
            _fastRegisterViewController = nil;
        }
        
        if (nil != _changePswViewController) {
            [_changePswViewController.view removeFromSuperview];
            _changePswViewController = nil;
        }
        
        if (nil != _realNameCheckViewController) {
            [_realNameCheckViewController.view removeFromSuperview];
            _realNameCheckViewController = nil;
        }
        
        if (nil != _bindPhoneViewController) {
            [_bindPhoneViewController.view removeFromSuperview];
            _bindPhoneViewController = nil;
        }
        
        if (nil != _phoneViewController) {
            [_phoneViewController.view removeFromSuperview];
            _phoneViewController = nil;
        }
    });
    
    if (_isdepictFloat == NO) {
        return;
    }
    
    self.alpha = 0;
    self.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1;
    } completion:^(BOOL finished) {
        [MainWindow bringSubviewToFront:self];
    }];
    
    if ([CommonData GetCommonDataInstance].randomAccReq == NO) {        
        [[NnnbFacadeCenter defaultFacade] verifyAccount:^(BOOL success, NSNotification *notifi) {
            if (success) {
                NSDictionary *dict = notifi.userInfo;
                
                if ((dict != nil) && [NnnbCommons isNSDictionaryObject:dict] && [dict objectForKey:@"state"]) {
                    [CommonData GetCommonDataInstance].accState = [[dict objectForKey:@"state"] integerValue];
                }
                else {
                    [CommonData GetCommonDataInstance].accState = 0;
                }
                [CommonData GetCommonDataInstance].randomAccReq = YES;
            }
            else {
                [CommonData GetCommonDataInstance].accState = 0;
                
                [CommonData GetCommonDataInstance].randomAccReq = NO;
            }
        }];
    }
}



- (void)removeWindow{
    self.hidden = YES;
}

- (void)setButtons{
    for (int i = 0; i < _titleArray.count; i ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame: CGRectMake(self.frameWidth * i , 2, self.frameWidth, self.frameWidth-4)];
        [button setBackgroundColor:[UIColor clearColor]];
        
        UIImage *image = [UIImage nnGetPlatImage:_imageArray[i]];
        [button setTitle:_titleArray[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button setImage:image forState:UIControlStateNormal];
        
        button.tag = i;
        [button setImageEdgeInsets:UIEdgeInsetsMake(-button.titleLabel.intrinsicContentSize.height, 0, 1, -button.titleLabel.intrinsicContentSize.width)];
        [button setTitleEdgeInsets:UIEdgeInsetsMake(button.currentImage.size.height, -button.currentImage.size.width, 0, 0)];
        [button addTarget:self action:@selector(itemsClick:) forControlEvents:UIControlEventTouchUpInside];
       
        [self.contentView addSubview:button];
    };
}

#pragma mark ------- contentview 操作 --------------------
//按钮在屏幕右边时，左移contentview
- (void)moveContentviewLeft{
    _contentView.frame = (CGRect){self.frameWidth/3, 0 ,_contentView.width,_contentView.height};
}

//按钮在屏幕左边时，contentview恢复默认
- (void)resetContentview{
    _contentView.frame = (CGRect){self.frameWidth + marginWith,0,_contentView.width,_contentView.height};
}


#pragma mark  ------- 绘图操作 ----------
- (void)drawRect:(CGRect)rect {
    [self drawDash];
}
//分割线
- (void)drawDash{
    CGContextRef context =UIGraphicsGetCurrentContext();
    CGContextBeginPath(context);
    CGContextSetLineWidth(context, 0.1);
    CGContextSetStrokeColorWithColor(context, [UIColor whiteColor].CGColor);
    CGFloat lengths[] = {2,1};
    CGContextSetLineDash(context, 0, lengths,2);
    for (int i = 1; i < _titleArray.count; i++){
        CGContextMoveToPoint(context, self.contentView.left + i * self.frameWidth, marginWith * 2);
        CGContextAddLineToPoint(context, self.contentView.left + i * self.frameWidth, self.frameWidth - marginWith * 2);
    }
    CGContextStrokePath(context);
}

//改变位置
- (void)locationChange:(UIPanGestureRecognizer*)p
{
    if (_isdepictTab == true) {
        [self animatedHiddenWindow];
        _isdepictTab = false;
        [self performSelector:@selector(buttonAnimation) withObject:nil afterDelay:0.5];
    }
    
    CGPoint panPoint = [p locationInView:[[[UIApplication sharedApplication] delegate] window]];
    
    if(p.state == UIGestureRecognizerStateBegan)
    {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(changeStatus) object:nil];
        _mainImageButton.alpha = normalAlpha;
    }
    
    if(p.state == UIGestureRecognizerStateChanged)
    {
        self.center = CGPointMake(panPoint.x, panPoint.y);
    }
    else if(p.state == UIGestureRecognizerStateEnded)
    {
        [self stopAnimation];
        [self performSelector:@selector(changeStatus) withObject:nil afterDelay:statusChangeDuration];
        [self reFreshWindowWithCurrentPoint:panPoint];
    }
}

//点击事件
- (void)click:(UITapGestureRecognizer*)p
{
    [self stopAnimation];

    _mainImageButton.alpha = normalAlpha;
    
    //拉出窗
    if (self.center.x == 0) {
        self.center = CGPointMake(WIDTH/2, self.center.y);
    }else if (self.center.x == kScreenWidth) {
        self.center = CGPointMake(kScreenWidth - WIDTH/2, self.center.y);
    }else if (self.center.y == 0) {
        self.center = CGPointMake(self.center.x, HEIGHT/2);
    }else if (self.center.y == kScreenHeight) {
        self.center = CGPointMake(self.center.x, kScreenHeight - HEIGHT/2);
    }
    //展示按钮列表
    if (!self.isdepictTab) {
        self.isdepictTab = TRUE;
        //为了主按钮点击动画
        self.layer.masksToBounds = YES;
        self.layer.borderWidth = myBorderWidth;
        
        for (UIButton *btn in self.contentView.subviews)
        {
            if ([btn isKindOfClass:[UIButton class]] && [btn.titleLabel.text isEqualToString:@"公告"])
            {
                if (btn.badge)
                {
                    [btn hidenBadge];
                }
            }
        }
        [[NnnbFacadeCenter defaultFacade] getPublicNotDataWithType:0 result:^(BOOL success, NSNotification *notifi) {
            if (success) {
                NSDictionary *dict = notifi.userInfo;
                NSInteger nums = [dict[@"nums"] integerValue];
                if (nums > 0) {
                    for (UIButton *btn in self.contentView.subviews) {
                        if ([btn.titleLabel.text isEqualToString:@"公告"]) {
                            [btn showBadgeWithCount:nums];
                        }
                    }
                }
            }
        }];
        [UIView animateWithDuration:showDuration animations:^{
            
            _contentView.alpha  = 1;
            
            if (self.frame.origin.x <= kScreenWidth/2) {
                [self resetContentview];
                
                self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, WIDTH + _imageArray.count * (self.frameWidth + marginWith) ,self.frameWidth);
            }else{
                
                [self moveContentviewLeft];
                
                self.mainImageButton.frame = CGRectMake((_imageArray.count * (self.frameWidth + marginWith)), 0, self.frameWidth, self.frameWidth);
                self.frame = CGRectMake(self.frame.origin.x  - _imageArray.count * (self.frameWidth + marginWith), self.frame.origin.y, (WIDTH + _imageArray.count * (self.frameWidth + marginWith)) ,self.frameWidth);
            }
            
            if (_bgcolor) {
                self.backgroundColor = _bgcolor;
            }else{
                self.backgroundColor = [UIColor whiteColor];
            }
        }];
        
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(changeStatus) object:nil];
    }else{
        self.isdepictTab = FALSE;
        
        [self animatedHiddenWindow];
        
        [self performSelector:@selector(changeStatus) withObject:nil afterDelay:statusChangeDuration];
    }
}




// 动画收起窗
- (void)animatedHiddenWindow {
    [UIView animateWithDuration:showDuration animations:^{
        _contentView.alpha  = 0;
        
        if (self.frame.origin.x + self.mainImageButton.frame.origin.x <= kScreenWidth/2) {
            self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frameWidth ,self.frameWidth);
        }else{
            self.mainImageButton.frame = CGRectMake(0, 0, self.frameWidth, self.frameWidth);
            self.frame = CGRectMake(self.frame.origin.x + _imageArray.count * (self.frameWidth + marginWith), self.frame.origin.y, self.frameWidth ,self.frameWidth);
        }
        
    } completion:^(BOOL finished) {
        self.layer.masksToBounds = NO;
        self.layer.borderWidth = 0;
        self.backgroundColor = [UIColor clearColor];
        
    }];
}

- (void)changeStatus
{
    [UIView animateWithDuration:1.0 animations:^{
        _mainImageButton.alpha = sleepAlpha;
    }];
    [UIView animateWithDuration:0.5 animations:^{
        CGFloat x = self.center.x < 20+WIDTH/2 ? 0 :  self.center.x > kScreenWidth - 20 -WIDTH/2 ? kScreenWidth : self.center.x;
        CGFloat y = 0;
        if (isIPhoneX) {
            y =  self.center.y < 40 + HEIGHT/2 ? _iDirection == 1 ? 0 : HEIGHT/2+_iXPortraitExt+_iXLandscapeExt : self.center.y > kScreenHeight - 40 - HEIGHT/2 ? kScreenHeight-_iXPortraitExt-_iXLandscapeExt- HEIGHT/2: self.center.y;
        }else{
            y =  self.center.y < 40 + HEIGHT/2 ? 0 : self.center.y > kScreenHeight - 40 - HEIGHT/2 ? kScreenHeight : self.center.y;
        }
        //禁止停留在4个角
        if(((x == 0 && y ==0) || (x == kScreenWidth && y == 0))&&isIPhoneX){
            y = HEIGHT/2+_iXLandscapeExt+_iXPortraitExt;
        }else if (((x == 0 && y == kScreenHeight) || (x == kScreenWidth && y == kScreenHeight))&&isIPhoneX)
        {
            y = self.center.y-HEIGHT/2-_iXLandscapeExt-_iXPortraitExt;
        }else if((x == 0 && y ==0) || (x == kScreenWidth && y == 0) || (x == 0 && y == kScreenHeight) || (x == kScreenWidth && y == kScreenHeight)){
            y = self.center.y;
        }
        self.center = CGPointMake(x, y);
    }];
}

- (void)doBorderWidth:(CGFloat)width color:(UIColor *)color cornerRadius:(CGFloat)cornerRadius{
    self.layer.cornerRadius = cornerRadius;
    self.layer.borderWidth = width;
    if (!color) {
        self.layer.borderColor = [UIColor whiteColor].CGColor;
    }else{
        self.layer.borderColor = color.CGColor;
    }
}

#pragma mark  ------- animation -------------

- (void)buttonAnimation{
    [_circleShape removeFromSuperlayer];
    
    self.layer.masksToBounds = NO;
    
    CGFloat scale = 1.0f;
    
    CGFloat width = self.mainImageButton.bounds.size.width, height = self.mainImageButton.bounds.size.height;
    
    CGFloat biggerEdge = width > height ? width : height, smallerEdge = width > height ? height : width;
    CGFloat radius = smallerEdge / 2 > WZFlashInnerCircleInitialRaius ? WZFlashInnerCircleInitialRaius : smallerEdge / 2;
    
    scale = biggerEdge / radius + 0.5;
    _circleShape = [self createCircleShapeWithPosition:CGPointMake(width/2, height/2)
                                              pathRect:CGRectMake(0, 0, radius * 2, radius * 2)
                                                radius:radius];
    
    [self.mainImageButton.layer addSublayer:_circleShape];
    
    CAAnimationGroup *groupAnimation = [self createFlashAnimationWithScale:scale duration:1.0f];
    
    [_circleShape addAnimation:groupAnimation forKey:nil];
}

- (void)stopAnimation{
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(buttonAnimation) object:nil];
    
    if (_circleShape) {
        [_circleShape removeFromSuperlayer];
    }
}

- (CAShapeLayer *)createCircleShapeWithPosition:(CGPoint)position pathRect:(CGRect)rect radius:(CGFloat)radius
{
    CAShapeLayer *circleShape = [CAShapeLayer layer];
    circleShape.path = [self createCirclePathWithRadius:rect radius:radius];
    circleShape.position = position;
    
    circleShape.bounds = CGRectMake(0, 0, radius * 2, radius * 2);
    circleShape.fillColor = _animationColor.CGColor;
    
    circleShape.opacity = 0;
    circleShape.lineWidth = 1;
    
    return circleShape;
}

- (CAAnimationGroup *)createFlashAnimationWithScale:(CGFloat)scale duration:(CGFloat)duration
{
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    scaleAnimation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(scale, scale, 1)];
    
    CABasicAnimation *alphaAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    alphaAnimation.fromValue = @1;
    alphaAnimation.toValue = @0;
    
    _animationGroup = [CAAnimationGroup animation];
    _animationGroup.animations = @[scaleAnimation, alphaAnimation];
    _animationGroup.duration = duration;
    _animationGroup.repeatCount = INFINITY;
    _animationGroup.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    
    return _animationGroup;
}


- (CGPathRef)createCirclePathWithRadius:(CGRect)frame radius:(CGFloat)radius
{
    return [UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:radius].CGPath;
}

#pragma mark  ------- button事件 ---------
- (void)itemsClick:(id)sender{
    if (self.isdepictTab){
        [self click:nil];
    }
    
    NSString *liStr = @"礼";
    NSString *bagStr = @"包";
    NSString *lgStr = [NSString stringWithFormat:@"%@%@",liStr,bagStr];
    
    UIButton *button = (UIButton *)sender;
    
    if ([button.titleLabel.text isEqualToString:@"账户"])
    {
        [MainWindow addSubview:self.userCenterController.view];
    }
    else if ([button.titleLabel.text isEqualToString:lgStr])
    {
        [MainWindow addSubview:self.packageViewController.view];
    }
    else if ([button.titleLabel.text isEqualToString:@"公告"])
    {
        [MainWindow addSubview:self.publicNotController.view];
    }
    else if ([button.titleLabel.text isEqualToString:@"客服"])
    {
        [MainWindow addSubview:self.customerController.view];
    }
    else if ([button.titleLabel.text isEqualToString:@"注销"])
    {
        [self logoutClickBtn];
    }
}

-(void)logoutClickBtn
{
    UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:@"确定要退出登录吗?"
                                                      delegate:self
                                             cancelButtonTitle:@"否"
                                             otherButtonTitles:@"是", nil];
    [alertView show];
    alertView.tag = LOGIN_OUT_BTN_TAG +1;
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == LOGIN_OUT_BTN_TAG +1)
    {
        if (buttonIndex == 1) {
            //确定
            [CommonData GetCommonDataInstance].randomAccReq = NO;
            [self removeWindow];
            
            [[DataManger getInstance] clear];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_LOGOUT_SUCCESS object:nil];
        }
    }
}

- (void)mainBtnTouchDown{
    if (!self.isdepictTab) {
        [self performSelector:@selector(buttonAnimation) withObject:nil afterDelay:0.5];
    }
}

- (void)adjustFloatWindowLocation{
    CGFloat minX = CGRectGetMinX(self.frame);
    CGFloat maxX = CGRectGetMaxX(self.frame);
    CGFloat minY = CGRectGetMinX(self.frame);
    CGFloat maxY = CGRectGetMaxY(self.frame);
    if (minX < 0) {
        self.tp_x = 0;
    }
    if (maxX > kScreenWidth){
        self.tp_right = kScreenWidth;
    }
    if (minY < 0) {
        self.tp_y = 0;
    }
    if (maxY > kScreenHeight) {
        self.tp_bottom = kScreenHeight;
    }
}

#pragma mark  ------- 设备旋转 -----------
- (void)willOrientChange:(NSNotification *)notification{
    //记录旋转前的位置
    self.lastPoint = self.frame.origin;
}

- (void)didOrientChange:(NSNotification *)notification{
    //重新刷新位置
    self.layer.masksToBounds = YES;
    if (self.lastPoint.x > [UIScreen mainScreen].bounds.size.width - 50/2 || self.lastPoint.y > [UIScreen mainScreen].bounds.size.height - 50/2) {
        [self adjustFloatWindowLocation];
    }else{
        self.tp_x = self.lastPoint.x;
        self.tp_y = self.lastPoint.y;
    }
    
    if (self.isdepictTab) {
        [self click:nil];
    }
    if (isIPhoneX) {
        CGPoint currentPoint = CGPointMake(self.tp_x, self.tp_y);
        [self reFreshWindowWithCurrentPoint:currentPoint];
    }

    
}

//旋转或者最后触摸时再次刷新window的位置
- (void)reFreshWindowWithCurrentPoint:(CGPoint )currentPoint{
    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    if(currentPoint.x <= kScreenWidth/2)
    {
        if(currentPoint.y <= 40+HEIGHT/2 && currentPoint.x >= 20+WIDTH/2)
        {
            [UIView animateWithDuration:animateDuration animations:^{
                self.center = CGPointMake(currentPoint.x, HEIGHT/2+_iXPortraitExt);
            }];
        }
        else if(currentPoint.y >= kScreenHeight-HEIGHT/2-40 && currentPoint.x >= 20+WIDTH/2)
        {
            [UIView animateWithDuration:animateDuration animations:^{
                self.center = CGPointMake(currentPoint.x, kScreenHeight-HEIGHT/2-_iXPortraitExt-_iXLandscapeExt);
            }];
        }
        else if (currentPoint.x < WIDTH/2+20 && currentPoint.y > kScreenHeight-HEIGHT/2)
        {
            [UIView animateWithDuration:animateDuration animations:^{
                self.center = CGPointMake(WIDTH/2+_iXLandscapeExt, kScreenHeight-HEIGHT/2-_iXPortraitExt);
            }];
        }
        else
        {
            CGFloat pointy = currentPoint.y < HEIGHT/2 ? HEIGHT/2 :currentPoint.y;
            [UIView animateWithDuration:animateDuration animations:^{
                if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
                    self.center = CGPointMake(WIDTH/2, pointy+_iXPortraitExt);
                }else{
                    self.center = CGPointMake(WIDTH/2+_iXLandscapeExt, pointy+_iXPortraitExt);
                }
            }];
        }
    }
    else if(currentPoint.x > kScreenWidth/2)
    {
        if(currentPoint.y <= 40+HEIGHT/2 && currentPoint.x < kScreenWidth-WIDTH/2-20 )
        {
            [UIView animateWithDuration:animateDuration animations:^{
                self.center = CGPointMake(currentPoint.x, HEIGHT/2+_iXPortraitExt);
            }];
        }
        else if(currentPoint.y >= kScreenHeight-40-HEIGHT/2 && currentPoint.x < kScreenWidth-WIDTH/2-20)
        {
            [UIView animateWithDuration:animateDuration animations:^{
                self.center = CGPointMake(currentPoint.x, kScreenHeight-HEIGHT/2-_iXPortraitExt-_iXLandscapeExt);
            }];
        }
        else if (currentPoint.x > kScreenWidth-WIDTH/2-20 && currentPoint.y < HEIGHT/2)
        {
            [UIView animateWithDuration:animateDuration animations:^{
                if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
                    self.center = CGPointMake(kScreenWidth-WIDTH/2-_iXLandscapeExt, HEIGHT/2+_iXPortraitExt);
                }else{
                    self.center = CGPointMake(kScreenWidth-WIDTH/2, HEIGHT/2+_iXPortraitExt);
                }
            }];
        }
        else
        {
            CGFloat pointy = currentPoint.y > kScreenHeight-HEIGHT/2 ? kScreenHeight-HEIGHT/2 :currentPoint.y;
            [UIView animateWithDuration:animateDuration animations:^{
                if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
                    self.center = CGPointMake(kScreenWidth-WIDTH/2-_iXLandscapeExt, pointy-_iXPortraitExt);
                }else{
                    self.center = CGPointMake(kScreenWidth-WIDTH/2, pointy-_iXPortraitExt);
                }
            }];
        }
    }
    
    
}
- (NnnbSTppCenterCtrl *)topUpCenterController{
    _topUpCenterController = [[NnnbSTppCenterCtrl alloc] init];
    return _topUpCenterController;
}

- (NnnbSLoginCtrl *)loginViewController{
    _loginViewController = [[NnnbSLoginCtrl alloc] init];
    return _loginViewController;
}

- (NnnbSUserCenterCtrl *)userCenterController{
    _userCenterController = [[NnnbSUserCenterCtrl alloc] init];
    return _userCenterController;
}

- (NnnbSBindPhoneCtrl *)bindPhoneController
{
    _bindPhoneController = [[NnnbSBindPhoneCtrl alloc] init];
    return _bindPhoneController;
}

- (NnnbSCustomerCtrl *)customerController{
    _customerController = [[NnnbSCustomerCtrl alloc] init];
    return _customerController;
}

- (NnnbSPublicNotCtrl *)publicNotController{
    _publicNotController = [[NnnbSPublicNotCtrl alloc] init];
    return _publicNotController;
}

- (NnnbSPackageCtrl *)packageViewController{
    _packageViewController = [[NnnbSPackageCtrl alloc] init];
    return _packageViewController;
}

- (NnnbSTppRecordCtrl *)topUpRecordViewController
{
    _topUpRecordViewController = [[NnnbSTppRecordCtrl alloc] init];
    return _topUpRecordViewController;
}

- (NnnbSFgPassWordViewCtrl *)fgPassWordViewController
{
    _fgPassWordViewController = [[NnnbSFgPassWordViewCtrl alloc] init];
    return _fgPassWordViewController;
}

- (NnnbSRegisterCtrl *)registerViewController
{
    _registerViewController = [[NnnbSRegisterCtrl alloc] init];
    return _registerViewController;
}

- (NnnbSFastRegisterCtrl *)fastRegisterViewController
{
    _fastRegisterViewController = [[NnnbSFastRegisterCtrl alloc] init];
    return _fastRegisterViewController;
}

- (NnnbSChangePswCtrl *)changePswViewController
{
    _changePswViewController = [[NnnbSChangePswCtrl alloc] init];
    return _changePswViewController;
}

- (NnnbSRealNameCheckCtrl *)realNameCheckViewController
{
    _realNameCheckViewController = [[NnnbSRealNameCheckCtrl alloc] init];
    return _realNameCheckViewController;
}

-(NnnbSBindPhoneCtrl *)bindPhoneViewController
{
    _bindPhoneViewController = [[NnnbSBindPhoneCtrl alloc] init];
    return _bindPhoneViewController;
}

-(NnnbSTelLoginVCtrl *)phoneViewController
{
    _phoneViewController = [[NnnbSTelLoginVCtrl alloc] init];
    return _phoneViewController;
}
@end
