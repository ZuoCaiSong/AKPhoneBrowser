//
//  NnnbSAccLevelUpCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSAccLevelUpCtrl.h"
#import "NnnbSAccLevelUpV.h"
#import "NnnbSBindPhoneCtrl.h"

@interface NnnbSAccLevelUpCtrl ()<NnnbSAccLevelUpVDelegate>
@property (nonatomic,strong) NnnbSAccLevelUpV *accLV;
@end

@implementation NnnbSAccLevelUpCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"账号升级" font:[UIFont systemFontOfSize:20]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWidth)/2, 2.5, titleWidth, 40)];
    title.text = @"账号升级";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictAccLevelUpV];
}

- (void)depictAccLevelUpV
{
    _accLV = [[NnnbSAccLevelUpV alloc] initWithFrame:CGRectMake(0, self.titleIg.tp_bottom, self.bgView.width, self.bgView.height-self.titleIg.tp_bottom)];
    _accLV.delegate = self;
    [self.bgView addSubview:_accLV];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbSAccLevelUpVDelegate
- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)popToUserCenterView
{
    [self popView];
    
    if (_delegate && [_delegate respondsToSelector:@selector(closeUserCenterView)]) {
        [_delegate closeUserCenterView];
    }
}

- (void)presentToBindPhoneView
{
    NnnbSBindPhoneCtrl *bindPhoneCtrl = [[NnnbSBindPhoneCtrl alloc] init];
    bindPhoneCtrl.closeBtnRemove = YES;
    bindPhoneCtrl.accLevelUpPresent = YES;
    [self presentViewController:bindPhoneCtrl animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
