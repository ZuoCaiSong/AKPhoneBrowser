//
//  NnnbSAccLevelUpV.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSAccLevelUpVDelegate <NSObject>

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

-(void)popToUserCenterView;

-(void)presentToBindPhoneView;

@end

@interface NnnbSAccLevelUpV : NnnbSSuperV
@property (nonatomic,weak) id<NnnbSAccLevelUpVDelegate> delegate;
@end
