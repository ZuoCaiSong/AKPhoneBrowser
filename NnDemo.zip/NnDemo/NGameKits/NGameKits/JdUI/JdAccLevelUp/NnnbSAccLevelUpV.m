//
//  NnnbSAccLevelUpV.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSAccLevelUpV.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbUserAccountManager.h"

#define off_Left 10
#define off_Top 10
#define FIELDBgHeight 40
#define getMesBtnWidth 110
#define UPDATA_COUNT 40

@interface NnnbSAccLevelUpV ()
@property (nonatomic,strong) UIView *levelUpBgV;
@property (nonatomic,strong) UIView *bindPhoneBgV;
@property (nonatomic,strong) NnnbTextField *accountField;
@property (nonatomic,strong) NnnbTextField *pswField;
@property (nonatomic,strong) NnnbTextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@end

@implementation NnnbSAccLevelUpV

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    if ([DataManger getInstance].currentUserInfo.isBind == 1)
    {
        [self createLevelUpView];
    }
    else
    {
        [self tipBindPhone];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(refreshView)
                                                 name:NOTIF_ACCOUNT_LEVELUP_REFRESH
                                               object:nil];
}

- (void)refreshView
{
    if (_bindPhoneBgV) {
        [_bindPhoneBgV removeFromSuperview];
        
        [self createLevelUpView];
    }
}

#pragma mark - 账号升级
- (void)createLevelUpView
{
    _levelUpBgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    [self addSubview:_levelUpBgV];
    
    NSArray *holderArr = @[@"请输入自定义账号",@"请输入密码",@"请输入验证码"];
    NSArray *imgArr = @[@"TygUser.png",@"TygPsw.png",@"TygMessage.png"];
    
    UIImage *bgImg = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    bgImg = [bgImg stretchableImageWithLeftCapWidth:bgImg.size.width/2 topCapHeight:bgImg.size.height/2];
    
    for (int i = 0; i < holderArr.count; i ++)
    {
        UIImageView *bgImgV = [[UIImageView alloc] initWithFrame:CGRectMake(off_Left, off_Top+i*(FIELDBgHeight+5), self.width - off_Left*2, FIELDBgHeight)];
        bgImgV.userInteractionEnabled = YES;
        bgImgV.image = bgImg;
        bgImgV.tag = 10+i;
        [_levelUpBgV addSubview:bgImgV];
        
        CGFloat fieldWidth = bgImgV.width;
        CGFloat fieldHeight = bgImgV.height;
        
        UIImageView *leftView = [[UIImageView alloc] init];
        leftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
        leftView.image = [UIImage nnGetPlatImage:imgArr[i]];
        [bgImgV addSubview:leftView];
        
        NnnbTextField *textfield = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        textfield.frame = CGRectMake(fieldHeight, 0.5, fieldWidth - fieldHeight - 10, fieldHeight-1);
        textfield.layer.cornerRadius = 6.0f;
        textfield.borderStyle = UITextBorderStyleNone;
        textfield.adjustsFontSizeToFitWidth = YES;
        textfield.delegate = self;
        textfield.placeholder = holderArr[i];
        textfield.font = [UIFont systemFontOfSize:15];
        textfield.tag = 100+i;
        [bgImgV addSubview:textfield];
        
        if (i == holderArr.count - 1)
        {
            textfield.returnKeyType = UIReturnKeyDone;
            textfield.keyboardType = UIKeyboardTypeNumberPad;
        }
        else
        {
            textfield.returnKeyType = UIReturnKeyNext;
            textfield.keyboardType = UIKeyboardTypeASCIICapable;
        }
        
        if (i == 1)
        {
            UIButton *eyeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            eyeBtn.frame = CGRectMake(fieldWidth - fieldHeight-5, fieldHeight/6, 2*fieldHeight/3, 2*fieldHeight/3);
            [eyeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygEyeO.png"] forState:UIControlStateNormal];
            [eyeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygEyeC.png"] forState:UIControlStateSelected];
            [eyeBtn addTarget:self action:@selector(eyeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            [bgImgV addSubview:eyeBtn];
        }
        
        if (i == 2)
        {
            UIButton *mesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            mesBtn.frame = CGRectMake(fieldWidth-getMesBtnWidth, 2, getMesBtnWidth, fieldHeight-4);
            [mesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            mesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:13];
            [mesBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
            [mesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
            mesBtn.tag = 1000;
            [bgImgV addSubview:mesBtn];
        }
    }
    
    UIImageView *accBgImgV = (UIImageView *)[self viewWithTag:10];
    UIImageView *pswBgImgV = (UIImageView *)[self viewWithTag:11];
    UIImageView *mesBgImgV = (UIImageView *)[self viewWithTag:12];
    
    _accountField = (NnnbTextField *)[accBgImgV viewWithTag:100];
    _pswField = (NnnbTextField *)[pswBgImgV viewWithTag:101];
    _mesField = (NnnbTextField *)[mesBgImgV viewWithTag:102];
    
    _getMesBtn = (UIButton *)[mesBgImgV viewWithTag:1000];
    
    UIImageView *tipImg = [[UIImageView alloc] initWithFrame:CGRectMake(mesBgImgV.left+5, mesBgImgV.tp_bottom+10, mesBgImgV.height-25, mesBgImgV.height-25)];
    tipImg.image = [UIImage nnGetPlatImage:@"TygTips.png"];
    [_levelUpBgV addSubview:tipImg];
    
    CGFloat tipLabWidth = [NnnbLabelSizeToFit getWidthWithtext:@"账号自定义升级后，可使用新账号登录" font:[UIFont systemFontOfSize:15]];
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake(tipImg.tp_right+5, tipImg.top, tipLabWidth, tipImg.height)];
    tipLab.text = @"账号自定义升级后，可使用新账号登录";
    tipLab.textColor = [UIColor lightGrayColor];
    tipLab.font = [UIFont systemFontOfSize:15];
    [_levelUpBgV addSubview:tipLab];
    
    UIButton *confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    confirmBtn.frame = CGRectMake(mesBgImgV.left, tipImg.tp_bottom+10, mesBgImgV.width, mesBgImgV.height);
    UIImage *img = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [confirmBtn setBackgroundImage:img forState:UIControlStateNormal];
    [confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
    confirmBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [confirmBtn addTarget:self action:@selector(confirmBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_levelUpBgV addSubview:confirmBtn];
}

#pragma mark - 密码是否可视
- (void)eyeBtnClick:(UIButton *)button
{
    if (button.selected == YES) {
        button.selected = NO;
        _pswField.secureTextEntry = NO;
    } else {
        button.selected = YES;
        _pswField.secureTextEntry = YES;
    }
}

#pragma mark - 获取验证码
-(void)getCheckBtnClick
{
    [_accountField resignFirstResponder];
    [_pswField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_accountField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text])
    {
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        return;
    }
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    //停止定时器
    [[NnnbFacade getInstance] verificationStopTimer];
    _getMesBtn.enabled = NO;
    
    //设置定时器参数
    [[NnnbFacade getInstance] verificationSetTimerPara:@selector(updateTimerHandler:) object:self];
    
    //开始定时器
    [[NnnbFacade getInstance] verificationStartTimer];
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForAccountLevelUp:_accountField.text result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            //提示
            NSString* strTips = @"验证码已发送";
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
        else {
            //停止定时器
            [[NnnbFacade getInstance] verificationStopTimer];
            _iUpdateCount = 0;
            _getMesBtn.enabled = YES;
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE]integerValue];
            if (iErr != 1011)
            {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}

- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        //超时
        [[NnnbFacade getInstance] verificationStopTimer];
        
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    }
    else
    {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后重新获取",(long)z] forState:UIControlStateNormal];
    }
}



#pragma mark - 确认
- (void)confirmBtnClick
{
    if ([_accountField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    //取消键盘
    [_accountField resignFirstResponder];
    [_pswField resignFirstResponder];
    [_mesField resignFirstResponder];
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] confirmAccountLevelUp:_accountField.text andPsd:_pswField.text messageCode:_mesField.text result:^(BOOL success, NSNotification *notifi) {
        //停止等待界面
        [self removeLoadView];
        if (success) {
            [self confirmVerifyCodeResultHandler:notifi];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];

}
- (void)confirmVerifyCodeResultHandler:(NSNotification*)notif{
    NSDictionary *dict = notif.userInfo[@"data"];
    [DataManger getInstance].systemInfo.strSessionId = dict[@"sessionid"];
    [NnnbTips depictCenterWithText:@"账号升级成功" duration:NN_TIPS_TIME3];
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    [keyChain nnStringSetObject:_accountField.text forKey:kUserName];
    [keyChain nnStringSetObject:_pswField.text forKey:kUserCode];
    
    [DataManger getInstance].currentUserInfo.strUserName = _accountField.text;
    [DataManger getInstance].currentUserInfo.strUserPassWord = _pswField.text;
    
    [CommonData GetCommonDataInstance].accState = 0;
    
    NSInteger index = [[NnnbUserAccountManager getInstance] getLoginAccounts].count;
    [[NnnbUserAccountManager getInstance] deleteAccountWithIndex:index-1];
    
    [self.delegate popToUserCenterView];
}


#pragma mark - 提示绑定手机
- (void)tipBindPhone
{
    _bindPhoneBgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    [self addSubview:_bindPhoneBgV];
    
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake(off_Left*2, self.height/4, self.width-off_Left*4, self.height/3)];
    tipLab.text = @"您尚未绑定手机。\n为了账号安全，请绑定后再进行账号升级！";
    tipLab.textColor = [UIColor lightGrayColor];
    tipLab.adjustsFontSizeToFitWidth = YES;
    tipLab.textAlignment = NSTextAlignmentCenter;
    tipLab.numberOfLines = 2;
    [_bindPhoneBgV addSubview:tipLab];
    
    UIButton *bindBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bindBtn.frame = CGRectMake(off_Left*2, self.height*3/4, self.width-off_Left*4, 40);
    UIImage *img = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [bindBtn setBackgroundImage:img forState:UIControlStateNormal];
    [bindBtn setTitle:@"去绑定" forState:UIControlStateNormal];
    bindBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [bindBtn addTarget:self action:@selector(bindBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_bindPhoneBgV addSubview:bindBtn];
}

- (void)bindBtnClick
{
    if (_delegate && [_delegate respondsToSelector:@selector(presentToBindPhoneView)]) {
        [_delegate presentToBindPhoneView];
    }
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewTop:120];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewBottom:120];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField) {
        [_accountField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else if (textField == _pswField){
        [_pswField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField){
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
