//
//  NnnbSBindPhoneV.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSBindPhoneV.h"
#import "NnnbFacade+bandPhoneUpdateTimer.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 20

#define UPDATA_COUNT 40

#define getMesBtnWidth 110

@interface NnnbSBindPhoneV ()
@property (nonatomic,strong) UIImageView *telFieldBgIv;
@property (nonatomic,strong) UIImageView *numFieldBgIv;
@property (nonatomic,strong) NnnbTextField *phoneField;
@property (nonatomic,strong) NnnbTextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,strong) UIButton *bindBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@property (nonatomic,copy) NSString *phoneStr;
@end

@implementation NnnbSBindPhoneV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    
    return self;
}

- (void)initView{
    UIImage *img = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    
    _telFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height, self.width - offLeft_x_width*2, 40)];
    _telFieldBgIv.userInteractionEnabled = YES;
    _telFieldBgIv.image = img;
    [self addSubview:_telFieldBgIv];
    
    CGFloat fieldWidth = _telFieldBgIv.width;
    CGFloat fieldHeight = _telFieldBgIv.height;
    
    //手机号--------------------------------------------------------
    UIImageView *phoneleftView = [[UIImageView alloc]init];
    phoneleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    phoneleftView.image = [UIImage nnGetPlatImage:@"TygPhone.png"];
    [_telFieldBgIv addSubview:phoneleftView];
    
    if (!_phoneField) {
        _phoneField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _phoneField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight-10, fieldHeight-1);
    }
    _phoneField.layer.cornerRadius = 6.0f;
    _phoneField.borderStyle = UITextBorderStyleNone;
    _phoneField.adjustsFontSizeToFitWidth = YES;
    _phoneField.delegate = self;
    _phoneField.placeholder = @"请输入手机号";
    _phoneField.font = [UIFont systemFontOfSize:15];
    _phoneField.returnKeyType = UIReturnKeyNext;
    _phoneField.keyboardType = UIKeyboardTypeNumberPad;
    [_telFieldBgIv addSubview:_phoneField];
    
    //验证码--------------------------------------------------------
    _numFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _telFieldBgIv.tp_bottom +20, self.width - offLeft_x_width*2, 40)];
    _numFieldBgIv.userInteractionEnabled = YES;
    _numFieldBgIv.image = img;
    [self addSubview:_numFieldBgIv];
    
    UIImageView *mesleftView = [[UIImageView alloc]init];
    mesleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    mesleftView.image = [UIImage nnGetPlatImage:@"TygMessage.png"];
    [_numFieldBgIv addSubview:mesleftView];
    
    if (!_mesField) {
        _mesField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _mesField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-10-fieldHeight, fieldHeight-1);
    }
    _mesField.layer.cornerRadius = 6.0f;
    _mesField.borderStyle = UITextBorderStyleNone;
    _mesField.adjustsFontSizeToFitWidth = YES;
    _mesField.delegate = self;
    _mesField.placeholder = @"请输入验证码";
    _mesField.font = [UIFont systemFontOfSize:15];
    _mesField.returnKeyType = UIReturnKeyDone;
    _mesField.keyboardType = UIKeyboardTypeNumberPad;
    [_numFieldBgIv addSubview:_mesField];
    
    //获取验证码
    if (!_getMesBtn) {
        _getMesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_getMesBtn];
    }
    _getMesBtn.frame = CGRectMake(fieldWidth-getMesBtnWidth, 2, getMesBtnWidth, fieldHeight-4);
    [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    _getMesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    [_getMesBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
    [_getMesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_numFieldBgIv addSubview:_getMesBtn];
    
    //绑定
    if (!_bindBtn) {
        _bindBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _bindBtn.frame = CGRectMake(_numFieldBgIv.left, _numFieldBgIv.tp_bottom+30, fieldWidth, 50);
    UIImage *img2 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img2 = [img2 stretchableImageWithLeftCapWidth:img2.size.width/2 topCapHeight:img2.size.height/2];
    [_bindBtn setBackgroundImage:img2 forState:UIControlStateNormal];
    [_bindBtn setTitle:@"绑     定" forState:UIControlStateNormal];
    _bindBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [_bindBtn addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_bindBtn];
}

#pragma mark - 获取验证码方法
- (void)getCheckBtnClick{
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入手机号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
    _getMesBtn.enabled = NO;
    
    //初始化定时器
    [[NnnbFacade getInstance] bandPhoneUpdateTimerSetTimerPara:@selector(updateTimerHandler:) object:self];
    [[NnnbFacade getInstance] bandPhoneUpdateTimerStartTimer];
    
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForUserBind:[DataManger getInstance].currentUserInfo.strUserName phone:_phoneField.text result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            NSString* strTips = @"验证码已发送";
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            
            _phoneStr = _phoneField.text;
        }
        else {
            [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
            _iUpdateCount = 0;
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            _getMesBtn.enabled = YES;
            
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE] integerValue];
            
            if (iErr != 1011)  {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}
#pragma mark - 倒计时
/****************************************************
 *  函数名:  updateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         (NSNumber *)iCount          倒计时时间
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    } else {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后重新获取", (long)z] forState:UIControlStateNormal];
    }
}

#pragma mark - 绑定手机方法
- (void)confirmClick{
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"手机号不能为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_phoneField.text isEqualToString:_phoneStr] && _phoneStr.length != 0) {
        [NnnbTips depictCenterWithText:@"手机号输入不一致" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(bindPhone) withObject:nil afterDelay:0.5];
}

- (void)bindPhone{
    [self conformButtonClick:_phoneField.text andyanzhengma:_mesField.text];
}

-(void)conformButtonClick:(NSString*)bindphoneN andyanzhengma:(NSString *)yanzhengma{
    [self depictLoadView];
    _phoneNum = bindphoneN;
    [[NnnbFacadeCenter defaultFacade] bindPhone:bindphoneN messageCode:yanzhengma result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [DataManger getInstance].currentUserInfo.isBind = YES;
            NSString *strTips = [NSString stringWithFormat:@"账号%@已成功绑定手机%@",
                                 [DataManger getInstance].currentUserInfo.strUserName,
                                 _phoneNum];
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            [self.delegate backToLastView];
            
            //刷新个人中心绑定手机
            [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_BINDPHONE_SUCCESS object:nil userInfo:nil];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}


#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _phoneField) {
        [_phoneField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _phoneField && string && string.length > 0 && ![NnnbCommons isNumber:string]){
        return NO;
    }
    
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
