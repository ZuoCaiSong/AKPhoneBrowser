//
//  NnnbSBindPhoneCtrl.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperVCtrl.h"
#import "NnnbSBindPhoneV.h"

@interface NnnbSBindPhoneCtrl : NnnbSSuperVCtrl<NnnbSBindPhoneVDelegate>
@property (nonatomic,assign) BOOL closeBtnRemove;
@property (nonatomic,assign) BOOL accLevelUpPresent;   //YES表示从账号升级页跳转过来的
@end
