//
//  NnnbSBindPhoneV.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSBindPhoneVDelegate <NSObject>

- (void)backToLastView;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbSBindPhoneV : NnnbSSuperV
@property (nonatomic,weak) id <NnnbSBindPhoneVDelegate> delegate;
@property (nonatomic,strong) NSString *phoneNum;
@end
