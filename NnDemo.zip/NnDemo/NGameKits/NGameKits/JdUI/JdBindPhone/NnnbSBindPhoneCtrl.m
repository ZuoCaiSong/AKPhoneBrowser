//
//  NnnbSBindPhoneCtrl.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSBindPhoneCtrl.h"

@interface NnnbSBindPhoneCtrl ()
@property (nonatomic,strong) NnnbSBindPhoneV *bindPhoneView;
@end

@implementation NnnbSBindPhoneCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.closeBtnRemove) {
        self.closeBtn.hidden = YES;
        [self.closeBtn removeFromSuperview];
    } else {
        self.backBtn.hidden = YES;
        [self.backBtn removeFromSuperview];
        [[NnnbSFloatW getInstance] removeWindow];
    }
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    title.text = @"绑定手机";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];

    [self.bgView addSubview:self.backBtn];
    
    [self depictBindPhoneView];
}

- (void)depictBindPhoneView{
    _bindPhoneView = [[NnnbSBindPhoneV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _bindPhoneView.delegate = self;
    [self.bgView addSubview:_bindPhoneView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbSBindPhoneVDelegate
- (void)backToLastView{
    if (self.closeBtnRemove) {
        [self popView];
        
        if (self.accLevelUpPresent) {
            self.accLevelUpPresent = NO;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIF_ACCOUNT_LEVELUP_REFRESH object:nil userInfo:nil];
        }
    } else {
        [[NnnbSFloatW getInstance] depictWindow];
        [self closeView];
    }
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
