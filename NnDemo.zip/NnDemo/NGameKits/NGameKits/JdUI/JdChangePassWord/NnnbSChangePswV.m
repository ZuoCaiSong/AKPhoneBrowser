//
//  NnnbSChangePswV.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSChangePswV.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 20

@interface NnnbSChangePswV ()
@property (nonatomic,strong) UIImageView *curPwdFieldBgIv;
@property (nonatomic,strong) UIImageView *nPwdFieldBgIv;
@property (nonatomic,strong) UIImageView *againPwdFieldBgIv;
@property (nonatomic,strong) NnnbTextField *oldPswField;
@property (nonatomic,strong) NnnbTextField *pswField;
@property (nonatomic,strong) NnnbTextField *againpswField;
@property (nonatomic,strong) UIButton *confirmBtn;
@end

@implementation NnnbSChangePswV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    UIImage *img = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    
    _curPwdFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, 10, self.width - offLeft_x_width*2, 40)];
    _curPwdFieldBgIv.userInteractionEnabled = YES;
    _curPwdFieldBgIv.image = img;
    [self addSubview:_curPwdFieldBgIv];
    
    CGFloat fieldWidth = _curPwdFieldBgIv.width;
    CGFloat fieldHeight = _curPwdFieldBgIv.height;
    
    //当前密码------------------------------------------
    UIImageView *oldPswleftView = [[UIImageView alloc]init];
    oldPswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    oldPswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_curPwdFieldBgIv addSubview:oldPswleftView];
    
    if (!_oldPswField) {
        _oldPswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _oldPswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight-10, fieldHeight-1);
    }
    _oldPswField.layer.cornerRadius = 6.0f;
    _oldPswField.borderStyle = UITextBorderStyleNone;
    _oldPswField.adjustsFontSizeToFitWidth = YES;
    _oldPswField.delegate = self;
    _oldPswField.placeholder = @"请输入旧密码";
    _oldPswField.font = [UIFont systemFontOfSize:15];
    _oldPswField.secureTextEntry = YES;
    _oldPswField.returnKeyType = UIReturnKeyNext;
    _oldPswField.keyboardType = UIKeyboardTypeASCIICapable;
    _oldPswField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_curPwdFieldBgIv addSubview:_oldPswField];
    
    _nPwdFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _curPwdFieldBgIv.tp_bottom + 10, self.width - offLeft_x_width*2, 40)];
    _nPwdFieldBgIv.userInteractionEnabled = YES;
    _nPwdFieldBgIv.image = img;
    [self addSubview:_nPwdFieldBgIv];
    //密码--------------------------------------------------------
    UIImageView *newPswleftView = [[UIImageView alloc]init];
    newPswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    newPswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_nPwdFieldBgIv addSubview:newPswleftView];
    
    if (!_pswField) {
        _pswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _pswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight-10, fieldHeight-1);
    }
    _pswField.layer.cornerRadius = 6.0f;
    _pswField.borderStyle = UITextBorderStyleNone;
    _pswField.adjustsFontSizeToFitWidth = YES;
    _pswField.delegate = self;
    _pswField.placeholder = @"请输入新密码";
    _pswField.font = [UIFont systemFontOfSize:15];
    _pswField.secureTextEntry = YES;
    _pswField.returnKeyType = UIReturnKeyNext;
    _pswField.keyboardType = UIKeyboardTypeASCIICapable;
    _pswField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_nPwdFieldBgIv addSubview:_pswField];
    
    _againPwdFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _nPwdFieldBgIv.tp_bottom + 10, self.width - offLeft_x_width*2, 40)];
    _againPwdFieldBgIv.userInteractionEnabled = YES;
    _againPwdFieldBgIv.image = img;
    [self addSubview:_againPwdFieldBgIv];
    
    //再次输入新密码
    UIImageView *againNewPswleftView = [[UIImageView alloc]init];
    againNewPswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    againNewPswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_againPwdFieldBgIv addSubview:againNewPswleftView];
    
    if (!_againpswField) {
        _againpswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _againpswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight -10, fieldHeight-1);
    }
    _againpswField.layer.cornerRadius = 6.0f;
    _againpswField.borderStyle = UITextBorderStyleNone;
    _againpswField.adjustsFontSizeToFitWidth = YES;
    _againpswField.delegate = self;
    _againpswField.placeholder = @"请再输入新密码";
    _againpswField.font = [UIFont systemFontOfSize:15];
    _againpswField.secureTextEntry = YES;
    _againpswField.returnKeyType = UIReturnKeyDone;
    _againpswField.keyboardType = UIKeyboardTypeASCIICapable;
    _againpswField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_againPwdFieldBgIv addSubview:_againpswField];
    
    //确认
    if (!_confirmBtn) {
        _confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _confirmBtn.frame = CGRectMake(offLeft_x_width, _againPwdFieldBgIv.tp_bottom + 20, self.width - offLeft_x_width*2, 50);
    UIImage *img2 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img2 = [img2 stretchableImageWithLeftCapWidth:img2.size.width/2 topCapHeight:img2.size.height/2];
    [_confirmBtn setBackgroundImage:img2 forState:UIControlStateNormal];
    [_confirmBtn setTitle:@"确     认" forState:UIControlStateNormal];
    _confirmBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [_confirmBtn addTarget:self action:@selector(confirmBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_confirmBtn];
}

#pragma mark - 确认按钮方法
- (void)confirmBtnClick{
    if ([_oldPswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入旧密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_oldPswField.text isEqualToString:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"新密码不能与旧密码相同" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_pswField.text isEqualToString:_againpswField.text])
    {
        [NnnbTips depictCenterWithText:@"两次密码不一致， 请重新输入!" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_oldPswField resignFirstResponder];
    [_pswField resignFirstResponder];
    [_againpswField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(confirm) withObject:nil afterDelay:0.5];
}

- (void)confirm {
    [self depictLoadView];

    [[NnnbFacadeCenter defaultFacade] changeOldPsd:_oldPswField.text andXinPsd:_pswField.text result:^(BOOL success, NSNotification *notifi) {
        //移除等待界面
        [self removeLoadView];
        if (success) {
            //返回上个界面
            [self.delegate backToLastView];
            
            NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
            int rPsw = [[keyChain kcObjectForKey:kRememberPsw] intValue];
            if (rPsw == 1) {
                //需要记住密码
                [keyChain nnStringSetObject:_pswField.text forKey:kUserCode];
            }
            else  {
                //不记住密码就把之前的旧密码数据清空
                [keyChain nnStringSetObject:@"" forKey:kUserCode];
            }
            [NnnbTips depictCenterWithText:@"修改密码成功" duration:NN_TIPS_TIME2];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}


#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _oldPswField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewTop:120];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _oldPswField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewBottom:120];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _oldPswField) {
        [_oldPswField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else if (textField == _pswField){
        [_pswField resignFirstResponder];
        [_againpswField becomeFirstResponder];
    } else {
        [_againpswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
