//
//  NnnbSChangePswV.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSChangePswVDelegate <NSObject>

- (void)backToLastView;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbSChangePswV : NnnbSSuperV<UITextFieldDelegate>
@property (nonatomic,weak) id <NnnbSChangePswVDelegate>delegate;
@end
