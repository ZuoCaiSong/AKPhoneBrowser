//
//  NnnbSPublicNotV.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSPublicNotV.h"
#import "NnnbSHistoryNotCl.h"

#define offTop 10
#define offleft 20

@implementation NnnbSPublicNotV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    _dataArr = [NSArray array];
    
    self.backgroundColor = [UIColor whiteColor];
    
    _btnView = [[UIView alloc] initWithFrame:CGRectMake((self.width/2)-100, offTop, 202, 37)];
    [self addSubview:_btnView];
    
    _newestNotView = [[UIView alloc] initWithFrame:CGRectMake(offleft, _btnView.top+_btnView.height+10, self.width-offleft*2, self.height-_btnView.height-offTop*3)];
    [self addSubview:_newestNotView];
    
    _historyNotView = [[UIView alloc] initWithFrame:CGRectMake(_newestNotView.left,_newestNotView.top,_newestNotView.width,_newestNotView.height)];
    _historyNotView.hidden = YES;
    [self addSubview:_historyNotView];
    
    UIImage *leftSel = [UIImage nnGetPlatImage:@"Tyg_leftSel_tab.png"];
    leftSel = [leftSel stretchableImageWithLeftCapWidth:leftSel.size.width/2 topCapHeight:leftSel.size.height/2];
    
    UIImage *leftNor = [UIImage nnGetPlatImage:@"Tyg_leftNor_tab.png"];
    leftNor = [leftNor stretchableImageWithLeftCapWidth:leftNor.size.width/2 topCapHeight:leftNor.size.height/2];
    
    UIImage *rightSel = [UIImage nnGetPlatImage:@"Tyg_rightSel_tab.png"];
    rightSel = [rightSel stretchableImageWithLeftCapWidth:rightSel.size.width/2 topCapHeight:rightSel.size.height/2];
    
    UIImage *rightNor = [UIImage nnGetPlatImage:@"Tyg_rightNor_tab.png"];
    rightNor = [rightNor stretchableImageWithLeftCapWidth:rightNor.size.width/2 topCapHeight:rightNor.size.height/2];
    
    NSArray *titleArr = @[@"最新消息",@"历史公告"];
    
    for (int i = 0; i < titleArr.count; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(1+(i%2)*100, 1, 100, 35);
        btn.tag = 100+i;
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:15];
        if (btn.tag == 100) {
            btn.selected = YES;
            
            [btn setBackgroundImage:leftNor forState:UIControlStateNormal];
            [btn setBackgroundImage:leftSel forState:UIControlStateSelected];
        } else {
            [btn setBackgroundImage:rightNor forState:UIControlStateNormal];
            [btn setBackgroundImage:rightSel forState:UIControlStateSelected];
        }
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_btnView addSubview:btn];
    }
    
    [self requestPublicNotData];
}

- (void)btnClick:(UIButton *)btn{
    for (UIButton *button in _btnView.subviews) {
        if (button.tag == btn.tag) {
            button.selected = YES;
        } else {
            button.selected = NO;
        }
    }
    
    if (btn.tag == 100) {
        _newestNotView.hidden = NO;
        _historyNotView.hidden = YES;
    } else {
        _historyNotView.hidden = NO;
        _newestNotView.hidden = YES;
        
        if (_dataArr.count != 0) {
            if (!_historyTableView) {
                [self initHistoryNotView];
            }
        } else {
            [NnnbTips depictCenterWithText:@"暂无历史公告!" duration:NN_TIPS_TIME2];
        }
    }
    
}

#pragma mark - 请求公告数据
- (void)requestPublicNotData{
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] getPublicNotDataWithType:1 result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            NSDictionary *dict = notifi.userInfo;
            
            if (dict[@"data"] && [dict[@"data"] isKindOfClass:[NSArray class]]) {
                _dataArr = dict[@"data"];
                
                if (_dataArr.count != 0) {
                    [self initnewestNotView];
                } else {
                    [self removeLoadView];
                    [NnnbTips depictCenterWithText:@"暂无公告信息" duration:NN_TIPS_TIME3];
                }
            } else {
                [self removeLoadView];
                [NnnbTips depictCenterWithText:@"暂无公告信息" duration:NN_TIPS_TIME3];
            }
        }
        else {
            [self removeLoadView];
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
    
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    NSString *times = [NSString stringWithFormat:@"%f",time];
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    [keyChain kcSetObject:times forKey:@"times"];
}

#pragma mark - 最新消息
- (void)initnewestNotView{
    NSDictionary *dict = [_dataArr objectAtIndex:0];
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:dict[@"URL"]]];
    
     _ggwebview = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, _newestNotView.width, _newestNotView.height)];
    _ggwebview.UIDelegate = self;
    _ggwebview.navigationDelegate = self;
    _ggwebview.scrollView.bounces = NO;
    [_newestNotView addSubview:_ggwebview];
    
    //进度监听
    [_ggwebview addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:NULL];
    [_ggwebview loadRequest:request];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        if ([change[@"new"] floatValue] == 1.0) {
            [self removeLoadView];
        }
    }
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [self removeLoadView];
    NSDictionary *dict = [_dataArr objectAtIndex:0];
    
    NSInteger read = [[dict objectForKey:@"read"] integerValue];
    NSInteger noticeID = [[dict objectForKey:@"notice_id"] integerValue];
    
    if (read == 0)
    {
        [[NnnbFacadeCenter defaultFacade] haveReadPublicNot:noticeID result:^(BOOL success, NSNotification *notifi) {
            
        }];
    }
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    [self removeLoadView];
    [NnnbTips depictCenterWithText:@"加载失败" duration:NN_TIPS_TIME2];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated)
    {
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
        
        decisionHandler(WKNavigationActionPolicyCancel);
    }
    else
    {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

#pragma mark - 历史公告
- (void)initHistoryNotView{
    [self removeLoadView];
    
    _historyTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _historyNotView.width, _historyNotView.height) style:UITableViewStylePlain];
    _historyTableView.delegate = self;
    _historyTableView.dataSource = self;
    _historyTableView.showsVerticalScrollIndicator = NO;
    _historyTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _historyTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [_historyNotView addSubview:_historyTableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count-1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"historyNotCell";
    
    NnnbSHistoryNotCl *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if(cell == nil){
        cell = [[NnnbSHistoryNotCl alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row+1];
    NSInteger read = [[dict objectForKey:@"read"] integerValue];
    
    cell.titleLab.text = dict[@"Title"];
    
    NSArray *array = [dict[@"tdate"] componentsSeparatedByString:@" "];
    cell.dateLab.text = array[0];
    
    if (read == 0) {
        cell.titleLab.textColor = [UIColor redColor];
        cell.dateLab.textColor = [UIColor redColor];
    } else {
        cell.titleLab.textColor = [UIColor blackColor];
        cell.dateLab.textColor = [UIColor blackColor];
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row+1];
    _index = indexPath.row+1;
    
    [self.delegate presentHistoryNotViewWithDict:dict];
}

- (void)requestDataToReload{
    NSDictionary *dict = [_dataArr objectAtIndex:_index];
    NSInteger read = [[dict objectForKey:@"read"] integerValue];
    
    if (read == 0) {
        [self depictLoadView];
        [[NnnbFacadeCenter defaultFacade] getPublicNotDataWithType:1 result:^(BOOL success, NSNotification *notifi) {
            [self removeLoadView];
            if (success) {
                NSDictionary *dict = notifi.userInfo;
                if (dict[@"data"] && [dict[@"data"] isKindOfClass:[NSArray class]]) {
                    _dataArr = dict[@"data"];
                    [_historyTableView reloadData];
                }
            }
            else {
                NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                
                [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
            }
        }];
    }
}
- (void)dealloc {
    [_ggwebview removeObserver:self forKeyPath:@"estimatedProgress" ];
}

@end
