//
//  NnnbSHistoryNotCl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSHistoryNotCl.h"

#define dataLabWidth 80

@implementation NnnbSHistoryNotCl

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        _titleLab = [[UILabel alloc] init];
        _titleLab.textAlignment = UITextAlignmentLeft;
        _titleLab.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:_titleLab];
        
        _line = [[UIImageView alloc] init];
        _line.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_line];
        
        _dateLab = [[UILabel alloc] init];
        _dateLab.textColor = [UIColor lightGrayColor];
        _dateLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_dateLab];
    }
    
    return self;
}

- (void)layoutSubviews{
    _titleLab.frame = CGRectMake(0, 0, self.width-dataLabWidth-10, 40);
    _line.frame = CGRectMake(0, _titleLab.top+_titleLab.height-1, self.width, 1);
    _dateLab.frame = CGRectMake(_titleLab.left+_titleLab.width+10, _titleLab.top+10, dataLabWidth, 20);
}

@end
