//
//  NnnbSHistoryNotCtrl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperVCtrl.h"

@protocol NnnbSHistoryNotViewCtrlDelegate <NSObject>
- (void)reloadData;
@end

@interface NnnbSHistoryNotCtrl : NnnbSSuperVCtrl<UIWebViewDelegate>
@property (nonatomic,strong) NSDictionary *dict;
@property (nonatomic,weak) id<NnnbSHistoryNotViewCtrlDelegate> delegate;
@end
