//
//  NnnbSPublicNotCtrl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperVCtrl.h"
#import "NnnbSPublicNotV.h"
#import "NnnbSHistoryNotCtrl.h"

@interface NnnbSPublicNotCtrl : NnnbSSuperVCtrl<NnnbSPublicNotVDelegate,NnnbSHistoryNotViewCtrlDelegate>
@property (nonatomic,strong) NnnbSPublicNotV *publicNotView;
@property (nonatomic,strong) NnnbSHistoryNotCtrl *historyNotViewController;
@end
