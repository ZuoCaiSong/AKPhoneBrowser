//
//  NnnbSPublicNotV.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperV.h"
#import <WebKit/WebKit.h>

@protocol NnnbSPublicNotVDelegate <NSObject>

-(void)presentHistoryNotViewWithDict:(NSDictionary *)dict;

@end

@interface NnnbSPublicNotV : NnnbSSuperV<UITableViewDelegate,UITableViewDataSource,WKUIDelegate,WKNavigationDelegate>
@property (nonatomic,strong) UIView *btnView;
@property (nonatomic,strong) UIView *newestNotView;
@property (nonatomic,strong) UIView *historyNotView;
@property (nonatomic,strong) NSArray *dataArr;
@property (nonatomic,strong) WKWebView *ggwebview;
@property (nonatomic,strong) UITableView *historyTableView;
@property (nonatomic,weak) id<NnnbSPublicNotVDelegate> delegate;
@property (nonatomic,assign) NSInteger index;

- (void)requestDataToReload;
@end
