//
//  NnnbSHistoryNotCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSHistoryNotCtrl.h"
#import <WebKit/WebKit.h>

@interface NnnbSHistoryNotCtrl ()<WKUIDelegate,WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *historyNotWebView;
@end

@implementation NnnbSHistoryNotCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.bgView.backgroundColor = [UIColor whiteColor];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    [[NnnbSFloatW getInstance] removeWindow];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    title.text = @"历史公告";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.backBtn addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.backBtn];
    
    [self depictHistoryNotView];
}

- (void)backBtnClick{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    [self.delegate reloadData];
}

- (void)depictHistoryNotView{
    _historyNotWebView = [[WKWebView alloc] initWithFrame:CGRectMake(10, 60, self.bgView.width-10*2, self.bgView.height-self.titleIg.height-10*2)];
    _historyNotWebView.scrollView.bounces = NO;
    _historyNotWebView.UIDelegate = self;
    _historyNotWebView.navigationDelegate = self;
    [self.bgView addSubview:_historyNotWebView];
    [self.view addSubview:self.bgView];
    
    //进度监听
    [_historyNotWebView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:NULL];
    
    NSString *urlStr = _dict[@"URL"];
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    [_historyNotWebView loadRequest:request];
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    [self depictLoadView];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        if ([change[@"new"] floatValue] == 1.0) {
            [self removeLoadView];
        }
    }
}

-(void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [self removeLoadView];
    NSInteger read = [[_dict objectForKey:@"read"] integerValue];
    NSInteger noticeID = [[_dict objectForKey:@"notice_id"] integerValue];
    
    if (read == 0) {
        [[NnnbFacadeCenter defaultFacade] haveReadPublicNot:noticeID result:^(BOOL success, NSNotification *notifi) {
            
        }];
    }
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    [self removeLoadView];
    [NnnbTips depictCenterWithText:@"加载失败" duration:NN_TIPS_TIME2];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated)
    {
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
        
        decisionHandler(WKNavigationActionPolicyCancel);
    }
    else
    {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}
- (void)dealloc {
    [_historyNotWebView removeObserver:self forKeyPath:@"estimatedProgress" ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
