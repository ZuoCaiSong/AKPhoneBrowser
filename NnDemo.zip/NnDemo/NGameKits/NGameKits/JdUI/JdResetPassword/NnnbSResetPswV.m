//
//  NnnbSResetPswV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSResetPswV.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 15

#define FIELDBgHeight 40

@interface NnnbSResetPswV ()
@property (nonatomic,strong) UIImageView *fFieldBgIv;
@property (nonatomic,strong) UIImageView *sFieldBgIv;
@property (nonatomic,strong) NnnbTextField *pswField;
@property (nonatomic,strong) NnnbTextField *againpswField;
@property (nonatomic,strong) UIButton *confirmBtn;

@end

@implementation NnnbSResetPswV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    UIImage *img = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    
    _fFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _fFieldBgIv.userInteractionEnabled = YES;
    _fFieldBgIv.image = img;
    [self addSubview:_fFieldBgIv];
    
    CGFloat fieldWidth = _fFieldBgIv.width;
    CGFloat fieldHeight = FIELDBgHeight;
    
    //输入新密码
    UIImageView *newPswleftView = [[UIImageView alloc]init];
    newPswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    newPswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_fFieldBgIv addSubview:newPswleftView];
    
    if (!_pswField) {
        _pswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _pswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight-10, fieldHeight-1);
    }
    _pswField.layer.cornerRadius = 6.0f;
    _pswField.borderStyle = UITextBorderStyleNone;
    _pswField.adjustsFontSizeToFitWidth = YES;
    _pswField.delegate = self;
    _pswField.placeholder = @"请输入新密码";
    _pswField.font = [UIFont systemFontOfSize:15];
    _pswField.secureTextEntry = YES;
    _pswField.returnKeyType = UIReturnKeyNext;
    _pswField.keyboardType = UIKeyboardTypeASCIICapable;
    _pswField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_fFieldBgIv addSubview:_pswField];

    //再次输入新密码
    _sFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _fFieldBgIv.tp_bottom + 15, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _sFieldBgIv.userInteractionEnabled = YES;
    _sFieldBgIv.image = img;
    [self addSubview:_sFieldBgIv];
    
    UIImageView *againNewPswleftView = [[UIImageView alloc]init];
    againNewPswleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    againNewPswleftView.image = [UIImage nnGetPlatImage:@"TygPsw.png"];
    [_sFieldBgIv addSubview:againNewPswleftView];
    
    if (!_againpswField) {
        _againpswField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _againpswField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth-fieldHeight-10, fieldHeight-1);
    }
    _againpswField.layer.cornerRadius = 6.0f;
    _againpswField.borderStyle = UITextBorderStyleNone;
    _againpswField.adjustsFontSizeToFitWidth = YES;
    _againpswField.delegate = self;
    _againpswField.placeholder = @"请再输入新密码";
    _againpswField.font = [UIFont systemFontOfSize:15];
    _againpswField.secureTextEntry = YES;
    _againpswField.returnKeyType = UIReturnKeyDone;
    _againpswField.keyboardType = UIKeyboardTypeASCIICapable;
    _againpswField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_sFieldBgIv addSubview:_againpswField];
    
    //确认
    if (!_confirmBtn) {
        _confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _confirmBtn.frame = CGRectMake(_sFieldBgIv.left, _sFieldBgIv.top+_sFieldBgIv.height+35, fieldWidth, 50);
    UIImage *img2 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img2 = [img2 stretchableImageWithLeftCapWidth:img2.size.width/2 topCapHeight:img2.size.height/2];
    [_confirmBtn setBackgroundImage:img2 forState:UIControlStateNormal];
    [_confirmBtn setTitle:@"确     定" forState:UIControlStateNormal];
    _confirmBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [_confirmBtn addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_confirmBtn];
}

#pragma mark - 确认按钮方法
- (void)confirmClick{
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_pswField.text isEqualToString:_againpswField.text])
    {
        [NnnbTips depictCenterWithText:@"两次密码不一致， 请重新输入!" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    [_pswField resignFirstResponder];
    [_againpswField resignFirstResponder];
    
    [self conformBtnClicknPsw:_againpswField.text];
}

- (void)conformBtnClicknPsw:(NSString *)nPsw {
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] resetPassword:self.strPhone account:self.strAccount messageCode:self.strMes andPsd:nPsw result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [NnnbTips depictCenterWithText:@"重置密码成功" duration:NN_TIPS_TIME2];
            [self.delegate backToLastView];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
        
    }];
    
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _pswField) {
        [_pswField resignFirstResponder];
        [_againpswField becomeFirstResponder];
    } else {
        [_againpswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
