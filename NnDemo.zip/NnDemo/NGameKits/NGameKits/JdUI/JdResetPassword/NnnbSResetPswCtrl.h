//
//  NnnbSResetPswCtrl.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperVCtrl.h"
#import "NnnbSResetPswV.h"

@protocol NnnbSResetPswCtrlDelegate <NSObject>

- (void)backTolastView;

@end

@interface NnnbSResetPswCtrl : NnnbSSuperVCtrl<NnnbSResetPswVDelegate>
{
    NnnbSResetPswV *_resetPswView;
}
//账号
@property(nonatomic, copy) NSString* strAccount;

//手机号码
@property(nonatomic, copy) NSString* strPhone;

//验证码
@property(nonatomic, copy) NSString* strMes;

@property(nonatomic,weak)id<NnnbSResetPswCtrlDelegate> delegate;
@end
