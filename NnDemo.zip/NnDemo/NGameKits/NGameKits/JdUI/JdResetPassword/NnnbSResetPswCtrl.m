//
//  NnnbSResetPswCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSResetPswCtrl.h"
#import "NnnbSRegisterCtrl.h"

@interface NnnbSResetPswCtrl ()

@end

@implementation NnnbSResetPswCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    [self depictResetPswView];
}

-(void)initTitle
{
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"重置密码" font:[UIFont systemFontOfSize:20]];
    UILabel *title  = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width - titleWidth)/2, 2.5, titleWidth, 40)];
    title.text = @"重置密码";
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
}

- (void)depictResetPswView{
    _resetPswView = [[NnnbSResetPswV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _resetPswView.delegate = self;
    _resetPswView.strAccount = self.strAccount;
    _resetPswView.strPhone = self.strPhone;
    _resetPswView.strMes = self.strMes;
    [self.bgView addSubview:_resetPswView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbSResetPswVDelegate
- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)backToLastView{
    [self popView];
    [self.delegate backTolastView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
