//
//  NnnbSPackageCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSPackageCtrl.h"
#import "NnnbSPackageContentCtrl.h"
#import "NnnbSTakenPackageCtrl.h"

@interface NnnbSPackageCtrl ()
@property (nonatomic,strong) NnnbSPackageV *packageView;
@property (nonatomic,strong) NnnbSPackageContentCtrl *packageContentVc;
@property (nonatomic,strong) NnnbSPackageCodeCtrl *packageCodeVc;
@property (nonatomic,strong) NnnbSTakenPackageCtrl *takenPackageVc;
@end

@implementation NnnbSPackageCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.bgView.backgroundColor = [UIColor whiteColor];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    [[NnnbSFloatW getInstance] removeWindow];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    NSString *liStr = @"礼";
    NSString *baoStr = @"包";
    title.text = [NSString stringWithFormat:@"%@%@",liStr,baoStr];
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.bgView addSubview:self.closeBtn];
    
    [self depictpackageView];
}

- (void)depictpackageView{
    _packageView = [[NnnbSPackageV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.frame.size.width, self.bgView.frame.size.height-45)];
    _packageView.delegate = self;
    [self.bgView addSubview:_packageView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - NnnbSPackageVDelegate
- (void)presentToPackageContentViewWithDict:(NSDictionary *)dict Img:(UIImage *)img{
    _packageContentVc = [[NnnbSPackageContentCtrl alloc] init];
    _packageContentVc.packageDict = dict;
    _packageContentVc.img = img;
    [self presentViewController:_packageContentVc animated:YES completion:nil];
}

- (void)presentToPackageCodeViewWithCode:(NSString *)codeStr{
    _packageCodeVc = [[NnnbSPackageCodeCtrl alloc] init];
    _packageCodeVc.codeStr = codeStr;
    _packageCodeVc.delegate = self;
    [self presentViewController:_packageCodeVc animated:YES completion:nil];
}

- (void)presentToTakenPackageViewWithDict:(NSDictionary *)dict{
    _takenPackageVc = [[NnnbSTakenPackageCtrl alloc] init];
    _takenPackageVc.dict = dict;
    [self presentViewController:_takenPackageVc animated:YES completion:nil];
}

#pragma mark - NnnbSPackageCodeCtrlDelegate
- (void)reloadData{
    if (_packageView.packageTableView) {
        [_packageView requestDataToReload];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
