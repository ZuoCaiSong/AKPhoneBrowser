//
//  NnnbSPackageContentCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSPackageContentCtrl.h"

@interface NnnbSPackageContentCtrl ()

@end

@implementation NnnbSPackageContentCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 5, 180, 40)];
    NSString *liStr = @"礼";
    NSString *baoStr = @"包";
    NSString *neirongStr = @"内容";
    title.text = [NSString stringWithFormat:@"%@%@%@",liStr,baoStr,neirongStr];
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.bgView addSubview:self.backBtn];
    [self.view addSubview:self.bgView];
    
    [self depictPackageContentView];
}

- (void)depictPackageContentView{
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 60, 60, 60)];
    icon.image = self.img;
    [self.bgView addSubview:icon];
    
    UILabel *nameLab = [[UILabel alloc] initWithFrame:CGRectMake(icon.left+icon.width, icon.top, 200, 20)];
    nameLab.text = _packageDict[@"name"];
    nameLab.font = [UIFont systemFontOfSize:15];
    [self.bgView addSubview:nameLab];
    
    UILabel *numLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.left+10, nameLab.top+nameLab.height, nameLab.width, nameLab.height)];
    numLab.text = [NSString stringWithFormat:@"剩余:%@",_packageDict[@"num"]];
    numLab.font = [UIFont systemFontOfSize:14];
    [self.bgView addSubview:numLab];
    
    UILabel *endDateLab = [[UILabel alloc] initWithFrame:CGRectMake(nameLab.left+10, numLab.top+numLab.height, nameLab.width, nameLab.height)];
    endDateLab.text = [NSString stringWithFormat:@"截止日期:%@",_packageDict[@"e_date"]];
    endDateLab.font = [UIFont systemFontOfSize:14];
    [self.bgView addSubview:endDateLab];
    
    UILabel *contentLab = [[UILabel alloc] initWithFrame:CGRectMake(icon.left, icon.top+icon.height+10, 70, 20)];
    contentLab.layer.masksToBounds = YES;
    contentLab.layer.cornerRadius = 6.0f;
    contentLab.backgroundColor = [UIColor lightGrayColor];
    contentLab.textColor = [UIColor whiteColor];
    contentLab.textAlignment = UITextAlignmentCenter;
    NSString *liStr = @"礼";
    NSString *baoStr = @"包";
    NSString *neirongStr = @"内容";
    contentLab.text = [NSString stringWithFormat:@"%@%@%@",liStr,baoStr,neirongStr];
    contentLab.font = [UIFont systemFontOfSize:13];
    [self.bgView addSubview:contentLab];
    
    UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(icon.left, contentLab.top+contentLab.height+5, self.bgView.width-icon.left*2, 40)];
    content.font = [UIFont systemFontOfSize:13];
    content.numberOfLines = 0;
    content.text = _packageDict[@"content"];
    [self.bgView addSubview:content];
    
    UILabel *usageLab = [[UILabel alloc] initWithFrame:CGRectMake(icon.left, content.top+content.height+5, contentLab.width, contentLab.height)];
    usageLab.layer.masksToBounds = YES;
    usageLab.layer.cornerRadius = 6.0f;
    usageLab.backgroundColor = [UIColor lightGrayColor];
    usageLab.textColor = [UIColor whiteColor];
    usageLab.text = @"使用方式";
    usageLab.textAlignment = UITextAlignmentCenter;
    usageLab.font = [UIFont systemFontOfSize:13];
    [self.bgView addSubview:usageLab];
    
    UILabel *usage = [[UILabel alloc] initWithFrame:CGRectMake(icon.left, usageLab.top+usageLab.height+5, self.bgView.width-icon.left*2, 30)];
    usage.font = [UIFont systemFontOfSize:13];
    usage.text = _packageDict[@"usage"];
    [self.bgView addSubview:usage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
