//
//  NnnbSPackageCl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSPackageCl.h"

@implementation NnnbSPackageCl

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        _icon = [[UIImageView alloc] init];
        [self.contentView addSubview:_icon];
        
        NSInteger direction = [[CommonData GetCommonDataInstance] judgeDirection];
        _name = [[UILabel alloc] init];
        _name.font = [UIFont systemFontOfSize:16];
        if (direction != 1) {
            if(isIPhone55S5CSE){
                _name.font = [UIFont systemFontOfSize:14];
            }
        }
        [self.contentView addSubview:_name];
        
        _takeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:_takeBtn];
        
        _content = [[UILabel alloc] init];
        _content.textColor = [UIColor lightGrayColor];
        _content.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_content];
        
        _endDate = [[UILabel alloc] init];
        _endDate.textColor = [UIColor lightGrayColor];
        _endDate.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_endDate];
        
        _num = [[UILabel alloc] init];
        _num.textAlignment = UITextAlignmentRight;
        _num.textColor = [UIColor lightGrayColor];
        _num.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_num];
        
        _line = [[UIImageView alloc] init];
        _line.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_line];
    }
    
    return self;
}

- (void)layoutSubviews{
    _icon.frame = CGRectMake(10, 0, 50, 50);
    
    _name.frame = CGRectMake(_icon.left+_icon.width, _icon.top+5, self.contentView.width-(_icon.left+_icon.width+95), 40);
    
    _takeBtn.frame = CGRectMake(self.contentView.width-90, _name.top+5, 80, 30);
    
    _content.frame = CGRectMake(_icon.left, _icon.top+_icon.height+5, self.contentView.width-_icon.left*2, 25);
    
    _endDate.frame = CGRectMake(_content.left, _content.top+_content.height, 160, _content.height);
    
    _num.frame = CGRectMake(self.contentView.width-100-10, _endDate.top, 100, _endDate.height);
    
    _line.frame = CGRectMake(0, _endDate.top+_endDate.height+9, self.contentView.width, 1);
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
