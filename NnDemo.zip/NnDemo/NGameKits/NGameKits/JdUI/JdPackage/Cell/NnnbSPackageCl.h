//
//  NnnbSPackageCl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NnnbSPackageCl : UITableViewCell
@property (nonatomic,strong) UIImageView *icon;
@property (nonatomic,strong) UILabel *name;
@property (nonatomic,strong) UIButton *takeBtn;
@property (nonatomic,strong) UILabel *content;
@property (nonatomic,strong) UILabel *endDate;
@property (nonatomic,strong) UILabel *num;
@property (nonatomic,strong) UIImageView *line;
@property (nonatomic) BOOL isSelected;
@end
