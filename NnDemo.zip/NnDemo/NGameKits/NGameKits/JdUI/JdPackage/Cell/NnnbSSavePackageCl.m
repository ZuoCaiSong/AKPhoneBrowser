//
//  NnnbSSavePackageCl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSavePackageCl.h"

@implementation NnnbSSavePackageCl

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        _nameLab = [[UILabel alloc] init];
        _nameLab.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:_nameLab];
        
        _endDateLab = [[UILabel alloc] init];
        _endDateLab.textColor = [UIColor lightGrayColor];
        _endDateLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_endDateLab];
        
        _contentLab = [[UILabel alloc] init];
        _contentLab.textColor = [UIColor lightGrayColor];
        _contentLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_contentLab];
        
        _line = [[UIImageView alloc] init];
        _line.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_line];
    }
    return self;
}

- (void)layoutSubviews{
    _nameLab.frame = CGRectMake(10, 0, self.contentView.width-10*2, 30);
    
    _endDateLab.frame = CGRectMake(_nameLab.left, _nameLab.top+_nameLab.height, _nameLab.width, 20);
    
    _contentLab.frame = CGRectMake(_endDateLab.left, _endDateLab.top+_endDateLab.height+5, _nameLab.width, _endDateLab.height);
    
    _line.frame = CGRectMake(0, _contentLab.top+_contentLab.height+4, self.contentView.width, 1);
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
