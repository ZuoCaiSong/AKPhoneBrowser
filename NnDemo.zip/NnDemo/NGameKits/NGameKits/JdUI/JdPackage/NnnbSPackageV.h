//
//  NnnbSPackageV.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSPackageVDelegate <NSObject>

- (void)presentToPackageContentViewWithDict:(NSDictionary *)dict Img:(UIImage *)img;

- (void)presentToPackageCodeViewWithCode:(NSString *)codeStr;

- (void)presentToTakenPackageViewWithDict:(NSDictionary *)dict;

@end

@interface NnnbSPackageV : NnnbSSuperV<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,weak) id<NnnbSPackageVDelegate> delegate;
@property (nonatomic,strong) UITableView *packageTableView;

- (void)requestDataToReload;
@end
