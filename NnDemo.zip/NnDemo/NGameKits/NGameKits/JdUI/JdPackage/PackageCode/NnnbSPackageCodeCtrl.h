//
//  NnnbSPackageCodeCtrl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperVCtrl.h"

@protocol NnnbSPackageCodeCtrlDelegate <NSObject>

- (void)reloadData;

@end

@interface NnnbSPackageCodeCtrl : NnnbSSuperVCtrl
@property (nonatomic,strong) NSString *codeStr;
@property (nonatomic,weak) id<NnnbSPackageCodeCtrlDelegate> delegate;
@end
