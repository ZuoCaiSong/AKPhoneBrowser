//
//  NnnbSPackageCodeCtrl.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSPackageCodeCtrl.h"

@interface NnnbSPackageCodeCtrl ()

@end

@implementation NnnbSPackageCodeCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 5, 180, 40)];
    title.text = @"兑换码";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.backBtn addTarget:self action:@selector(returnToGitfBagView) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.backBtn];
    [self.view addSubview:self.bgView];
    
    [self depictPackageCodeView];
}

- (void)returnToGitfBagView{
    [self dismissViewControllerAnimated:YES completion:nil];
    
    [self.delegate reloadData];
}

- (void)depictPackageCodeView{
    UIImageView *takeSuccImg = [[UIImageView alloc] initWithFrame:CGRectMake((self.bgView.width/2)-40, 50, 80, 80)];
    takeSuccImg.image = [UIImage nnGetPlatImage:@"TygTakeSucc.png"];
    [self.bgView addSubview:takeSuccImg];
    
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake(10, takeSuccImg.top+takeSuccImg.height, self.bgView.width-10*2, 60)];
    NSString *liStr = @"礼";
    NSString *bagStr = @"包";
    NSString *tipsStr = [NSString stringWithFormat:@"%@%@兑换码已经保存到“存号箱”。\n领到的号码要尽快兑换哦，迟了就有可能被人家淘走，快去兑换吧！",liStr,bagStr];
    tipLab.text = tipsStr;
    tipLab.font = [UIFont systemFontOfSize:14];
    tipLab.numberOfLines = 0;
    tipLab.textColor = [UIColor lightGrayColor];
    [self.bgView addSubview:tipLab];
    
    UILabel *codeLab = [[UILabel alloc] initWithFrame:CGRectMake(tipLab.left, tipLab.top+tipLab.height, self.bgView.width-tipLab.left*2, 20)];
    codeLab.text = [NSString stringWithFormat:@"兑换码：%@",self.codeStr];
    codeLab.textColor = RGBCOLOR(247, 99, 87);
    codeLab.font = [UIFont boldSystemFontOfSize:15];
    [self.bgView addSubview:codeLab];
    
    UIImage *img = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    UIButton *copyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    copyBtn.frame = CGRectMake(codeLab.left, codeLab.top+codeLab.height+10, codeLab.width, 40);
    [copyBtn setTitle:@"一键复制兑换码" forState:UIControlStateNormal];
    [copyBtn setBackgroundImage:img forState:UIControlStateNormal];
    [copyBtn addTarget:self action:@selector(copyCode) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:copyBtn];
}

- (void)copyCode{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    [pasteboard setString:self.codeStr];
    
    [NnnbTips depictCenterWithText:@"复制成功" duration:NN_TIPS_TIME2];
    
    [self popView];
    
    [self.delegate reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
