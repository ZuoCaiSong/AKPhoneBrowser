//
//  NnnbSPackageV.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSPackageV.h"
#import "NnnbSPackageCl.h"
#import "NnnbSSavePackageCl.h"

@interface NnnbSPackageV ()
@property (nonatomic,strong) UIView *btnView;
@property (nonatomic,strong) UIView *packageView;
@property (nonatomic,strong) UIView *savePackageView;
@property (nonatomic,strong) NSArray *dataArr;   //理煲数组
@property (nonatomic,strong) NSMutableArray *hadArr;   //存号箱数组
@property (nonatomic,strong) NSMutableArray *imgArr;
@property (nonatomic,strong) UITableView *savePackageTableView;
@property (nonatomic,assign) NSInteger indexRow;
@end

#define offTop 10
#define offleft 20

@implementation NnnbSPackageV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    _imgArr = [NSMutableArray array];
    _hadArr = [NSMutableArray array];
    
    self.backgroundColor = [UIColor whiteColor];
    
    _btnView = [[UIView alloc] initWithFrame:CGRectMake((self.width/2)-100, offTop, 202, 37)];
    [self addSubview:_btnView];
    
    _packageView = [[UIView alloc] initWithFrame:CGRectMake(0, _btnView.top+_btnView.height+10, self.width, self.height-_btnView.height-offTop*2)];
    [self addSubview:_packageView];
    
    _savePackageView = [[UIView alloc] initWithFrame:CGRectMake(_packageView.left,_packageView.top,_packageView.width,_packageView.height)];
    _savePackageView.hidden = YES;
    [self addSubview:_savePackageView];
    
    UIImage *leftSel = [UIImage nnGetPlatImage:@"Tyg_leftSel_tab.png"];
    leftSel = [leftSel stretchableImageWithLeftCapWidth:leftSel.size.width/2 topCapHeight:leftSel.size.height/2];
    
    UIImage *leftNor = [UIImage nnGetPlatImage:@"Tyg_leftNor_tab.png"];
    leftNor = [leftNor stretchableImageWithLeftCapWidth:leftNor.size.width/2 topCapHeight:leftNor.size.height/2];
    
    UIImage *rightSel = [UIImage nnGetPlatImage:@"Tyg_rightSel_tab.png"];
    rightSel = [rightSel stretchableImageWithLeftCapWidth:rightSel.size.width/2 topCapHeight:rightSel.size.height/2];
    
    UIImage *rightNor = [UIImage nnGetPlatImage:@"Tyg_rightNor_tab.png"];
    rightNor = [rightNor stretchableImageWithLeftCapWidth:rightNor.size.width/2 topCapHeight:rightNor.size.height/2];
    
    NSString *liStr = @"礼";
    NSString *bagStr = @"包";
    NSString *lgStr = [NSString stringWithFormat:@"%@%@",liStr,bagStr];
    NSArray *titleArr = @[lgStr,@"存号箱"];
    
    for (int i = 0; i < titleArr.count; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(1+(i%2)*100, 1, 100, 35);
        btn.tag = 100+i;
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:15];
        if (btn.tag == 100) {
            btn.selected = YES;
            
            [btn setBackgroundImage:leftNor forState:UIControlStateNormal];
            [btn setBackgroundImage:leftSel forState:UIControlStateSelected];
        } else {
            [btn setBackgroundImage:rightNor forState:UIControlStateNormal];
            [btn setBackgroundImage:rightSel forState:UIControlStateSelected];
        }
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_btnView addSubview:btn];
    }
    
    [self requestPackageListData];
}

- (void)btnClick:(UIButton *)btn{
    for (UIButton *button in _btnView.subviews) {
        if (button.tag == btn.tag) {
            button.selected = YES;
        } else {
            button.selected = NO;
        }
    }
    
    if (btn.tag == 100) {
        _savePackageView.hidden = YES;
        _packageView.hidden = NO;
        
        [_packageTableView reloadData];
    } else {
        _packageView.hidden = YES;
        _savePackageView.hidden = NO;
        
        if (_savePackageTableView){
            [_savePackageTableView reloadData];
        } else {
            if (_hadArr.count != 0){
                [self initSavePackageView];
            } else {
                NSString *liStr = @"礼";
                NSString *bagStr = @"包";
                NSString *tipsStr = [NSString stringWithFormat:@"您还没有领取过%@%@哦!",liStr,bagStr];
                
                [NnnbTips depictCenterWithText:tipsStr duration:NN_TIPS_TIME2];
            }
        }
    }
}

#pragma mark - 获取数据
- (void)requestPackageListData{
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] getPackageListData:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [self packageListResultHandler:notifi];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)packageListResultHandler:(NSNotification*)notif{
    NSDictionary *dict = notif.userInfo;
    if (dict[@"data"] && [dict[@"data"] isKindOfClass:[NSArray class]]){
        _dataArr = dict[@"data"];
        if (_dataArr.count != 0) {
            for (NSDictionary *dict2 in _dataArr) {
                UIImage *iconImg = [UIImage nnImageWithUrl:dict2[@"img"]];
                if (iconImg) {
                    [_imgArr addObject:iconImg];
                }else {
                    [_imgArr addObject:[UIImage new]];
                }
                
                if ([dict2[@"had"] integerValue] == 1) {
                    [_hadArr addObject:dict2];
                }
            }
            [self initpackageView];
        } else {
            NSString *liStr = @"礼";
            NSString *bagStr = @"包";
            NSString *tipsStr = [NSString stringWithFormat:@"暂无%@%@信息",liStr,bagStr];
            [NnnbTips depictCenterWithText:tipsStr duration:NN_TIPS_TIME3];
        }
    } else {
        NSString *liStr = @"礼";
        NSString *bagStr = @"包";
        NSString *tipsStr = [NSString stringWithFormat:@"暂无%@%@信息",liStr,bagStr];
        [NnnbTips depictCenterWithText:tipsStr duration:NN_TIPS_TIME3];
    }
}

#pragma mark - 理煲列表
- (void)initpackageView{
    _packageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _packageView.width, _packageView.height) style:UITableViewStylePlain];
    _packageTableView.delegate = self;
    _packageTableView.dataSource = self;
    _packageTableView.showsVerticalScrollIndicator = NO;
    _packageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _packageTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [_packageView addSubview:_packageTableView];
}

#pragma mark - 存号列表
- (void)initSavePackageView{
    _savePackageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _savePackageView.width, _savePackageView.height) style:UITableViewStylePlain];
    _savePackageTableView.delegate = self;
    _savePackageTableView.dataSource = self;
    _savePackageTableView.showsVerticalScrollIndicator = NO;
    _savePackageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _savePackageTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [_savePackageView addSubview:_savePackageTableView];
}

#pragma mark - tableview代理方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_packageView.hidden == NO) {
        return _dataArr.count;
    }

    return _hadArr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_packageView.hidden == NO) {
        return 120;
    }
    return 85;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (_packageView.hidden == NO) {
        
        static NSString *packageCellId = @"packageCell";
        
        NnnbSPackageCl *packageCell = [tableView dequeueReusableCellWithIdentifier:packageCellId];
        
        if(packageCell == nil){
            packageCell = [[NnnbSPackageCl alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:packageCellId];
        }
        
        NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row];
        
        packageCell.icon.image = _imgArr[indexPath.row];
        
        packageCell.name.text = dict[@"name"];
        
        NSInteger had = [dict[@"had"] integerValue];
        NSInteger num = [dict[@"num"] integerValue];
        
        if (had == 1) {
            packageCell.takeBtn.enabled = NO;
            [packageCell.takeBtn setTitle:@"已领取" forState:UIControlStateNormal];
            [packageCell.takeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygGrayBtn.png"] forState:UIControlStateNormal];
        } else {
            if (num == 0) {
                packageCell.takeBtn.enabled = NO;
                [packageCell.takeBtn setTitle:@"已领完" forState:UIControlStateNormal];
                [packageCell.takeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygGrayBtn.png"] forState:UIControlStateNormal];
            } else {
                packageCell.takeBtn.tag = indexPath.row;
                packageCell.takeBtn.enabled = YES;
                [packageCell.takeBtn setTitle:@"领取" forState:UIControlStateNormal];
                [packageCell.takeBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygYellowBtn.png"] forState:UIControlStateNormal];
                [packageCell.takeBtn addTarget:self action:@selector(cellBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            }
        }
        
        packageCell.content.text = dict[@"content"];
        
        packageCell.endDate.text = [NSString stringWithFormat:@"截止日期:%@",dict[@"e_date"]];
        
        packageCell.num.text = [NSString stringWithFormat:@"剩余量:%ld",(long)num];
        
        return packageCell;
    }
    
    static NSString *savePackageCellId = @"savePackageCell";
    
    NnnbSSavePackageCl *savePackageCell = [tableView dequeueReusableCellWithIdentifier:savePackageCellId];
    
    if(savePackageCell == nil){
        savePackageCell = [[NnnbSSavePackageCl alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:savePackageCellId];
    }
    
    NSDictionary *dict = [_hadArr objectAtIndex:indexPath.row];
    
    savePackageCell.nameLab.text = dict[@"name"];
    
    savePackageCell.endDateLab.text = [NSString stringWithFormat:@"截止日期：%@",dict[@"e_date"]];
    
    savePackageCell.contentLab.text = dict[@"content"];
    
    return savePackageCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (_packageView.hidden == NO) {
        NSDictionary *dict = [_dataArr objectAtIndex:indexPath.row];
        [self.delegate presentToPackageContentViewWithDict:dict Img:_imgArr[indexPath.row]];
    } else {
        [self.delegate presentToTakenPackageViewWithDict:_hadArr[indexPath.row]];
    }
}

#pragma mark - 表格领取按钮点击方法
- (void)cellBtnClick:(UIButton *)btn{
    NSInteger codeType = [[_dataArr[btn.tag] objectForKey:@"code_type"] integerValue];
    
    NSString *hdStr = [_dataArr[btn.tag] objectForKey:@"hd"];
    
    _indexRow = btn.tag;
    
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] getPageageCode:codeType hdStr:hdStr result:^(BOOL success, NSNotification *notifi) {
         [self removeLoadView];
        if (success) {
            NSDictionary *dict = notifi.userInfo;
            if (_delegate && [_delegate respondsToSelector:@selector(presentToPackageCodeViewWithCode:)]) {
                [self.delegate presentToPackageCodeViewWithCode:dict[@"code"]];
            }
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
    
}


#pragma mark - 从兑换码页面返回时再次请求数据并且reload表格
- (void)requestDataToReload{
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] getPackageListData:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [self packageListDataResultHandler:notifi];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)packageListDataResultHandler:(NSNotification*)notif{
    NSDictionary *dict = notif.userInfo;
    _dataArr = dict[@"data"];
    [_hadArr addObject:_dataArr[_indexRow]];
    [_packageTableView reloadData];
}

@end
