//
//  NnnbSLoginV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSLoginV.h"
#import "NnnbColorEx.h"
#import "NnnbIAPManager.h"
#import "NnnbUserAccountManager.h"
#import "NnnbSRegisterCtrl.h"

#define offLeft_x_width 10   //左边off宽度
#define LOGIN_TAG 1002   //定义提示密码错误的警告框的
#define LOGIN_FUN_TAG 100  //登陆下面按钮的tag起始
#define ACC_CHOOSE_TAG 1000 //是否记住账号 密码
#define FIELDBgHeight 40
#define forgetPwdBtnWidth 90
#define bgImageVTag 20
#define textFieldTag 200

@interface NnnbSLoginV ()<UIAlertViewDelegate,NnnbUserMenuDelegate>
@property (nonatomic,strong) UIButton *selectUserBtn;
@property (nonatomic,strong) UIAlertView* loginAlertView;
@property (nonatomic,strong) NSTimer *loginTimer;
@property (nonatomic,strong) UIImageView *fieldAccBgIv;
@property (nonatomic,strong) UIImageView *fieldPsdBgIv;
@property (nonatomic,strong) UIButton *raBtn;
@property (nonatomic,strong) UIButton *customerServiceBtn;
@property (nonatomic,strong) NnnbTextField *accountField;
@property (nonatomic,strong) NnnbTextField *pswField;
@property (nonatomic,strong) UIButton *loginBtn;
@property (nonatomic,copy) NSString *userName;
@property (nonatomic,copy) NSString *userCode;
@property (nonatomic,strong) UIButton *forgetPwdBtn;
@property (nonatomic,strong) NnnbUserMenu *userMenu;
@property (nonatomic,strong) UIImageView *accountBgView;
@end

@implementation NnnbSLoginV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    [self initTextField];
    [self initAccChoose];
    [self initLoginBtn];
    [self initRegisterBtn];
}

#pragma mark - 输入框
- (void)initTextField{
    NSArray *placeholderArr = @[@"账号",@"密码"];
    NSArray *leftViewArr = @[@"TygUser.png",@"TygPsw.png"];
    
    UIImage *bgImg = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    bgImg = [bgImg stretchableImageWithLeftCapWidth:bgImg.size.width/2 topCapHeight:bgImg.size.height/2];
    
    for (int i = 0; i < placeholderArr.count; i ++) {
        UIImageView *bgImageV = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, 10+i*(FIELDBgHeight+10), self.width - offLeft_x_width*2, FIELDBgHeight)];
        bgImageV.userInteractionEnabled = YES;
        bgImageV.image = bgImg;
        bgImageV.tag = bgImageVTag + i;
        [self addSubview:bgImageV];
        
        UIImageView *leftView = [[UIImageView alloc] initWithFrame:CGRectMake(bgImageV.height/4, bgImageV.height/4, bgImageV.height/2, bgImageV.height/2)];
        leftView.image = [UIImage nnGetPlatImage:leftViewArr[i]];
        leftView.layer.cornerRadius = 6.0f;
        [bgImageV addSubview:leftView];
        
        NnnbTextField *tField = [[NnnbTextField alloc] initWithFrame:CGRectMake(bgImageV.height, 1, bgImageV.width - bgImageV.height*2, bgImageV.height-2) andFromRight:10];
        tField.layer.cornerRadius = 6.0f;
        tField.borderStyle = UITextBorderStyleNone;
        tField.adjustsFontSizeToFitWidth = YES;
        tField.delegate = self;
        tField.placeholder = placeholderArr[i];
        tField.keyboardType = UIKeyboardTypeASCIICapable;
        tField.tag = textFieldTag + i;
        [bgImageV addSubview:tField];
        
        if (i == 0)
        {
            _accountBgView = bgImageV;
            tField.returnKeyType = UIReturnKeyNext;
            
            UIImage *img = [UIImage nnGetPlatImage:@"TygBottomJianTou.png"];
            img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
            
            self.selectUserBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            self.selectUserBtn.frame = CGRectMake(bgImageV.width - bgImageV.height, bgImageV.height/4, bgImageV.height/2, bgImageV.height/2);
            [self.selectUserBtn setImage:img forState:UIControlStateNormal];
            [self.selectUserBtn addTarget:self action:@selector(depictSelectUserAccount:) forControlEvents:UIControlEventTouchUpInside];
            [bgImageV addSubview:self.selectUserBtn];
        }
        else
        {
            tField.returnKeyType = UIReturnKeyDone;
            tField.secureTextEntry = YES;
            tField.clearButtonMode = UITextFieldViewModeWhileEditing;
            
            _forgetPwdBtn = [UIButton buttonWithType:UIButtonTypeSystem];
            _forgetPwdBtn.frame = CGRectMake(bgImageV.width - forgetPwdBtnWidth - 10, 2, forgetPwdBtnWidth, bgImageV.height-4);
            [_forgetPwdBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
            _forgetPwdBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
            [_forgetPwdBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
            [_forgetPwdBtn addTarget:self action:@selector(forgetPwdBtnClick) forControlEvents:UIControlEventTouchUpInside];
            [bgImageV addSubview:_forgetPwdBtn];
        }
    }
    
    _fieldAccBgIv = (UIImageView *)[self viewWithTag:bgImageVTag];
    _fieldPsdBgIv = (UIImageView *)[self viewWithTag:bgImageVTag+1];
    _accountField = (NnnbTextField *)[_fieldAccBgIv viewWithTag:textFieldTag];
    _pswField = (NnnbTextField *)[_fieldPsdBgIv viewWithTag:textFieldTag+1];
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSString *Reserve_Name = [keyChain nnPlatObjectForKey:kUserName];
    if (Reserve_Name != nil && Reserve_Name.length > 0) {
        _accountField.text = Reserve_Name;
        _pswField.text = [keyChain nnPlatObjectForKey:kUserCode];
    }
}

- (void)forgetPwdBtnClick
{
    [self.delegate loginToForgetPasswordView];
}

#pragma mark - 记住密码、自动登录
- (void)initAccChoose
{
    NSArray *titleArr = @[@"记住密码",@"自动登录"];
    
    for (int i = 0; i < titleArr.count; i ++) {
        _raBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        if (i == 0)
        {
            _raBtn.frame = CGRectMake(_fieldPsdBgIv.left, _fieldPsdBgIv.tp_bottom, 100, FIELDBgHeight);
        }
        else
        {
            _raBtn.frame = CGRectMake(_fieldPsdBgIv.width-100, _fieldPsdBgIv.tp_bottom, 100, FIELDBgHeight);
        }
        
        _raBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        _raBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -6, 0, 0);
        _raBtn.tag = ACC_CHOOSE_TAG+i;
        [_raBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [_raBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_raBtn setImage:[UIImage nnGetPlatImage:@"TygRememberAccNo.png"] forState:UIControlStateNormal];
        [_raBtn setImage:[UIImage nnGetPlatImage:@"TygRememberAcc.png"] forState:UIControlStateSelected];
        [_raBtn addTarget:self action:@selector(raBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_raBtn];
        
        NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
        int rememberPsw = [[keyChain kcObjectForKey:kRememberPsw] intValue];
        int autoLogin = [[keyChain kcObjectForKey:kAutoLogin] intValue];
        
        //首次安装默认勾选记住密码
        NSString *strfisrtInstall = [keyChain kcObjectForKey:firstInstall];
        
        if ([strfisrtInstall isEqualToString:@"notFirstInstall"]) {
            if(rememberPsw == 1 && _raBtn.tag == ACC_CHOOSE_TAG){
                _raBtn.selected = YES;
            }
        } else {
            if(_raBtn.tag == ACC_CHOOSE_TAG){
                _raBtn.selected = YES;
            }
            
            [keyChain kcSetObject:@"notFirstInstall" forKey:firstInstall];
        }
        
        NSString *userName = [keyChain nnPlatObjectForKey:kUserName];
        NSString *loginType = [keyChain kcObjectForKey:LoginType];
        if (autoLogin == 1 && _raBtn.tag == ACC_CHOOSE_TAG + 1) {
            _raBtn.selected = YES;
            
            if ([loginType isEqualToString:AccountLogin]) {
                if (userName.length > 0) {
                    self.loginAlertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                                    message:@"正在登录中..."
                                                                   delegate:self
                                                          cancelButtonTitle:@"取消"
                                                          otherButtonTitles:nil];
                    self.loginAlertView.tag = 100002;
                    
                    self.loginAlertView.delegate = self;
                    
                    [self.loginAlertView show];
                    
                    self.loginTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(loginClick) userInfo:nil repeats:NO];
                }
            }
        }
    }
}

- (void)raBtnClick:(UIButton *)btn{
    if (btn.selected == YES) {
        if (btn.tag == ACC_CHOOSE_TAG) {
            for (UIButton *button in self.subviews) {
                if (button.tag == ACC_CHOOSE_TAG || button.tag == ACC_CHOOSE_TAG +1) {
                    button.selected = NO;
                }
            }
        }
        btn.selected = NO;
    } else {
        if (btn.tag == ACC_CHOOSE_TAG + 1) {
            for (UIButton *button in self.subviews) {
                if (button.tag == ACC_CHOOSE_TAG || button.tag == ACC_CHOOSE_TAG + 1) {
                    button.selected = YES;
                }
            }
        }
        
        btn.selected = YES;
    }
}

#pragma mark - 登录按钮
- (void)initLoginBtn{
    //登录
    if (!_loginBtn) {
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _loginBtn.frame = CGRectMake(_fieldPsdBgIv.left, _fieldPsdBgIv.tp_bottom+FIELDBgHeight, _fieldPsdBgIv.width, FIELDBgHeight);
    UIImage *img = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [_loginBtn setBackgroundImage:img forState:UIControlStateNormal];
    [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    _loginBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [_loginBtn addTarget:self action:@selector(loginClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_loginBtn];
}

#pragma mark - 登录按钮方法
- (void)loginClick{
    if (self.loginAlertView) {
        [self.loginAlertView dismissWithClickedButtonIndex:0 animated:NO];
        self.loginAlertView = nil;
    }
    
    if (self.loginTimer) {
        [self.loginTimer invalidate];
        self.loginTimer = nil;
    }
    
    if([NnnbCommons isFastDoubleClickInSecond:2.0 TagStr:@"depictLoginView"]){
        [NnnbTips depictCenterWithText:@"请勿频繁点击，稍等片刻再操作" duration:NN_TIPS_TIME2];
        return;
    }
    
    if ([_accountField.text length] <= 0){
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text]){
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] <= 0){
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text]){
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(login) withObject:nil afterDelay:0.5];
}

- (void)login{
    [self NnnbSLoginVWithName:_accountField.text password:_pswField.text];
}

- (void)NnnbSLoginVWithName:(NSString*)userName password:(NSString*)password{
    //等待加载节目单
    [self depictLoadView];
    
    _userName = userName;
    _userCode = password;
    [[NnnbFacadeCenter defaultFacade] loginWithName:userName password:password result:^(BOOL success, NSNotification *notifi) {
        //移除加载等待界面
        [self removeLoadView];
        if (success) {
            [self loginResultHandler:notifi];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)loginResultHandler:(NSNotification*)notif {
    //保存用户名和用户密码
    [DataManger getInstance].currentUserInfo.strUserName = _userName;
    [DataManger getInstance].currentUserInfo.strUserPassWord = _userCode;
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    [keyChain kcSetObject:AccountLogin forKey:LoginType];
    
    [keyChain nnStringSetObject:_userName forKey:kUserName];
    
    NSString *rememberPsw = [NSString new];
    NSString *autoLogin = [NSString new];
    
    if ([CommonData GetCommonDataInstance].autoRememberAndLogin == YES) {
        [CommonData GetCommonDataInstance].autoRememberAndLogin = NO;
        rememberPsw = @"1";
        autoLogin = @"1";
        [keyChain kcSetObject:@"1" forKey:kRememberPsw];
        [keyChain nnStringSetObject:_userCode forKey:kUserCode];
        [keyChain kcSetObject:@"1" forKey:kAutoLogin];
    } else {
        for (UIButton *button in self.subviews) {
            if (button.tag == 1000) {
                if (button.selected == YES) {
                    rememberPsw = @"1";
                    [keyChain kcSetObject:@"1" forKey:kRememberPsw];
                    [keyChain nnStringSetObject:_userCode forKey:kUserCode];
                } else {
                    rememberPsw = @"0";
                    [keyChain kcSetObject:@"0" forKey:kRememberPsw];
                    [keyChain nnStringSetObject:@"" forKey:kUserCode];
                }
            }
            
            if (button.tag == 1001) {
                if (button.selected == YES) {
                    autoLogin = @"1";
                    [keyChain kcSetObject:@"1" forKey:kAutoLogin];
                } else {
                    autoLogin = @"0";
                    [keyChain kcSetObject:@"0" forKey:kAutoLogin];
                }
            }
        }
    }
    
    [[NnnbUserAccountManager getInstance] setLoginAccount:_userName andPwd:_userCode andRememberPsw:rememberPsw andAutoLogin:autoLogin];
    
    //抛出登录成功的消息
    [NnnbCommons postLoginSuccessMsg];
    
    [[NnnbIAPManager sharedManager] checkReceipt];
    
    //保证每次登录成功后展现
    [[NnnbSFloatW getInstance] depictWindow];
    
    [self.delegate popLoginView];
}

#pragma mark - 手机登录、账号注册
- (void)initRegisterBtn{
    NSArray *loginFunArrName = @[@"手机号登录", @"账号注册"];
    
    for (int i = 0; i < loginFunArrName.count; i++) {
        _customerServiceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _customerServiceBtn.frame = CGRectMake(_loginBtn.left+(i%2)*(_loginBtn.width-120), _loginBtn.top+_loginBtn.height+5, 120, _loginBtn.height);
        [_customerServiceBtn setTitle:loginFunArrName[i] forState:UIControlStateNormal];
        [_customerServiceBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
        _customerServiceBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
        [_customerServiceBtn addTarget:self action:@selector(loginFunBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _customerServiceBtn.tag = LOGIN_FUN_TAG +i;
        [_customerServiceBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygLightGray.png"] forState:UIControlStateHighlighted];
        [self addSubview:_customerServiceBtn];
    }
}

-(void)loginFunBtnClick:(UIButton *)btn
{
    if (btn.tag == LOGIN_FUN_TAG)
    {
        [self.delegate loginToPhoneLoginController];
    }
    else if (btn.tag == LOGIN_FUN_TAG + 1)
    {
        if (_delegate && [_delegate respondsToSelector:@selector(presentToRegisterView)])
        {
            [_delegate presentToRegisterView];
        }
    }
}

#pragma mark - 选择用户
- (void)depictSelectUserAccount:(UIButton*)btn{
    [_accountField resignFirstResponder];
    
    if(btn.selected == NO) {
        [self.userMenu showMenu];
    }
    else {
        [self.userMenu hideMenu];
    }
    btn.selected = !btn.selected;
}

#pragma mark - 下拉用户菜单
//LMJDropdownMenu Delegate
- (void)dropdownMenu:(NnnbUserMenu *)menu selectedCellNumber:(NSInteger)number
{
    NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
    NSDictionary *dic = [userAccountArr objectAtIndex:number];
    _accountField.text = [dic objectForKey:@"login_userId"];
    _pswField.text = [dic objectForKey:@"login_pwd"];
    
    self.selectUserBtn.selected = NO;
}

- (void)dropdownMenuWithDeleteAtIndex:(NSInteger)index
{
    NSArray *accountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
    
    [[NnnbUserAccountManager getInstance] deleteAccountWithIndex:(index % accountArr.count)];
}

//懒加载
- (NnnbUserMenu *)userMenu{
    if (_userMenu == nil) {
        _userMenu = [[NnnbUserMenu alloc] init];
        [_userMenu setFrame:CGRectMake(CGRectGetMinX(_accountBgView.frame), _accountBgView.tp_bottom, _accountBgView.width, _accountBgView.height)];
        _userMenu.delegate = self;
        [self addSubview:_userMenu];
        
        NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
        NSMutableArray * dataArray = [NSMutableArray array];
        for (NSDictionary * dict in userAccountArr) {
            [dataArray addObject:dict[@"login_userId"]];
        }
        
        [_userMenu setMenuWords:dataArray rowHeight:_accountBgView.height];
    }
    
    return _userMenu;
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.userMenu hideMenu];
    self.selectUserBtn.selected = NO;
    
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:60];
    }
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _accountField){
        [self.delegate moveBgViewBottom:60];
        
        //帐号只能是字母，数字和下划线
        if (textField.text && textField.text.length > 0 && ![NnnbCommons checkAccount:textField.text])
        {
            textField.text = @"";
            
            [NnnbTips depictCenterWithText:@"亲，请输入数字、字母或者下划线！" duration:NN_TIPS_TIME2];
        }
        
        NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
        
        for (NSDictionary *dict in userAccountArr) {
            NSString *user_Account = [dict objectForKey:@"login_userId"];
            if ([user_Account isEqualToString:_accountField.text]) {
                _pswField.text = [dict objectForKey:@"login_pwd"];
                return;
            } else {
                _pswField.text = nil;
            }
        }
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField){
        [_accountField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else {
        [_pswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField) {
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= 32) || (textField.text && (textField.text.length + string.length > 32))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

#pragma mark - UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == LOGIN_TAG) {
        [self loginResultHandler:nil];
    }
    
    if (alertView.tag == 100002) {
        if (self.loginTimer) {
            [self.loginTimer invalidate];
            self.loginTimer = nil;
        }
    }
}

@end
