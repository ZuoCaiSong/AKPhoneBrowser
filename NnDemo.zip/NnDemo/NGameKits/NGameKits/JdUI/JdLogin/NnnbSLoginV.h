//
//  NnnbSLoginV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbSSuperV.h"

@protocol NnnbSLoginVDelegate <NSObject>

-(void)popLoginView;

-(void)loginToForgetPasswordView;

-(void)presentToRegisterView;

-(void)loginToFastRegisterView;

-(void)loginToPhoneLoginController;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbSLoginV : NnnbSSuperV

@property (nonatomic,weak) id<NnnbSLoginVDelegate> delegate;

/*
 外界登录用的接口
 */
-(void)NnnbSLoginVWithName:(NSString*)userName password:(NSString*)password;
@end
