//
//  NnnbSLoginCtrl.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSLoginCtrl.h"
#import "NnnbUserAccountManager.h"

@interface NnnbSLoginCtrl ()

@end

@implementation NnnbSLoginCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"账号登录" font:[UIFont systemFontOfSize:20]];
    UILabel *title  = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width - titleWidth)/2, 0, titleWidth, self.titleIg.height)];
    title.text = @"账号登录";
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictLoginView];
}

- (void)depictLoginView{
    _loginView = [[NnnbSLoginV alloc] initWithFrame:CGRectMake(0, self.titleIg.tp_bottom, self.bgView.width, self.bgView.height-self.titleIg.tp_bottom)];
    _loginView.delegate = self;
    
    [self.bgView addSubview:_loginView];
    [self.view addSubview:self.bgView];
    
    NnnbKeyChain *keychain = [NnnbKeyChain standardKeyChain];
    NSString *userName = [keychain nnPlatObjectForKey:kUserName];
    NSString *phone = [keychain nnPlatObjectForKey:kUserPhone];
    NSString *loginType = [keychain kcObjectForKey:LoginType];
    NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
    
    if ([loginType isEqualToString:PhoneLogin] && phone.length > 0)
    {
        [self performSelector:@selector(loginToPhoneLoginController) withObject:nil afterDelay:0.1];
    }
    else if (userName.length <= 0 && userAccountArr.count == 0)
    {
        [self performSelector:@selector(presentToRegisterView) withObject:nil afterDelay:0.1];
    }
}

#pragma mark - NnnbSLoginVDelegate
- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)popLoginView{
    [self closeView];
}

- (void)loginToForgetPasswordView{
    NnnbSFgPassWordViewCtrl *fVC = [NnnbSFloatW getInstance].fgPassWordViewController;
    [self presentViewController:fVC animated:YES completion:nil];
}

-(void)loginToPhoneLoginController
{
    self.view.hidden = YES;
    NnnbSTelLoginVCtrl *cVC = [NnnbSFloatW getInstance].phoneViewController;
    cVC.delegate = self;
    [MainWindow addSubview:cVC.view];
}

- (void)presentToRegisterView
{
    NnnbSRegisterCtrl *rVC = [NnnbSFloatW getInstance].registerViewController;
    rVC.delegate = self;
    //    [self presentViewController:rVC animated:YES completion:nil];
    [self presentViewController:rVC animated:NO completion:nil];
}

- (void)loginToFastRegisterView
{
    NnnbSFastRegisterCtrl *farc = [NnnbSFloatW getInstance].fastRegisterViewController;
    farc.delegate = self;
    [self presentViewController:farc animated:YES completion:nil];
}

#pragma mark - NnnbSTelLoginVDelegate
- (void)closeLoginViewFromPhoneView
{
    [self popView];
    [self closeView];
}

-(void)noHiddenView{
    self.view.hidden = NO;
}

- (void)loginVCPresentRegistVC
{
    NnnbSRegisterCtrl *rVC = [NnnbSFloatW getInstance].registerViewController;
    rVC.delegate = self;
    [self presentViewController:rVC animated:NO completion:nil];
}

#pragma mark - NnnbSRegisterVDelegate
-(void)registerSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw
{
    [_loginView NnnbSLoginVWithName:account password:psw];
}

- (void)registerVCPresentPhoneLoginVC
{
    [self loginToPhoneLoginController];
}

#pragma mark - NnnbSFastRegisterCtrlDelegate
- (void)retutnToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw{
    [_loginView NnnbSLoginVWithName:account password:psw];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
