//
//  NnnbSTelLoginV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSTelLoginV.h"
#import "NnnbFacade+bandPhoneUpdateTimer.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbUserAccountManager.h"
#import "NnnbSLoginCtrl.h"
#import "NnnbIAPManager.h"

#define offLeft_x_width 10  //左边off宽度
#define offTop_x_height 10   //顶部off高度
#define getMesBtnWidth 110

#define UPDATA_COUNT 40
#define FIELDBgHeight 40

#define BottomBtnTag 100

@interface NnnbSTelLoginV ()
@property (nonatomic,assign) NSInteger direction;
@property (nonatomic,strong) UIImage *img;
@property (nonatomic,strong) UIImageView *teleFieldBgIv;
@property (nonatomic,strong) UIImageView *msgFieldBgIv;
@property (nonatomic,strong) NnnbTextField *phoneField;
@property (nonatomic,strong) NnnbTextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,strong) UIButton *loginBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@property (nonatomic,assign) CGFloat fieldHeight;
@property (nonatomic,strong) NSTimer *loginTimer;
@property (nonatomic,copy) NSString *phoneStr;
@property (nonatomic,copy) NSString *phonePsw;
@property (nonatomic,strong) UIAlertView* loginAlertView;
@property (nonatomic,copy) NSString *mesPhoneStr;
@end

@implementation NnnbSTelLoginV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    _direction = [[CommonData GetCommonDataInstance] judgeDirection];
    
    _img = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    _img = [_img stretchableImageWithLeftCapWidth:_img.size.width/2 topCapHeight:_img.size.height/2];
    
    //手机------------------------------------------
    _teleFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _teleFieldBgIv.userInteractionEnabled = YES;
    _teleFieldBgIv.image = _img;
    [self addSubview:_teleFieldBgIv];
    
    CGFloat fieldWidth = _teleFieldBgIv.width;
    _fieldHeight = _teleFieldBgIv.height;
    
    UIImageView *phoneleftView = [[UIImageView alloc]init];
    phoneleftView.frame = CGRectMake(_fieldHeight/4, _fieldHeight/4, _fieldHeight/2, _fieldHeight/2);
    phoneleftView.image = [UIImage nnGetPlatImage:@"TygPhone.png"];
    [_teleFieldBgIv addSubview:phoneleftView];
    
    if (!_phoneField) {
        _phoneField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _phoneField.frame = CGRectMake(_fieldHeight, 0.5, fieldWidth-_fieldHeight -10, _fieldHeight-1);
    }
    _phoneField.layer.cornerRadius = 6.0f;
    _phoneField.borderStyle = UITextBorderStyleNone;
    _phoneField.adjustsFontSizeToFitWidth = YES;
    _phoneField.delegate = self;
    _phoneField.placeholder = @"请输入手机号码";
    _phoneField.font = [UIFont systemFontOfSize:15];
    _phoneField.returnKeyType = UIReturnKeyNext;
    _phoneField.keyboardType = UIKeyboardTypeNumberPad;
    [_teleFieldBgIv addSubview:_phoneField];
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSString *phone = [keyChain nnPlatObjectForKey:kUserPhone];
    if (phone.length > 0) {
        _phoneField.text = phone;
    }

    //验证码--------------------------------------------------------
    _msgFieldBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _teleFieldBgIv.tp_bottom +10,self.width - offLeft_x_width*2, FIELDBgHeight)];
    _msgFieldBgIv.userInteractionEnabled = YES;
    _msgFieldBgIv.image = _img;
    [self addSubview:_msgFieldBgIv];
    
    UIImageView *mesleftView = [[UIImageView alloc]init];
    mesleftView.frame = CGRectMake(_fieldHeight/4, _fieldHeight/4, _fieldHeight/2, _fieldHeight/2);
    mesleftView.image = [UIImage nnGetPlatImage:@"TygMessage.png"];
    [_msgFieldBgIv addSubview:mesleftView];
    
    if (!_mesField) {
        _mesField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _mesField.frame = CGRectMake(_fieldHeight, 0.5, fieldWidth-_fieldHeight -10, _fieldHeight-1);
    }
    _mesField.layer.cornerRadius = 6.0f;
    _mesField.borderStyle = UITextBorderStyleNone;
    _mesField.adjustsFontSizeToFitWidth = YES;
    _mesField.delegate = self;
    _mesField.placeholder = @"请输入验证码";
    _mesField.font = [UIFont systemFontOfSize:15];
    _mesField.returnKeyType = UIReturnKeyDone;
    _mesField.keyboardType = UIKeyboardTypeNumberPad;
    [_msgFieldBgIv addSubview:_mesField];
    
    //获取验证码
    if (!_getMesBtn) {
        _getMesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _getMesBtn.frame = CGRectMake(fieldWidth-getMesBtnWidth, 2, getMesBtnWidth, _fieldHeight-4);
    [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    _getMesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:13];
    [_getMesBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
    [_getMesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_msgFieldBgIv addSubview:_getMesBtn];
    
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake(_msgFieldBgIv.left, _msgFieldBgIv.tp_bottom+15, _msgFieldBgIv.width, _msgFieldBgIv.height/2)];
    tipLab.text = @"通过手机验证码可以马上登录，无需注册!";
    tipLab.adjustsFontSizeToFitWidth = YES;
    tipLab.textColor = [UIColor lightGrayColor];
    tipLab.textAlignment = NSTextAlignmentCenter;
    [self addSubview:tipLab];
    
    //登录
    _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _loginBtn.frame = CGRectMake(_msgFieldBgIv.left, tipLab.tp_bottom+10, _msgFieldBgIv.width, _mesField.height);
    UIImage *img3 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img3 = [img3 stretchableImageWithLeftCapWidth:img3.size.width/2 topCapHeight:img3.size.height/2];
    [_loginBtn setBackgroundImage:img3 forState:UIControlStateNormal];
    [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    _loginBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    [_loginBtn addTarget:self action:@selector(phoneLoginClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_loginBtn];
    
    NSArray *titleArr = @[@"账号注册", @"已有账号"];
    
    for (int i = 0; i < titleArr.count; i++) {
        UIButton *bottomBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        bottomBtn.frame = CGRectMake(_loginBtn.left+(i%2)*(_loginBtn.width-120), _loginBtn.tp_bottom+5, 120, _loginBtn.height);
        [bottomBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [bottomBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
        bottomBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
        [bottomBtn addTarget:self action:@selector(bottomBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        bottomBtn.tag = BottomBtnTag +i;
        [bottomBtn setBackgroundImage:[UIImage nnGetPlatImage:@"TygLightGray.png"] forState:UIControlStateHighlighted];
        [self addSubview:bottomBtn];
    }
    
    NSString *loginType = [keyChain kcObjectForKey:LoginType];
    NSString *phonePsw = [keyChain nnPlatObjectForKey:kUserPhonePsw];
    
    _phoneStr = phone;
    _phonePsw = phonePsw;
    
    if (phone.length > 0 && phonePsw.length > 0 && [loginType isEqualToString:PhoneLogin]) {
        self.loginAlertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                        message:@"正在登录中..."
                                                       delegate:self
                                              cancelButtonTitle:@"取消"
                                              otherButtonTitles:nil];
        
        self.loginAlertView.tag = 100001;
        
        self.loginAlertView.delegate = self;
        
        [self.loginAlertView show];
        
        self.loginTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(autoLogin) userInfo:nil repeats:NO];
    }
}

- (void)autoLogin
{
    [[NnnbFacadeCenter defaultFacade] loginWithName:_phoneStr password:_phonePsw result:^(BOOL success, NSNotification *notifi) {
        
        if (self.loginAlertView) {
            [self.loginAlertView dismissWithClickedButtonIndex:0 animated:NO];
            self.loginAlertView = nil;
        }
        
        if (self.loginTimer) {
            [self.loginTimer invalidate];
            self.loginTimer = nil;
        }
        
        if (success) {
            //抛出登录成功的消息
            [NnnbCommons postLoginSuccessMsg];
            
            [[NnnbIAPManager sharedManager] checkReceipt];
            
            [[NnnbSFloatW getInstance] depictWindow];
            
            [self.delegate closePhoneLoginView];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
        
    }];
    
}


- (void)bottomBtnClick:(UIButton *)button
{
    if (button.tag == BottomBtnTag) {
        if (_delegate && [_delegate respondsToSelector:@selector(presentRegistView)])
        {
            [_delegate presentRegistView];
        }
    }
    else {
        if (_delegate && [_delegate respondsToSelector:@selector(phoneLoginViewReturnToLoginView)])
        {
            [self.delegate phoneLoginViewReturnToLoginView];
        }
    }
}

#pragma mark - 获取验证码方法
- (void)getCheckBtnClick{
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入手机号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    //停止定时器
    [[NnnbFacade getInstance] verificationStopTimer];
    _getMesBtn.enabled = NO;
    
    //设置定时器参数
    [[NnnbFacade getInstance] verificationSetTimerPara:@selector(updateTimerHandler:) object:self];
    
    //开始定时器
    [[NnnbFacade getInstance] verificationStartTimer];
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForPhoneLogin:_phoneField.text result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            //提示
            NSString* strTips = @"验证码已发送";
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            
            _mesPhoneStr = _phoneField.text;
        }
        else {
            //停止定时器
            [[NnnbFacade getInstance] verificationStopTimer];
            _iUpdateCount = 0;
            _getMesBtn.enabled = YES;
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE]integerValue];
            if (iErr != 1011) {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}

/****************************************************
 *  函数名:  updateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         (NSNumber *)iCount          倒计时时间
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        //超时
        [[NnnbFacade getInstance] verificationStopTimer];
        
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    }
    else
    {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后重新获取",(long)z] forState:UIControlStateNormal];
    }
}



#pragma mark - 登录按钮点击
- (void)phoneLoginClick{
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"手机号不能为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_phoneField.text isEqualToString:_mesPhoneStr] && _mesPhoneStr.length != 0) {
        [NnnbTips depictCenterWithText:@"手机号输入不一致" duration:NN_TIPS_TIME2];

        return;
    }
    
    //取消键盘
    [_mesField resignFirstResponder];
    [_phoneField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(doPhoneLogin) withObject:nil afterDelay:0.5];
}

- (void)doPhoneLogin{
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] phoneloginNumber:_phoneField.text messageCode:_mesField.text result:^(BOOL success, NSNotification *notifi) {
        
        //等待界面
        [self removeLoadView];
        if (success) {
            NSString *psw = [notifi.userInfo objectForKey:@"p"];
            
            //保存用户名和用户密码
            [DataManger getInstance].currentUserInfo.strUserName = _phoneField.text;
            [DataManger getInstance].currentUserInfo.strUserPassWord = psw;
            
            NnnbKeyChain *keychain = [NnnbKeyChain standardKeyChain];
            [keychain nnStringSetObject:_phoneField.text forKey:kUserPhone];
            [keychain nnStringSetObject:psw forKey:kUserPhonePsw];
            [keychain kcSetObject:PhoneLogin forKey:LoginType];
            
            //抛出登录成功的消息
            [NnnbCommons postLoginSuccessMsg];
            
            [[NnnbIAPManager sharedManager] checkReceipt];
            
            [[NnnbSFloatW getInstance] depictWindow];
            
            [self.delegate closePhoneLoginView];
        }
        else {
            //提示错误
            NSString* errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
        
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _phoneField) {
        [_phoneField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _phoneField && string && string.length > 0 && ![NnnbCommons isNumber:string]){
        return NO;
    }
    
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

#pragma mark - UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 100001) {
        if (self.loginTimer) {
            [self.loginTimer invalidate];
            self.loginTimer = nil;
        }
    }
}

@end
