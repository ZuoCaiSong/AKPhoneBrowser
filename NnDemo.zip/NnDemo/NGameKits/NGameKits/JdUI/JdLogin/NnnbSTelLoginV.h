//
//  NnnbSTelLoginV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperV.h"

@protocol NnnbSTelLoginVDelegate <NSObject>

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

-(void)closePhoneLoginView;

-(void)phoneLoginViewReturnToLoginView;

- (void)presentRegistView;

@end

@interface NnnbSTelLoginV : NnnbSSuperV<UITextFieldDelegate,UIAlertViewDelegate>
@property (nonatomic,weak) id<NnnbSTelLoginVDelegate> delegate;
@end
