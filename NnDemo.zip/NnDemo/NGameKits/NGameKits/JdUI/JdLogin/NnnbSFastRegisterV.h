//
//  NnnbSFastRegisterV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperV.h"
@protocol NnnbSFastRegisterVDelegate <NSObject>
-(void)backToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw;
@end

@interface NnnbSFastRegisterV : NnnbSSuperV
@property (nonatomic,strong) UILabel *user;
@property (nonatomic,strong) UILabel *psw;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *userPsw;
@property (nonatomic,strong) UIButton *enterGameBtn;
@property (nonatomic ,strong)NSTimer *enterTimer;
@property (nonatomic ,assign)NSInteger enterCount;
@property (nonatomic,weak) id<NnnbSFastRegisterVDelegate> delegate;
@end
