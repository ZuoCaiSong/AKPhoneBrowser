//
//  NnnbSFastRegisterCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSFastRegisterCtrl.h"

@interface NnnbSFastRegisterCtrl ()

@end

@implementation NnnbSFastRegisterCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];

    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"注册成功" font:[UIFont systemFontOfSize:20]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWidth)/2, 2.5, titleWidth, 40)];
    title.text = @"注册成功";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont boldSystemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictFastRegisterView];
}

- (void)depictFastRegisterView{
    _fastRegisterView = [[NnnbSFastRegisterV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-50)];
    _fastRegisterView.backgroundColor = RGBCOLOR(232, 232, 232);
    _fastRegisterView.delegate = self;
    self.bgView.backgroundColor = RGBCOLOR(232, 232, 232);
    [self.bgView addSubview:_fastRegisterView];
    [self.view addSubview:self.bgView];
}

//-(void)closeView
//{
//    NSString *account;
//    NSString *psw;
//    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
//    account = [userDef objectForKey:@"fastRegisterName"];
//    psw = [userDef objectForKey:@"fastRegisterPsw"];
//
//    [self popView];
//    UIView *view = [self.view superview];
//    [view removeFromSuperview];
//
//    [self.delegate retutnToLastViewWithAccount:account andPsw:psw];
//}

#pragma mark - NnnbSFastRegisterVDelegate
- (void)backToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw{
    [self popView];
    if (_delegate && [_delegate respondsToSelector:@selector(retutnToLastViewWithAccount:andPsw:)]) {
        [_delegate retutnToLastViewWithAccount:account andPsw:psw];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
