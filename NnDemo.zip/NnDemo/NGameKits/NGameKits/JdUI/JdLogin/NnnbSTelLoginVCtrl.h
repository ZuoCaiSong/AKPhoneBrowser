//
//  NnnbSTelLoginVCtrl.h
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperVCtrl.h"

@protocol NnnbSTelLoginCtrl <NSObject>
- (void)closeLoginViewFromPhoneView;

-(void)noHiddenView;

- (void)loginVCPresentRegistVC;
@end

@interface NnnbSTelLoginVCtrl : NnnbSSuperVCtrl<NnnbSTelLoginVDelegate>
@property (nonatomic,strong) NnnbSTelLoginV *phoneLoginView;
@property (nonatomic,weak) id<NnnbSTelLoginCtrl> delegate;
@end
