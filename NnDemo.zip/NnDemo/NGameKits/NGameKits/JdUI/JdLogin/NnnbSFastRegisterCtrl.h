//
//  NnnbSFastRegisterCtrl.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSSuperVCtrl.h"
#import "NnnbSFastRegisterV.h"

@protocol NnnbSFastRegisterCtrlDelegate <NSObject>

-(void)retutnToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw;

@end

@interface NnnbSFastRegisterCtrl : NnnbSSuperVCtrl<NnnbSFastRegisterVDelegate>
@property (nonatomic,strong) NnnbSFastRegisterV *fastRegisterView;
@property (nonatomic,weak) id<NnnbSFastRegisterCtrlDelegate> delegate;
@end
