//
//  NnnbSFgPassWordV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSFgPassWordVDelegate <NSObject>

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

-(void)presentViewResetPassword:(NSString *)strAccount phone:(NSString *)strPhone mes:(NSString *)strMes;

@end

@interface NnnbSFgPassWordV : NnnbSSuperV
@property(nonatomic,weak)id<NnnbSFgPassWordVDelegate> delegate;
@end
