//
//  NnnbSFgPassWordV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSFgPassWordV.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbColorEx.h"

//左边off宽度
#define offLeft_x_width 10
//右边off宽度
#define offRight_x_width 10
//顶部off高度
#define offTop_x_height 10

#define UPDATA_COUNT 40

#define getMesBtnWidth 110

#define FIELDBgHeight 40

@interface NnnbSFgPassWordV ()
@property (nonatomic,strong) UIImageView *fieldAccBgIv;
@property (nonatomic,strong) UIImageView *fieldTeleBgIv;
@property (nonatomic,strong) UIImageView *fieldMesBgIv;
@property (nonatomic,strong) NnnbTextField *accountField;
@property (nonatomic,strong) NnnbTextField *phoneField;
@property (nonatomic,strong) NnnbTextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,strong) UIButton *confirmBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@property (nonatomic,copy) NSString *phoneStr;
@end

@implementation NnnbSFgPassWordV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    UIImage *bgImg = [UIImage nnGetPlatImage:@"TygYuanBianKuang.png"];
    bgImg = [bgImg stretchableImageWithLeftCapWidth:bgImg.size.width/2 topCapHeight:bgImg.size.height/2];
    
    _fieldAccBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _fieldAccBgIv.userInteractionEnabled = YES;
    _fieldAccBgIv.image = bgImg;
    [self addSubview:_fieldAccBgIv];
    
    CGFloat fieldWidth = _fieldAccBgIv.width;
    CGFloat fieldHeight = _fieldAccBgIv.height;
    
    //账号------------------------------------------
    UIImageView *accountleftView = [[UIImageView alloc]init];
    accountleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    accountleftView.image = [UIImage nnGetPlatImage:@"TygUser.png"];
    [_fieldAccBgIv addSubview:accountleftView];
    
    if (!_accountField) {
        _accountField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _accountField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth - fieldHeight - 10, fieldHeight-1);
    }
    _accountField.layer.cornerRadius = 6.0f;
    _accountField.borderStyle = UITextBorderStyleNone;
    _accountField.adjustsFontSizeToFitWidth = YES;
    _accountField.delegate = self;
    _accountField.placeholder = @"请输入账号";
    _accountField.font = [UIFont systemFontOfSize:15];
    _accountField.returnKeyType = UIReturnKeyNext;
    _accountField.keyboardType = UIKeyboardTypeASCIICapable;
    _accountField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [_fieldAccBgIv addSubview:_accountField];
    
    //手机号--------------------------------------------------------
    _fieldTeleBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _fieldAccBgIv.tp_bottom + 10, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _fieldTeleBgIv.userInteractionEnabled = YES;
    _fieldTeleBgIv.image = bgImg;
    [self addSubview:_fieldTeleBgIv];
    
    UIImageView *phoneleftView = [[UIImageView alloc]init];
    phoneleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    phoneleftView.image = [UIImage nnGetPlatImage:@"TygPhone.png"];
    [_fieldTeleBgIv addSubview:phoneleftView];
    
    if (!_phoneField) {
        _phoneField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _phoneField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth - fieldHeight - 10, fieldHeight-1);
    }
    _phoneField.layer.cornerRadius = 6.0f;
    _phoneField.borderStyle = UITextBorderStyleNone;
    _phoneField.adjustsFontSizeToFitWidth = YES;
    _phoneField.delegate = self;
    _phoneField.placeholder = @"请输入手机号";
    _phoneField.font = [UIFont systemFontOfSize:15];
    _phoneField.returnKeyType = UIReturnKeyNext;
    _phoneField.keyboardType = UIKeyboardTypeNumberPad;
    [_fieldTeleBgIv addSubview:_phoneField];
    
    //验证码--------------------------------------------------------
    _fieldMesBgIv = [[UIImageView alloc] initWithFrame:CGRectMake(offLeft_x_width, _fieldTeleBgIv.tp_bottom + 10, self.width - offLeft_x_width*2, FIELDBgHeight)];
    _fieldMesBgIv.userInteractionEnabled = YES;
    _fieldMesBgIv.image = bgImg;
    [self addSubview:_fieldMesBgIv];
    
    UIImageView *mesleftView = [[UIImageView alloc]init];
    mesleftView.frame = CGRectMake(fieldHeight/4, fieldHeight/4, fieldHeight/2, fieldHeight/2);
    mesleftView.image = [UIImage nnGetPlatImage:@"TygMessage.png"];
    [_fieldMesBgIv addSubview:mesleftView];
    
    if (!_mesField) {
        _mesField = [[NnnbTextField alloc]initWithFrame:CGRectZero andFromRight:10];
        _mesField.frame = CGRectMake(fieldHeight, 0.5, fieldWidth - fieldHeight - 10, fieldHeight-1);
    }
    _mesField.layer.cornerRadius = 6.0f;
    _mesField.borderStyle = UITextBorderStyleNone;
    _mesField.adjustsFontSizeToFitWidth = YES;
    _mesField.delegate = self;
    _mesField.placeholder = @"请输入验证码";
    _mesField.font = [UIFont systemFontOfSize:15];
    _mesField.returnKeyType = UIReturnKeyDone;
    _mesField.keyboardType = UIKeyboardTypeNumberPad;
    [_fieldMesBgIv addSubview:_mesField];
    
    //获取验证码
    if (!_getMesBtn) {
        _getMesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _getMesBtn.frame = CGRectMake(fieldWidth-getMesBtnWidth, 2, getMesBtnWidth, fieldHeight-4);
    [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    _getMesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [_getMesBtn setTitleColor:RGBCOLOR(0, 171, 227) forState:UIControlStateNormal];
    [_getMesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [_fieldMesBgIv addSubview:_getMesBtn];
    
    //确认
    if (!_confirmBtn) {
        _confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    _confirmBtn.frame = CGRectMake(_fieldMesBgIv.left, _fieldMesBgIv.top+_fieldMesBgIv.height+20, fieldWidth, fieldHeight+10);
    UIImage *img2 = [UIImage nnGetPlatImage:@"TygYellowBtn.png"];
    img2 = [img2 stretchableImageWithLeftCapWidth:img2.size.width/2 topCapHeight:img2.size.height/2];
    [_confirmBtn setBackgroundImage:img2 forState:UIControlStateNormal];
    [_confirmBtn setTitle:@"确     定" forState:UIControlStateNormal];
    _confirmBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    [_confirmBtn addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_confirmBtn];
}

#pragma mark - 获取验证码
/****************************************************
 *  函数名:  getCheckBtnClick
 *  功  能:  获取验证码的button的响应函数
 *  入  参:
 *			无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
-(void)getCheckBtnClick{
    [_accountField resignFirstResponder];
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_accountField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text])
    {
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入手机号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    //停止定时器
    [[NnnbFacade getInstance] verificationStopTimer];
    _getMesBtn.enabled = NO;
    
    //设置定时器参数
    [[NnnbFacade getInstance] verificationSetTimerPara:@selector(updateTimerHandler:) object:self];
    
    //开始定时器
    [[NnnbFacade getInstance] verificationStartTimer];
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForUserForgetPsd:_accountField.text phone:_phoneField.text esult:^(BOOL success, NSNotification *notifi) {
        if (success) {
            //提示
            NSString* strTips = @"验证码已发送";
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            
            _phoneStr = _phoneField.text;
        }
        else {
            //停止定时器
            [[NnnbFacade getInstance] verificationStopTimer];
            _iUpdateCount = 0;
            _getMesBtn.enabled = YES;
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE]integerValue];
            if (iErr != 1011) {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}

/****************************************************
 *  函数名:  updateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         (NSNumber *)iCount          倒计时时间
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        //超时
        [[NnnbFacade getInstance] verificationStopTimer];
        
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    }
    else
    {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后重新获取",(long)z] forState:UIControlStateNormal];
    }
}

#pragma mark - 确认按钮方法
- (void)confirmClick{
    if (![NnnbCommons checkAccount:_accountField.text])
    {
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"手机号不能为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_phoneField.text isEqualToString:_phoneStr] && _phoneStr.length != 0) {
        [NnnbTips depictCenterWithText:@"手机号输入不一致" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_accountField resignFirstResponder];
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] confirmVerifyCode:_mesField.text account:_accountField.text phone:_phoneField.text result:^(BOOL success, NSNotification *notifi) {
        //停止等待界面
        [self removeLoadView];
        if (success) {
            [self.delegate presentViewResetPassword:_accountField.text phone:_phoneField.text mes:_mesField.text];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:80];
    }
    if (textField == _phoneField) {
        [self.delegate moveBgViewTop:120];
    }
    if (textField == _mesField) {
        [self.delegate moveBgViewTop:160];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _accountField){
        [self.delegate moveBgViewBottom:80];
        //帐号只能是字母，数字和下划线
        if (textField.text && textField.text.length > 0 && ![NnnbCommons checkAccount:textField.text]){
            textField.text = @"";
            
            [NnnbTips depictCenterWithText:@"亲，请输入数字、字母或者下划线！" duration:NN_TIPS_TIME2];
        }
    }
    
    if (textField == _phoneField) {
        [self.delegate moveBgViewBottom:120];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewBottom:160];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField) {
        [_accountField resignFirstResponder];
        [_phoneField becomeFirstResponder];
    } else if (textField == _phoneField){
        [_phoneField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _phoneField && string && string.length > 0 && ![NnnbCommons isNumber:string]){
        return NO;
    }
    
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField){
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
