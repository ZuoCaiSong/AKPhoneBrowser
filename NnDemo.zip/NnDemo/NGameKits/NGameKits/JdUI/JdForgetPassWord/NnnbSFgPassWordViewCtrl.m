//
//  NnnbSFgPassWordViewCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSFgPassWordViewCtrl.h"
#import "NnnbSResetPswCtrl.h"

@interface NnnbSFgPassWordViewCtrl ()
@end

@implementation NnnbSFgPassWordViewCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    [self depictFgPassWordView];
}

- (void)depictFgPassWordView{
    CGFloat titleWidth = [NnnbLabelSizeToFit getWidthWithtext:@"忘记密码" font:[UIFont systemFontOfSize:20]];
    UILabel *title  = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width - titleWidth)/2, 2.5, titleWidth, 40)];
    title.text = @"忘记密码";
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    _fgPassWordView = [[NnnbSFgPassWordV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _fgPassWordView.delegate = self;
    [self.bgView addSubview:_fgPassWordView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbSFgPassWordVDelegate
- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)presentViewResetPassword:(NSString *)strAccount phone:(NSString *)strPhone mes:(NSString *)strMes{
    NnnbSResetPswCtrl *rVc = [[NnnbSResetPswCtrl alloc] init];
    rVc.delegate = self;
    rVc.strAccount = strAccount;
    rVc.strPhone = strPhone;
    rVc.strMes = strMes;
    [self presentViewController:rVc animated:YES completion:nil];
}

#pragma mark - NnnbSResetPswCtrlDelegate
- (void)backTolastView{
    [self popView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
