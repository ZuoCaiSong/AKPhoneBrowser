//
//  NnnbSTppCenterV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSTppCenterVDelegate <NSObject>

-(void)closeOwnView;

- (void)PlayerMsg:(NSDictionary *)info;

@end

@interface NnnbSTppCenterV : NnnbSSuperV
@property (nonatomic,weak) id<NnnbSTppCenterVDelegate> delegate;
@end
