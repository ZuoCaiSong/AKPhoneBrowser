//
//  NnnbSTppCenterCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSTppCenterCtrl.h"
#import "NnnbColorEx.h"
#import "NSString+Game.h"
#import "NSString+Base64.h"

@interface NnnbSTppCenterCtrl ()
@property (nonatomic,strong) NnnbSTppCenterV *topUpCenterView;
@property (nonatomic,copy) NSString *zUrStr;
@property (nonatomic,copy) NSString *wUrStr;
@property (nonatomic,strong) UIWebView *yulanView;
@end

@implementation NnnbSTppCenterCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _yulanView  = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, UIScreenWidth, UIScreenHeight)];
    _yulanView.scrollView.bounces = NO;
    _yulanView.alpha = 0;
    _yulanView.delegate = self;
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    [self.closeBtn addTarget:self action:@selector(sendNot) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    NSString *str1 = @"确认";
    NSString *str2 = @"订";
    NSString *str3 = @"单";
    title.text = [NSString stringWithFormat:@"%@%@%@",str1,str2,str3];
    title.textColor = [UIColor blackColor];
    title.font = [UIFont boldSystemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictTopUpView];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(becomeActiveToPopView:)
                                                name:NN_BECOMEACTIVE_HANDLE
                                              object:nil];
}

- (void)sendNot{
    NSDictionary *flagD = [NSDictionary dictionaryWithObject:@"0" forKey:@"stateFlag"];
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_APPLE
                                                        object:nil userInfo:flagD];
}

- (void)depictTopUpView{
    _topUpCenterView = [[NnnbSTppCenterV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _topUpCenterView.delegate = self;
    [self.bgView addSubview:_topUpCenterView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

-(void)becomeActiveToPopView:(NSNotification*)notif
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NN_BECOMEACTIVE_HANDLE object:nil];
    
    NSDictionary *flagD = [NSDictionary dictionaryWithObject:@"1" forKey:@"stateFlag"];
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_APPLE
                                                        object:nil userInfo:flagD];
    
    
    [self closeOwnView];
}

#pragma mark - NnnbSTppCenterVDelegate
-(void)closeOwnView{
    [self closeView];
}

- (void)PlayerMsg:(NSDictionary *)info{
    _zUrStr = info[@"ymStr"];
    _wUrStr = info[@"htmStr"];
    
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:info[@"data"]]];
    [self.view addSubview: _yulanView];
    [_yulanView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)returnBtnClick
{
    [_yulanView removeFromSuperview];
    NSDictionary *flagD = [NSDictionary dictionaryWithObject:@"1" forKey:@"stateFlag"];
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_APPLE
                                                        object:self userInfo:flagD];
}

#pragma mark - UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{

}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{

}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSRange flagRange = [request.URL.absoluteString rangeOfString:[NSString stringWithBase64EncodedString:@"cGF5LnRhbndhbi5jb20vYXBpL3Nka192My9yZXR1cm4ucGhw"]];
    
    if (flagRange.length >0)
    {
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        [userDef setBool:YES forKey:[NSString stringWithFormat:@"chSuccReturn%@", [DataManger getInstance].systemInfo.strAppId]];
        [userDef synchronize];
        
        [UIView animateWithDuration:0.3 animations:^{
            _yulanView.alpha = 0;
        } completion:^(BOOL finished) {
            [self returnBtnClick];
        }];
        
        return YES;
    }

    NSString *urlStr = request.URL.absoluteString;
    
    if ((!GGRar_isEmpty(_wUrStr) &&[urlStr containsString:_wUrStr])|| (!GGRar_isEmpty(_zUrStr) && [urlStr containsString:_zUrStr]))
    {
        NSURL *url = [NSURL URLWithString:request.URL.absoluteString];
        [[UIApplication sharedApplication] openURL:url];
    }
    
    return YES;
}
@end
