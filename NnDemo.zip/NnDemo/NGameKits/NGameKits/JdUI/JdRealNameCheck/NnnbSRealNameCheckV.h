//
//  NnnbSRealNameCheckV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol NnnbSRealNameCheckVDelegate <NSObject>

- (void)backToLastView;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbSRealNameCheckV : NnnbSSuperV<UITextFieldDelegate>
@property (nonatomic,weak) id <NnnbSRealNameCheckVDelegate>delegate;
@property (nonatomic, copy) NSString *tempString;
@end
