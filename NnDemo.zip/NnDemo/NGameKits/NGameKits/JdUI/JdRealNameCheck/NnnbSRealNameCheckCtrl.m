//
//  NnnbSRealNameCheckCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSRealNameCheckCtrl.h"

@interface NnnbSRealNameCheckCtrl ()

@end

@implementation NnnbSRealNameCheckCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    title.text = @"实名验证";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictRealNameCheckView];
}

- (void)depictRealNameCheckView{
    _realNameCheckView = [[NnnbSRealNameCheckV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _realNameCheckView.delegate = self;
    [self.bgView addSubview:_realNameCheckView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbSChangePswVDelegate
- (void)backToLastView{
    [self popView];
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
