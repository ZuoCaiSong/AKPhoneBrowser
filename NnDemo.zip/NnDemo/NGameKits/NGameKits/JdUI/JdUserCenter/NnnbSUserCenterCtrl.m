//
//  NnnbSUserCenterCtrl.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSUserCenterCtrl.h"
#import "NnnbSChangePswCtrl.h"
#import "NnnbSRealNameCheckCtrl.h"
#import "NnnbSBindPhoneCtrl.h"
#import "NnnbSAccLevelUpCtrl.h"

@interface NnnbSUserCenterCtrl ()<NnnbSAccLevelUpCtrlDelegate>

@end

@implementation NnnbSUserCenterCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    [self initHeaderView];

    [[NnnbSFloatW getInstance] removeWindow];

    [self depictUserCenterView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateBindPhoneSuccess:)
                                                 name:NN_NOTIF_BINDPHONE_SUCCESS
                                               object:nil];
}

- (void)initHeaderView{
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-180)/2, 2.5, 180, 40)];
    title.text = @"账户";
    title.textColor = [UIColor blackColor];
    title.font = [UIFont systemFontOfSize:20];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self.bgView addSubview:self.closeBtn];
}

- (void)depictUserCenterView{
    _userCenterView = [[NnnbSUserCenterV alloc] initWithFrame:CGRectMake(0, 45, self.bgView.width, self.bgView.height-45)];
    _userCenterView.delegate = self;
    [self.bgView addSubview:_userCenterView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - NnnbSUserCenterVDelegate
- (void)accToTopUpRecordView
{
    NnnbSTppRecordCtrl *rVC = [NnnbSFloatW getInstance].topUpRecordViewController;
    [self presentViewController:rVC animated:YES completion:nil];
}

- (void)accToChangePswView{
    NnnbSChangePswCtrl *cVc = [NnnbSFloatW getInstance].changePswViewController;
    [self presentViewController:cVc animated:YES completion:nil];
}

- (void)accToRealNameCheckView{
    NnnbSRealNameCheckCtrl *rVc = [NnnbSFloatW getInstance].realNameCheckViewController;
    [self presentViewController:rVc animated:YES completion:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateRealNameCheckSuccess:)
                                                 name:NN_NOTIF_CHECKPERSONID_SUCCESS
                                               object:nil];
}

- (void)accToBindPhoneView{
    NnnbSBindPhoneCtrl *bVc = [NnnbSFloatW getInstance].bindPhoneViewController;
    bVc.closeBtnRemove = YES;
    [self presentViewController:bVc animated:YES completion:nil];
}

- (void)updateBindPhoneSuccess:(NSNotification*)notif{
    if (_userCenterView.bindTelBtn != nil) {
        _userCenterView.bindTelBtn.enabled = NO;
    }
}

- (void)updateRealNameCheckSuccess:(NSNotification*)notif{
    if (_userCenterView.realNameBtn!= nil) {
        _userCenterView.realNameBtn.enabled = NO;
    }
}

- (void)presentToAccLevelUpView
{
    NnnbSAccLevelUpCtrl *accluCtrl = [[NnnbSAccLevelUpCtrl alloc] init];
    accluCtrl.delegate = self;
    [self presentViewController:accluCtrl animated:YES completion:nil];
}

#pragma mark - NnnbSAccLevelUpCtrlDelegate
- (void)closeUserCenterView
{
    [self closeView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
