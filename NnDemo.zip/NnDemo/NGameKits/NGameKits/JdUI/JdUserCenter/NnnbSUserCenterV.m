//
//  NnnbSUserCenterV.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSUserCenterV.h"
#import "NnnbSAccLevelUpCtrl.h"

#define offLeft_x_width 10   //左边off宽度
#define ACC_FUN_BTN_TAG 100
#define TIP_BIND_TEL_TAG 1000

#define btnHeight 40

@interface NnnbSUserCenterV ()<UIAlertViewDelegate>
@property (nonatomic,strong) UIAlertView *alertView;
@end

@implementation NnnbSUserCenterV

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    if (!([DataManger getInstance].currentUserInfo.isBind))
    {
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        BOOL bHasTip = [userDef boolForKey:kBingFlag];
        if (!bHasTip)
        {
            [userDef setBool:YES forKey:kBingFlag];
            [userDef synchronize];
            
            _alertView = [[UIAlertView alloc]initWithTitle:@"注意"
                                                   message:@"您的账号尚未绑定手机，忘记密码或者被盗时将无法通过手机找回密码！"
                                                  delegate:self
                                         cancelButtonTitle:@"稍后绑定"
                                         otherButtonTitles:@"立刻绑定", nil];
            _alertView.tag = TIP_BIND_TEL_TAG;
            _alertView.delegate = self;
            [_alertView show];
        }
    }
    NSString *tipc = @"充";
    NSString *tipj = @"值记录";
    NSString *tipjilu = [NSString stringWithFormat:@"%@%@",tipc,tipj];

    UIImage *img = [UIImage nnGetPlatImage:@"TygLightGray.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    
    NSArray *iconArr = [NSArray array];
    NSArray *titleArr = [NSArray array];

    if ([CommonData GetCommonDataInstance].accState == 1) {
        iconArr = @[@"TygAccGoUp.png",@"TygTopUpRecord.png",@"TygChangePwd.png",@"TygNameCheck.png",@"TygBindTel.png"];
        titleArr = @[@"账号升级",tipjilu,@"修改密码",@"实名验证",@"绑定手机"];
    } else {
        iconArr = @[@"TygTopUpRecord.png",@"TygChangePwd.png",@"TygNameCheck.png",@"TygBindTel.png"];
        titleArr = @[tipjilu,@"修改密码",@"实名验证",@"绑定手机"];
    }
    
    for (int i = 0; i < iconArr.count; i++) {
        NnnbSButton *btn = [NnnbSButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, i*btnHeight, self.width, btnHeight);
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setImage:[UIImage nnGetPlatImage:iconArr[i]] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage nnGetPlatImage:@"TygLightGray.png"] forState:UIControlStateHighlighted];
        [btn addTarget:self action:@selector(AccFunBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = ACC_FUN_BTN_TAG +i;
        [self addSubview:btn];
        
        if ([btn.titleLabel.text isEqualToString:@"实名验证"]) {
            _realNameBtn = btn;
            [btn setImage:[UIImage nnGetPlatImage:@"TygNameCheckEnable.png"] forState:UIControlStateDisabled];
            [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
            [btn setTitle:@"实名验证(已验证)" forState:UIControlStateDisabled];
            if ([DataManger getInstance].currentUserInfo.isCheck) {
                btn.enabled = NO;
            }
        }
        
        if ([btn.titleLabel.text isEqualToString:@"绑定手机"]) {
            _bindTelBtn = btn;
            [btn setImage:[UIImage nnGetPlatImage:@"TygBindTelEnable.png"] forState:UIControlStateDisabled];
            [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
            [btn setTitle:@"绑定手机(已绑定)" forState:UIControlStateDisabled];
            if ([DataManger getInstance].currentUserInfo.isBind) {
                btn.enabled = NO;
            }
        }
        
        UIImageView *arrowImg = [[UIImageView alloc] initWithFrame:CGRectMake(btn.width-11-20, (btnHeight-18)/2, 11, 18)];
        arrowImg.image = [UIImage nnGetPlatImage:@"TygRightJianTou.png"];
        [btn addSubview:arrowImg];
        
        UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(btn.titleLabel.left, btnHeight-1, btn.width-btn.titleLabel.left-20, 1)];
        line.backgroundColor = [UIColor lightGrayColor];
        line.alpha = 0.3;
        [btn addSubview:line];
    }
}

- (void)AccFunBtnClick:(UIButton *)btn{
    if ([btn.titleLabel.text isEqualToString:@"账号升级"]) {
        if (_delegate && [_delegate respondsToSelector:@selector(presentToAccLevelUpView)]) {
            [_delegate presentToAccLevelUpView];
        }
    }

    NSString *tipc = @"充";
    NSString *tipj = @"值记录";
    NSString *tipjilu = [NSString stringWithFormat:@"%@%@",tipc,tipj];
    if ([btn.titleLabel.text isEqualToString:tipjilu]) {
        [self.delegate accToTopUpRecordView];
    }

    if ([btn.titleLabel.text isEqualToString:@"修改密码"]) {
        [self.delegate accToChangePswView];
    }

    if ([btn.titleLabel.text isEqualToString:@"实名验证"]) {
        [self.delegate accToRealNameCheckView];
    }

    if ([btn.titleLabel.text isEqualToString:@"绑定手机"]) {
        [self.delegate accToBindPhoneView];
    }
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{    
    if (alertView.tag == TIP_BIND_TEL_TAG) {
        if (buttonIndex == 1) {
            [self.delegate accToBindPhoneView];
        }
    }
}

@end
