//
//  NnnbSUserCenterV.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSSuperV.h"

@protocol  NnnbSUserCenterVDelegate<NSObject>

- (void)accToTopUpRecordView;

- (void)accToChangePswView;

- (void)accToRealNameCheckView;

- (void)accToBindPhoneView;

- (void)presentToAccLevelUpView;

@end

@interface NnnbSUserCenterV : NnnbSSuperV
@property (nonatomic,weak) id<NnnbSUserCenterVDelegate>delegate;
@property (nonatomic,strong) UIButton *realNameBtn;
@property (nonatomic,strong) UIButton *bindTelBtn;
@end
