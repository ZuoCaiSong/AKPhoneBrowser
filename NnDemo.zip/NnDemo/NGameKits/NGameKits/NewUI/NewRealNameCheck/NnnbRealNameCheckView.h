//
//  NnnbRealNameCheckView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@protocol NnnbRealNameCheckViewDelegate <NSObject>

- (void)backToLastView;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbRealNameCheckView : NnnbSuperView<UITextFieldDelegate>
@property (nonatomic,weak) id <NnnbRealNameCheckViewDelegate>delegate;
@property (nonatomic, copy) NSString *tempString;
@end
