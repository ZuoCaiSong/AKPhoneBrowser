//
//  NnnbRealNameCheckView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbRealNameCheckView.h"

//左边off宽度
#define offLeft_x_width 20
//顶部off高度
#define offTop_x_height 30

@interface NnnbRealNameCheckView ()
@property (nonatomic,strong) UIImageView *fieldBgIv;
@property (nonatomic,strong) UITextField *realNameField;
@property (nonatomic,strong) UITextField *personIdField;
@property (nonatomic,strong) UIButton *confirmBtn;
@end

@implementation NnnbRealNameCheckView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    _tempString = @"";
    
    NSArray *labelArr = @[@"真实姓名：",@"身份证号："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+30), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height)];
        if (i == 0) {
            textField.returnKeyType = UIReturnKeyNext;
           
        } else {
            textField.returnKeyType = UIReturnKeyDone;
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
         textField.keyboardType = UIKeyboardTypeDefault;
        textField.delegate = self;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height+5, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        lineImg.tag = 10+i;
        [self addSubview:lineImg];
    }
    
    _realNameField = (UITextField *)[self viewWithTag:100];
    _personIdField = (UITextField *)[self viewWithTag:101];
    
    UIButton *confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    confirmBtn.frame = CGRectMake((self.width/2)-80, _personIdField.top+_personIdField.height+40, 80*2, 40);
    [confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
    [confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [confirmBtn setBackgroundImage:img forState:UIControlStateNormal];
    [confirmBtn addTarget:self action:@selector(confirmBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:confirmBtn];
}

#pragma mark - 确认按钮方法
- (void)confirmBtnClick{
    if ([_realNameField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入姓名" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_personIdField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入身份证号码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isChinese:_realNameField.text])
    {
        [NnnbTips depictCenterWithText:@"请输入中文姓名" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPersonID:_personIdField.text])
    {
        [NnnbTips depictCenterWithText:@"身份证格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_personIdField resignFirstResponder];
    [_realNameField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(confirm) withObject:nil afterDelay:0.5];
}

- (void)confirm{
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] checkPersonWithRealName:_realNameField.text personId:_personIdField.text result:^(BOOL success, NSNotification *notifi) {
        //等待界面
        [self removeLoadView];
        if (success) {
            //返回上个界面
            [self.delegate backToLastView];
            
            [NnnbTips depictCenterWithText:@"认证成功" duration:NN_TIPS_TIME2];
            [DataManger getInstance].currentUserInfo.isCheck = YES;
            
            //刷新个人中心实名认证
            [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_CHECKPERSONID_SUCCESS object:nil userInfo:nil];
        } else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _realNameField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _personIdField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _realNameField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _personIdField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _realNameField) {
        [_realNameField resignFirstResponder];
        [_personIdField becomeFirstResponder];
    } else {
        [_personIdField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _realNameField && string && string.length > 0){
        return YES;
    }
    
    if (textField == _personIdField && string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

- (void)textFieldChanged {
    
    UITextRange *selectedRange = [_realNameField markedTextRange];
    //获取高亮部分
    UITextPosition *pos = [_realNameField positionFromPosition:selectedRange.start offset:0];
    if (selectedRange && pos) {
        return;
    }
    
    NSString *text = _realNameField.text;
    for (NSInteger i = 0; i<text.length; i++) {
        unichar c = [text characterAtIndex:i];
        if(c >= 0x4E00 && c <= 0x9FA5) {
            //中文，OK
        }else {
            //非中文，不可以，还原
            _realNameField.text = self.tempString;
            return;
        }
    }
    //到这，说明一切OK，存一下
    self.tempString = _realNameField.text;
    
}

@end
