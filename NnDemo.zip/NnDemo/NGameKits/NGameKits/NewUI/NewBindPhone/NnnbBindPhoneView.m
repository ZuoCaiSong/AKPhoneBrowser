//
//  NnnbBindPhoneView.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbBindPhoneView.h"
#import "NnnbFacade+bandPhoneUpdateTimer.h"

//左边off宽度
#define offLeft_x_width 20
//顶部off高度
#define offTop_x_height 30

#define UPDATA_COUNT 40

#define getMesBtnWidth 90

@interface NnnbBindPhoneView ()
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@property (nonatomic,copy) NSString *phoneStr;
@end

@implementation NnnbBindPhoneView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *labelArr = @[@"手机号：",@"验证码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+30), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] init];
        if (i == 0) {
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height);
            textField.returnKeyType = UIReturnKeyNext;
        } else {
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2-getMesBtnWidth, label.height);
            textField.returnKeyType = UIReturnKeyDone;
            
            _getMesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            _getMesBtn.frame = CGRectMake(textField.left+textField.width ,textField.top, getMesBtnWidth, textField.height);
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            [_getMesBtn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateNormal];
            _getMesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
            [_getMesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:_getMesBtn];
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height+5, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        [self addSubview:lineImg];
    }
    
    _phoneField = (UITextField *)[self viewWithTag:100];
    _mesField = (UITextField *)[self viewWithTag:101];
    
    UIButton *bindBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bindBtn.frame = CGRectMake((self.width/2)-80, _mesField.top+_mesField.height+40, 80*2, 40);
    [bindBtn setTitle:@"确认" forState:UIControlStateNormal];
    [bindBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [bindBtn setBackgroundImage:img forState:UIControlStateNormal];
    [bindBtn addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:bindBtn];
}

#pragma mark - 获取验证码方法
- (void)getCheckBtnClick{
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入手机号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
    _getMesBtn.enabled = NO;
    
    //初始化定时器
    [[NnnbFacade getInstance] bandPhoneUpdateTimerSetTimerPara:@selector(updateTimerHandler:) object:self];
    [[NnnbFacade getInstance] bandPhoneUpdateTimerStartTimer];
    
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForUserBind:[DataManger getInstance].currentUserInfo.strUserName phone:_phoneField.text result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            NSString* strTips = @"验证码已发送";
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            
            _phoneStr = _phoneField.text;
        }
        else {
            [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
            _iUpdateCount = 0;
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            _getMesBtn.enabled = YES;
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE] integerValue];
            if (iErr != 1011) {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}

#pragma mark - 倒计时
/****************************************************
 *  函数名:  updateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         (NSNumber *)iCount          倒计时时间
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        [[NnnbFacade getInstance] bandPhoneUpdateTimerStopTimer];
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"重新获取" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    } else {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后获取", (long)z] forState:UIControlStateNormal];
    }
}

#pragma mark - 绑定手机方法
- (void)confirmClick{
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"手机号不能为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_phoneField.text isEqualToString:_phoneStr] && _phoneStr.length != 0) {
        [NnnbTips depictCenterWithText:@"手机号输入不一致" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(bindPhone) withObject:nil afterDelay:0.5];
}

- (void)bindPhone{
    [self conformButtonClick:_phoneField.text andyanzhengma:_mesField.text];
}

-(void)conformButtonClick:(NSString*)bindphoneN andyanzhengma:(NSString *)yanzhengma{
    [self depictLoadView];
    _phoneNum = bindphoneN;
    [[NnnbFacadeCenter defaultFacade] bindPhone:bindphoneN messageCode:yanzhengma result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [DataManger getInstance].currentUserInfo.isBind = YES;
            NSString *strTips = [NSString stringWithFormat:@"账号%@已成功绑定手机%@",
                                 [DataManger getInstance].currentUserInfo.strUserName,
                                 _phoneNum];
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            [self.delegate backToLastView];
            //刷新个人中心绑定手机
            [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_BINDPHONE_SUCCESS object:nil userInfo:nil];
        }else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _mesField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _phoneField) {
        [_phoneField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _phoneField && string && string.length > 0 && ![NnnbCommons isNumber:string]){
        return NO;
    }
    
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
