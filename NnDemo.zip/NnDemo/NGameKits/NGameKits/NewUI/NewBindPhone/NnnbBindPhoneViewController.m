//
//  NnnbBindPhoneViewController.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbBindPhoneViewController.h"

@interface NnnbBindPhoneViewController ()

@end

@implementation NnnbBindPhoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.closeBtnRemove) {
        self.closeBtn.hidden = YES;
        [self.closeBtn removeFromSuperview];
    } else {
        self.backBtn.hidden = YES;
        [self.backBtn removeFromSuperview];
        [[NnnbFloatWindow getInstance] removeWindow];
    }
    
    CGFloat titleWid = [NnnbLabelSizeToFit getWidthWithtext:@"绑定手机" font:[UIFont systemFontOfSize:18]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWid)/2, 5, titleWid, 30)];
    title.text = @"绑定手机";
    title.font = [UIFont systemFontOfSize:18];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictBindPhoneView];
}

- (void)depictBindPhoneView{
    _bindPhoneView = [[NnnbBindPhoneView alloc] initWithFrame:CGRectMake(0, self.titleIg.top+self.titleIg.height, self.bgView.width, self.bgView.height-self.titleIg.height)];
    _bindPhoneView.delegate = self;
    [self.bgView addSubview:_bindPhoneView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbBindPhoneViewDelegate
- (void)backToLastView{
    if (self.closeBtnRemove) {
        [self popView];
    } else {
        [[NnnbFloatWindow getInstance] depictWindow];
        [self closeView];
    }
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
