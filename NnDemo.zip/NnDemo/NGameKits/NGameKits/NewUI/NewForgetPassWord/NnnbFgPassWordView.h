//
//  NnnbFgPassWordView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@protocol NnnbFgPassWordViewDelegate <NSObject>

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

-(void)presentViewResetPassword:(NSString *)strAccount phone:(NSString *)strPhone mes:(NSString *)strMes;

@end

@interface NnnbFgPassWordView : NnnbSuperView
@property(nonatomic,weak)id<NnnbFgPassWordViewDelegate> delegate;
@end
