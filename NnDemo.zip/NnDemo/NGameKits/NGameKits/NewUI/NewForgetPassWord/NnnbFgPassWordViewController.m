//
//  NnnbFgPassWordViewController.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFgPassWordViewController.h"
#import "NnnbResetPswViewController.h"

@interface NnnbFgPassWordViewController ()
@end

@implementation NnnbFgPassWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    CGFloat titleWid = [NnnbLabelSizeToFit getWidthWithtext:@"忘记密码" font:[UIFont systemFontOfSize:18]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWid)/2, 5, titleWid, 30)];
    title.text = @"忘记密码";
    title.font = [UIFont systemFontOfSize:18];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictFgPassWordView];
}

- (void)depictFgPassWordView{
    _fgPassWordView = [[NnnbFgPassWordView alloc] initWithFrame:CGRectMake(0, self.titleIg.top+self.titleIg.height, self.bgView.width, self.bgView.height-self.titleIg.height)];
    _fgPassWordView.delegate = self;
    [self.bgView addSubview:_fgPassWordView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbFgPassWordViewDelegate
- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)presentViewResetPassword:(NSString *)strAccount phone:(NSString *)strPhone mes:(NSString *)strMes{
    NnnbResetPswViewController *rVc = [[NnnbResetPswViewController alloc] init];
    rVc.delegate = self;
    rVc.strAccount = strAccount;
    rVc.strPhone = strPhone;
    rVc.strMes = strMes;
    [self presentViewController:rVc animated:YES completion:nil];
}

#pragma mark - NnnbResetPswViewControllerDelegate
- (void)backTolastView{
    [self popView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
