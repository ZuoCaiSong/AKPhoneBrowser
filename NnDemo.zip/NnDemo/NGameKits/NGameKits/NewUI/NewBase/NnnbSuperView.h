//
//  NnnbSuperView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbLoadingView.h"
#import "NnnbTextField.h"

@interface NnnbSuperView : UIView<UITextFieldDelegate>
{
    //加载界面
    NnnbLoadingView    *_twLoadingView;
}

/****************************************************
 *  函数名:  depictLoadView
 *  功  能:  加载界面
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)depictLoadView;

/****************************************************
 *  函数名:  removeLoadView
 *  功  能:  加载界面
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)removeLoadView;
@end
