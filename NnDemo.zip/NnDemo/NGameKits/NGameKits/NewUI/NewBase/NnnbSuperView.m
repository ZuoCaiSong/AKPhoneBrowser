//
//  NnnbSuperView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@implementation NnnbSuperView

/****************************************************
 *  函数名:  depictLoadView
 *  功  能:  加载界面
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)depictLoadView
{
    if (_twLoadingView == nil)
    {
        _twLoadingView = [[NnnbLoadingView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    }
    
    //禁止操作
//    self.userInteractionEnabled = NO;
    MainWindow.userInteractionEnabled = NO;
    [_twLoadingView depictInView:self];
}

/****************************************************
 *  函数名:  removeLoadView
 *  功  能:  加载界面
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)removeLoadView
{
    if (_twLoadingView)
    {
        [_twLoadingView remove];
    }
    
    //允许操作界面
//    self.userInteractionEnabled = YES;
    MainWindow.userInteractionEnabled = YES;
}

@end
