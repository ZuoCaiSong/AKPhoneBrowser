//
//  NnnbChangePswViewController.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbChangePswViewController.h"

@interface NnnbChangePswViewController ()
@property (nonatomic,assign) NSInteger titleClickCounts;
@end

@implementation NnnbChangePswViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _titleClickCounts = 0;
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    UIButton *titleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    titleBtn.frame = CGRectMake((self.titleIg.width-180)/2, 5, 180, 30);
    titleBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [titleBtn setTitle:@"修改密码" forState:UIControlStateNormal];
    [titleBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [titleBtn addTarget:self action:@selector(titleBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.titleIg addSubview:titleBtn];
    [self.titleIg setUserInteractionEnabled:YES];
    
    [self depictChangePswView];
}

- (void)titleBtnClick:(UIButton *)btn{
    _titleClickCounts += 1;
    if (_titleClickCounts%3 == 0) {
        [btn setTitle:[NSString stringWithFormat:@"版本:v%@",NN_CURRENT_VERSION] forState:UIControlStateNormal];
    } else {
        [btn setTitle:@"修改密码" forState:UIControlStateNormal];
    }
}

- (void)depictChangePswView{
    _changePswView = [[NnnbChangePswView alloc] initWithFrame:CGRectMake(0, self.titleIg.top+self.titleIg.height, self.bgView.width, self.bgView.height-self.titleIg.height)];
    _changePswView.delegate = self;
    [self.bgView addSubview:_changePswView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbChangePswViewDelegate
- (void)backToLastView{
    [self popView];
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
