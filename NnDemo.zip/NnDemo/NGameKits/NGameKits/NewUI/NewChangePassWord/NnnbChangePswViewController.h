//
//  NnnbChangePswViewController.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperViewController.h"
#import "NnnbChangePswView.h"

@interface NnnbChangePswViewController : NnnbSuperViewController<NnnbChangePswViewDelegate>
{
    NnnbChangePswView *_changePswView;
}
@end
