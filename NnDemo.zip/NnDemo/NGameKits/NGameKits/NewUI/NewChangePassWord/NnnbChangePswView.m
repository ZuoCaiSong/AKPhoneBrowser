//
//  NnnbChangePswView.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbChangePswView.h"

//左边off宽度
#define offLeft_x_width 20
//顶部off高度
#define offTop_x_height 20

@interface NnnbChangePswView ()
@property (nonatomic,strong) UITextField *oldPswField;
@property (nonatomic,strong) UITextField *pswField;
@property (nonatomic,strong) UITextField *againpswField;
@end

@implementation NnnbChangePswView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *labelArr = @[@"旧  密  码：",@"新  密  码：",@"确认密码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+15), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height)];
        if (i != labelArr.count-1) {
            textField.returnKeyType = UIReturnKeyNext;
        } else {
            textField.returnKeyType = UIReturnKeyDone;
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.secureTextEntry = YES;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        [self addSubview:lineImg];
    }
    
    _oldPswField = (UITextField *)[self viewWithTag:100];
    _pswField = (UITextField *)[self viewWithTag:101];
    _againpswField = (UITextField *)[self viewWithTag:102];
    
    UIButton *confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    confirmBtn.frame = CGRectMake((self.width/2)-80, _againpswField.top+_againpswField.height+25, 80*2, 40);
    [confirmBtn setTitle:@"确认" forState:UIControlStateNormal];
    [confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [confirmBtn setBackgroundImage:img forState:UIControlStateNormal];
    [confirmBtn addTarget:self action:@selector(confirmBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:confirmBtn];
}

#pragma mark - 确认按钮方法
- (void)confirmBtnClick{
    if ([_oldPswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入旧密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_oldPswField.text isEqualToString:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"新密码不能与旧密码相同" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_pswField.text isEqualToString:_againpswField.text])
    {
        [NnnbTips depictCenterWithText:@"两次密码不一致， 请重新输入!" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_oldPswField resignFirstResponder];
    [_pswField resignFirstResponder];
    [_againpswField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(confirm) withObject:nil afterDelay:0.5];
}

- (void)confirm{
    [self depictLoadView];
    [[NnnbFacadeCenter defaultFacade] changeOldPsd:_oldPswField.text andXinPsd:_pswField.text result:^(BOOL success, NSNotification *notifi) {
        //移除等待界面
        [self removeLoadView];
        if (success) {
            
            //返回上个界面
            [self.delegate backToLastView];
            
            NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
            [keyChain nnStringSetObject:_pswField.text forKey:kUserCode];
            
            int rPsw = [[keyChain kcObjectForKey:kRememberPsw] intValue];
            if (rPsw == 1)
            {
                //需要记住密码
                [keyChain nnStringSetObject:_pswField.text forKey:kUserCode];
            }
            else
            {
                //不记住密码就把之前的旧密码数据清空
                [keyChain nnStringSetObject:@"" forKey:kUserCode];
            }
            
            [NnnbTips depictCenterWithText:@"修改密码成功" duration:NN_TIPS_TIME2];
        } else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _oldPswField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewTop:120];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _oldPswField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewBottom:120];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _oldPswField) {
        [_oldPswField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else if (textField == _pswField){
        [_pswField resignFirstResponder];
        [_againpswField becomeFirstResponder];
    } else {
        [_againpswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
