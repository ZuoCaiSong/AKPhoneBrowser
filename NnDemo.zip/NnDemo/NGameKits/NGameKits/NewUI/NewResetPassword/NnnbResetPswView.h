//
//  NnnbResetPswView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@protocol NnnbResetPswViewDelegate <NSObject>

- (void)backToLastView;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbResetPswView : NnnbSuperView
//账号
@property(nonatomic, copy) NSString* strAccount;

//手机号码
@property(nonatomic, copy) NSString* strPhone;

//验证码
@property(nonatomic, copy) NSString* strMes;

@property(nonatomic,weak)id<NnnbResetPswViewDelegate> delegate;
@end
