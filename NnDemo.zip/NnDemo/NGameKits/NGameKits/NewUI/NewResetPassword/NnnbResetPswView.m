//
//  NnnbResetPswView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbResetPswView.h"

//左边off宽度
#define offLeft_x_width 20
//顶部off高度
#define offTop_x_height 30

@interface NnnbResetPswView ()
@property (nonatomic,strong) UITextField *pswField;
@property (nonatomic,strong) UITextField *againpswField;
@property (nonatomic,strong) UIButton *confirmBtn;
@end

@implementation NnnbResetPswView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *labelArr = @[@"新  密  码：",@"确认密码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+30), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height)];
        if (i != labelArr.count-1) {
            textField.returnKeyType = UIReturnKeyNext;
        } else {
            textField.returnKeyType = UIReturnKeyDone;
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.secureTextEntry = YES;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height+5, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        [self addSubview:lineImg];
    }
    
    _pswField = (UITextField *)[self viewWithTag:100];
    _againpswField = (UITextField *)[self viewWithTag:101];
    
    UIButton *confirmBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    confirmBtn.frame = CGRectMake((self.width/2)-80, _againpswField.top+_againpswField.height+40, 80*2, 40);
    [confirmBtn setTitle:@"确定" forState:UIControlStateNormal];
    [confirmBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [confirmBtn setBackgroundImage:img forState:UIControlStateNormal];
    [confirmBtn addTarget:self action:@selector(confirmClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:confirmBtn];
}

#pragma mark - 确认按钮方法
- (void)confirmClick{
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_pswField.text isEqualToString:_againpswField.text])
    {
        [NnnbTips depictCenterWithText:@"两次密码不一致， 请重新输入!" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    [_pswField resignFirstResponder];
    [_againpswField resignFirstResponder];
    
    [self conformBtnClicknPsw:_againpswField.text];
}

- (void)conformBtnClicknPsw:(NSString *)nPsw{
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] resetPassword:self.strPhone account:self.strAccount messageCode:self.strMes andPsd:nPsw result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        if (success) {
            [NnnbTips depictCenterWithText:@"重置密码成功" duration:NN_TIPS_TIME2];
            [self.delegate backToLastView];
        }
        else {
            NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
        }
        
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _againpswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _pswField) {
        [_pswField resignFirstResponder];
        [_againpswField becomeFirstResponder];
    } else {
        [_againpswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
