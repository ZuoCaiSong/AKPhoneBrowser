//
//  NnnbResetPswViewController.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperViewController.h"
#import "NnnbResetPswView.h"

@protocol NnnbResetPswViewControllerDelegate <NSObject>

- (void)backTolastView;

@end

@interface NnnbResetPswViewController : NnnbSuperViewController<NnnbResetPswViewDelegate>
{
    NnnbResetPswView *_resetPswView;
}
//账号
@property(nonatomic, copy) NSString* strAccount;

//手机号码
@property(nonatomic, copy) NSString* strPhone;

//验证码
@property(nonatomic, copy) NSString* strMes;

@property(nonatomic,weak)id<NnnbResetPswViewControllerDelegate> delegate;
@end
