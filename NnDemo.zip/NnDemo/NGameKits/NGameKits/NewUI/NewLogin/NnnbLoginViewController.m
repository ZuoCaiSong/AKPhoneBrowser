//
//  NnnbLoginViewController.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbLoginViewController.h"
#import "NnnbLoginView.h"
#import "NnnbPhoneLoginView.h"
#import "NnnbScrollerView.h"
#import "NnnbRegisterViewController.h"
#import "NnnbFgPassWordViewController.h"
#import "NnnbFastRegisterViewController.h"

@interface NnnbLoginViewController ()<NnnbLoginViewDelegate,NnnbPhoneLoginViewDelegate,NnnbRegisterViewControllerDelegate,NnnbFastRegisterViewControllerDelegate>
@property (nonatomic,strong) NnnbLoginView *loginView;
@property (nonatomic,strong) NnnbPhoneLoginView *phoneLoginView;
@property (nonatomic,strong) NnnbScrollerView *scrollerView;
@end

@implementation NnnbLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    [[NnnbFloatWindow getInstance] removeWindow];
    
    [self.titleIg removeFromSuperview];
    [self depictLoginView];
}

- (void)depictLoginView{
    _scrollerView = [[NnnbScrollerView alloc] initWithFrame:CGRectMake(0, 0, self.bgView.width, self.bgView.height)];
    [self.bgView addSubview:_scrollerView];
    [self.view addSubview:self.bgView];
    
    NSArray *titleArr = @[@"手机",@"账号"];
    
    CGFloat titleHeight = 50;
    
    _phoneLoginView = [[NnnbPhoneLoginView alloc] initWithFrame:CGRectMake(0, 0, _scrollerView.width, _scrollerView.height-titleHeight)];
    _phoneLoginView.delegate = self;
    
    _loginView = [[NnnbLoginView alloc] initWithFrame:CGRectMake(0, 0, _phoneLoginView.width, _phoneLoginView.height)];
    _loginView.delegate = self;
    
    NSArray *viewsArr = @[_phoneLoginView,_loginView];
    
    [_scrollerView setWithTitles:titleArr TitlesHeight:titleHeight Views:viewsArr];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - NnnbLoginViewDelegate
- (void)getRegisterAccountSuccess:(NSString *)account andPsw:(NSString *)psw {
    NnnbRegisterViewController *rVC = [[NnnbRegisterViewController alloc]init];
    rVC.delegate = self;
    rVC.registerAccount = account;
    rVC.registerPsd = psw;
    [self presentViewController:rVC animated:YES completion:nil];
}

- (void)presentToFastRegisterViewWithAccount:(NSString *)account andPsw:(NSString *)psw{
    NnnbFastRegisterViewController *farc = [[NnnbFastRegisterViewController alloc] init];
    farc.delegate = self;
    [self presentViewController:farc animated:YES completion:nil];
}

- (void)presentToForgetPasswordView{
    NnnbFgPassWordViewController *fVC = [[NnnbFgPassWordViewController alloc]init];
    [self presentViewController:fVC animated:YES completion:nil];
}

- (void)closeLoginView{
    [self closeView];
}

- (void)moveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

- (void)moveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

#pragma mark - NnnbRegisterViewControllerDelegate
-(void)registerSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw{
    [_loginView NnnbLoginViewWithName:account password:psw];
}

#pragma mark - NnnbFastRegisterViewControllerDelegate
-(void)fastRegisterSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw{
    [_loginView NnnbLoginViewWithName:account password:psw];
}

#pragma mark - NnnbPhoneLoginViewDelegate
-(void)plMoveBgViewTop:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y -= moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

-(void)plMoveBgViewBottom:(NSInteger)moveNum{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:0.3];
    CGRect r = self.bgView.frame;
    r.origin.y += moveNum;
    self.bgView.frame = r;
    [UIView commitAnimations];
}

-(void)closePhoneLoginView{
    [self closeView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
