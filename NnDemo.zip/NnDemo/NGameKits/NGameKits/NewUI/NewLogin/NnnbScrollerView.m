//
//  NnnbScrollerView.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbScrollerView.h"

#define IndicatorViewAwayLeft 20

@interface NnnbScrollerView ()
@property (nonatomic,strong) UIImageView *titleView;
@property (nonatomic,strong) UIImageView *titleIndicatorView;
@property (nonatomic,strong) UIScrollView *contentScrollView;
@property (nonatomic,assign) CGFloat scale;
@property (nonatomic,assign) BOOL isDragging;
@end

@implementation NnnbScrollerView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

-(void)setWithTitles:(NSArray *)titleArr TitlesHeight:(CGFloat)titlesHeight Views:(NSArray *)viewArr{
    self.backgroundColor = [UIColor whiteColor];
    
    _titleView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, titlesHeight)];
    _titleView.userInteractionEnabled = YES;
    _titleView.image = [UIImage nnGetPlatImage:@"SygTopBg.png"];
    [self addSubview:_titleView];
    
    CGFloat titleBtnWidth = _titleView.frame.size.width / titleArr.count;
    
    for (int i = 0; i < titleArr.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(titleBtnWidth * i, 0, titleBtnWidth, _titleView.frame.size.height);
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateSelected];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        if (btn.tag == 101) {
            btn.selected = YES;
        }
        
        [_titleView addSubview:btn];
    }
    
    //添加提示视图
    _titleIndicatorView = [[UIImageView alloc] initWithFrame:CGRectMake(titleBtnWidth+IndicatorViewAwayLeft, _titleView.frame.size.height-2, titleBtnWidth-IndicatorViewAwayLeft*2, 2)];
    _titleIndicatorView.image = [UIImage nnGetPlatImage:@"SygGreenLine.png"];
    [_titleView addSubview:_titleIndicatorView];
    
    //创建ScrollView
    _contentScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _titleView.frame.origin.y+_titleView.frame.size.height, self.frame.size.width, self.frame.size.height-_titleView.frame.size.height)];
    _contentScrollView.pagingEnabled = YES;
    _contentScrollView.showsHorizontalScrollIndicator = NO;
    _contentScrollView.showsVerticalScrollIndicator = NO;
    _contentScrollView.delegate = self;
    _contentScrollView.bounces = NO;
    _contentScrollView.contentSize = CGSizeMake(_contentScrollView.width * titleArr.count, _contentScrollView.height);
    _contentScrollView.delaysContentTouches = NO;
    [self addSubview:_contentScrollView];
    
    for (int i=0; i < viewArr.count; i++) {
        UIView *uv = viewArr[i];
        CGRect u = uv.frame;
        u.origin.x = i*_contentScrollView.frame.size.width;
        uv.frame = u;
        
        [_contentScrollView addSubview:uv];
    }

    [self contentScrollViewShowPage:1];
    
    _scale = _titleIndicatorView.frame.size.width / (_contentScrollView.frame.size.width-IndicatorViewAwayLeft*4);
}

-(void)btnClick:(UIButton *)button
{
    for (UIButton *btn in _titleView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == button.tag) {
                btn.selected = YES;
            } else {
                btn.selected = NO;
            }
        }
    }
    
    [UIView animateWithDuration:0.2 animations:^{
        CGRect t = _titleIndicatorView.frame;
        t.origin.x = button.frame.origin.x+IndicatorViewAwayLeft;
        _titleIndicatorView.frame = t;
    }];
    
    _isDragging = NO;
    
    [self contentScrollViewShowPage:button.tag-100];
}

-(void)contentScrollViewShowPage:(NSInteger)page
{
    [_contentScrollView setContentOffset:CGPointMake(page * _contentScrollView.frame.size.width, 0) animated:YES];
}

#pragma mark - UIScrollViewDelegate
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    _isDragging = YES;
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger page = (scrollView.contentOffset.x / scrollView.frame.size.width)+100;

    for (UIButton *btn in _titleView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == page) {
                btn.selected = YES;

                [UIView animateWithDuration:0.2 animations:^{
                    CGRect t = _titleIndicatorView.frame;
                    t.origin.x = btn.frame.origin.x+IndicatorViewAwayLeft;
                    _titleIndicatorView.frame = t;
                }];
            } else {
                btn.selected = NO;
            }
        }
    }

    _isDragging = NO;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (_isDragging == YES) {
        CGRect r = _titleIndicatorView.frame;
        r.origin.x = (scrollView.contentOffset.x+IndicatorViewAwayLeft*2)*_scale;
        _titleIndicatorView.frame = r;
    }
}

@end
