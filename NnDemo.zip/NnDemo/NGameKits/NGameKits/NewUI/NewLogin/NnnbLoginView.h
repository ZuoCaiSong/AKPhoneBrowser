//
//  NnnbLoginView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbSuperView.h"

@protocol NnnbLoginViewDelegate <NSObject>

-(void)closeLoginView;

-(void)presentToForgetPasswordView;

-(void)presentToFastRegisterViewWithAccount:(NSString *)account andPsw:(NSString *)psw;

-(void)getRegisterAccountSuccess:(NSString *)account andPsw:(NSString *)psw;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbLoginView : NnnbSuperView
@property (nonatomic,weak) id<NnnbLoginViewDelegate> delegate;

/*
 外界登录用的接口
 */
-(void)NnnbLoginViewWithName:(NSString*)userName password:(NSString*)password;
@end
