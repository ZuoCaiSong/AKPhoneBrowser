//
//  NnnbPhoneLoginView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbPhoneLoginView.h"
#import "NnnbFacade+bandPhoneUpdateTimer.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbUserAccountManager.h"
#import "NnnbIAPManager.h"

#define offLeft_x_width 20  //左边off宽度
#define offTop_x_height 20   //顶部off高度
#define getMesBtnWidth 90

#define UPDATA_COUNT 40

@interface NnnbPhoneLoginView ()
@property (nonatomic,strong) UIImageView *fieldBgIv;
@property (nonatomic,strong) UITextField *phoneField;
@property (nonatomic,strong) UITextField *mesField;
@property (nonatomic,strong) UIButton *getMesBtn;
@property (nonatomic,assign) NSInteger iUpdateCount;
@property (nonatomic,copy) NSString *phoneStr;
@end

@implementation NnnbPhoneLoginView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *labelArr = @[@"手机号：",@"验证码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+10), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] init];
        if (i == 0) {
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height);
            textField.returnKeyType = UIReturnKeyNext;
        } else {
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2-getMesBtnWidth, label.height);
            textField.returnKeyType = UIReturnKeyDone;
        
            _getMesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            _getMesBtn.frame = CGRectMake(textField.left+textField.width ,textField.top, getMesBtnWidth, textField.height);
            [_getMesBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            [_getMesBtn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateNormal];
            _getMesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
            [_getMesBtn addTarget:self action:@selector(getCheckBtnClick) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:_getMesBtn];
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        [self addSubview:lineImg];
    }
    
    _phoneField = (UITextField *)[self viewWithTag:100];
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSString *phone = [keyChain nnPlatObjectForKey:kUserPhone];
    if (phone.length > 0) {
        _phoneField.text = phone;
    }
    
    _mesField = (UITextField *)[self viewWithTag:101];
    
    CGFloat tipLabWid = [NnnbLabelSizeToFit getWidthWithtext:@"手机登录无需注册！" font:[UIFont systemFontOfSize:17]];
    UILabel *tipLab = [[UILabel alloc] initWithFrame:CGRectMake((self.width/2)-(tipLabWid/2), _mesField.top+_mesField.height+20, tipLabWid, 30)];
    tipLab.text = @"手机登录无需注册！";
    tipLab.textColor = [UIColor lightGrayColor];
    tipLab.textAlignment = UITextAlignmentCenter;
    [self addSubview:tipLab];
    
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    loginBtn.frame = CGRectMake((self.width/2)-80, tipLab.top+tipLab.height+20, 80*2, 40);
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [loginBtn setBackgroundImage:img forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(phoneLoginClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:loginBtn];
}

#pragma mark - 获取验证码方法
- (void)getCheckBtnClick{
    [_phoneField resignFirstResponder];
    [_mesField resignFirstResponder];
    
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入手机号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //停止定时器
    [[NnnbFacade getInstance] verificationStopTimer];
    _getMesBtn.enabled = NO;
    
    //设置定时器参数
    [[NnnbFacade getInstance] verificationSetTimerPara:@selector(updateTimerHandler:) object:self];
    
    //开始定时器
    [[NnnbFacade getInstance] verificationStartTimer];
    [[NnnbFacadeCenter defaultFacade] getPhoneCodeForPhoneLogin:_phoneField.text result:^(BOOL success, NSNotification *notifi) {
        if (success) {
            //提示
            NSString* strTips = @"验证码已发送";
            [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            
            _phoneStr = _phoneField.text;
        }else {
            //停止定时器
            [[NnnbFacade getInstance] verificationStopTimer];
            _iUpdateCount = 0;
            _getMesBtn.enabled = YES;
            [_getMesBtn setTitle:@"重新获取" forState:UIControlStateNormal];
            
            NSInteger iErr = [[notifi.userInfo objectForKey:KEY_ERROR_CODE]integerValue];
            if (iErr != 1011)
            {
                NSString* strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }
    }];
}

/****************************************************
 *  函数名:  updateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         (NSNumber *)iCount          倒计时时间
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)updateTimerHandler:(NSNumber *)iCount
{
    _iUpdateCount = [iCount integerValue];
    
    if (_iUpdateCount >= UPDATA_COUNT)
    {
        //超时
        [[NnnbFacade getInstance] verificationStopTimer];
        
        _iUpdateCount = 0;
        [_getMesBtn setTitle:@"重新获取" forState:UIControlStateNormal];
        _getMesBtn.enabled = YES;
    }
    else
    {
        _getMesBtn.enabled = NO;
        NSInteger z = (UPDATA_COUNT - _iUpdateCount);
        [_getMesBtn setTitle:[NSString stringWithFormat:@"%ld秒后获取",(long)z] forState:UIControlStateNormal];
    }
}

#pragma mark - 登录按钮点击
- (void)phoneLoginClick{
    if ([_phoneField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"手机号不能为空" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons isPhoneNumber:_phoneField.text])
    {
        [NnnbTips depictCenterWithText:@"手机号码格式不正确！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_mesField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入验证码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![_phoneField.text isEqualToString:_phoneStr] && _phoneStr.length != 0) {
        [NnnbTips depictCenterWithText:@"手机号输入不一致" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_mesField resignFirstResponder];
    [_phoneField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(doPhoneLogin) withObject:nil afterDelay:0.5];
}

- (void)doPhoneLogin{
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] phoneloginNumber:_phoneField.text messageCode:_mesField.text result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        
        if (success) {
            [self phoneLoginResultHandler:notifi];
        } else {
            //提示错误
            NSString* errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

//登录成功
- (void)phoneLoginResultHandler:(NSNotification*)notif
{
    NSString *psw = [notif.userInfo objectForKey:@"p"];
    
    //保存用户名和用户密码
    [DataManger getInstance].currentUserInfo.strUserName = _phoneField.text;
    [DataManger getInstance].currentUserInfo.strUserPassWord = psw;
    
    NnnbKeyChain *keychain = [NnnbKeyChain standardKeyChain];
    [keychain nnStringSetObject:_phoneField.text forKey:kUserPhone];
    [keychain nnStringSetObject:psw forKey:kUserPhonePsw];
    [keychain kcSetObject:PhoneLogin forKey:LoginType];
    
    //抛出登录成功的消息
    [NnnbCommons postLoginSuccessMsg];
    
    [[NnnbIAPManager sharedManager] checkReceipt];
    
    [[NnnbFloatWindow getInstance] depictWindow];
    
    [self.delegate closePhoneLoginView];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate plMoveBgViewTop:60];
    }
    
    if (textField == _mesField) {
        [self.delegate plMoveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _phoneField) {
        [self.delegate plMoveBgViewBottom:60];
    }
    
    if (textField == _mesField) {
        [self.delegate plMoveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _phoneField) {
        [_phoneField resignFirstResponder];
        [_mesField becomeFirstResponder];
    } else {
        [_mesField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == _phoneField && string && string.length > 0 && ![NnnbCommons isNumber:string]){
        return NO;
    }
    
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
