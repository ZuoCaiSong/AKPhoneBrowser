//
//  NnnbLoginView.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbLoginView.h"
#import "NnnbColorEx.h"
#import "NnnbIAPManager.h"
#import "NnnbUserAccountManager.h"

#define offLeft_x_width 20   //左边off宽度
#define offTop_x_height 15   //顶部off高度
#define raBtnHeight 40
#define ACC_CHOOSE_TAG 2000 //是否记住账号 密码

@interface NnnbLoginView ()<UIAlertViewDelegate,NnnbUserMenuDelegate>
@property (nonatomic,assign) CGFloat labWid;
@property (nonatomic,strong) UIButton *selectUserBtn;
@property (nonatomic,strong) UITextField *accountField;
@property (nonatomic,strong) UITextField *pswField;
@property (nonatomic,strong) UIImageView *line1;
@property (nonatomic,strong) UIImageView *line2;
@property (nonatomic,strong) UIButton *remePswBtn;
@property (nonatomic,strong) UIAlertView* loginAlertView;
@property (nonatomic,strong) NSTimer *loginTimer;
@property (nonatomic,copy) NSString *userName;
@property (nonatomic,copy) NSString *userCode;
@property (nonatomic,strong) NnnbUserMenu *userMenu;
@end

@implementation NnnbLoginView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    [self initTextField];
    [self initAccChoose];
    [self initBtnView];
}

#pragma mark - 输入框
- (void)initTextField{
    NSArray *labelArr = @[@"账号：",@"密码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        _labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+10), _labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] init];
        if (i == 0) {
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height);
            textField.returnKeyType = UIReturnKeyNext;
            
            _selectUserBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            _selectUserBtn.tag = 108;
            _selectUserBtn.frame = CGRectMake(textField.width-label.height, 0, label.height, label.height);
            [_selectUserBtn setImage:[UIImage nnGetPlatImage:@"SygArrowBottom.png"] forState:UIControlStateNormal];
            [_selectUserBtn setImage:[UIImage nnGetPlatImage:@"SygArrowTop.png"] forState:UIControlStateSelected];
            [_selectUserBtn addTarget:self action:@selector(depictSelectUserAccount:) forControlEvents:UIControlEventTouchUpInside];
            [textField addSubview:_selectUserBtn];
        } else {
            CGFloat forgetPswBtnWid = [NnnbLabelSizeToFit getWidthWithtext:@"忘记密码" font:[UIFont systemFontOfSize:17]];
            
            textField.frame = CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2-forgetPswBtnWid, label.height);
            textField.returnKeyType = UIReturnKeyDone;
            textField.secureTextEntry = YES;
            
            UIButton *forgetPswBtn = [UIButton buttonWithType:UIButtonTypeSystem];
            forgetPswBtn.frame = CGRectMake(textField.left+textField.width, textField.top, forgetPswBtnWid, label.height);
            forgetPswBtn.titleLabel.font = [UIFont systemFontOfSize:17];
            [forgetPswBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
            [forgetPswBtn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateNormal];
            [forgetPswBtn addTarget:self action:@selector(forgetPasswordBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:forgetPswBtn];
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        lineImg.tag = 10+i;
        [self addSubview:lineImg];
    }
    
    _accountField = (UITextField *)[self viewWithTag:100];
    _pswField = (UITextField *)[self viewWithTag:101];
    _line1 = (UIImageView *)[self viewWithTag:10];
    _line2 = (UIImageView *)[self viewWithTag:11];
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSString *Reserve_Name = [keyChain nnPlatObjectForKey:kUserName];
    if (Reserve_Name != nil && Reserve_Name.length > 0) {
        _accountField.text = Reserve_Name;
        _pswField.text = [keyChain nnPlatObjectForKey:kUserCode];
    }
}

#pragma mark - 忘记密码按钮方法
-(void)forgetPasswordBtnClick:(UIButton*)btn{
    [self.delegate presentToForgetPasswordView];
}

#pragma mark - 记住密码、自动登录
- (void)initAccChoose
{
    NSArray *titleArr = @[@"记住密码",@"自动登录"];
    
    NSInteger direction = [[CommonData GetCommonDataInstance] judgeDirection];
    
    for (int i = 0; i < titleArr.count; i ++) {
        UIButton *acBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        // 横竖屏判断
        if (direction == 1)
        {
            acBtn.frame = CGRectMake(_line2.left+(i%2)*(100+10), _pswField.top+_pswField.height+5, 100, raBtnHeight);
            acBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
           
        }
        else
        {
            if(isIPhone55S5CSE)
            {
                acBtn.frame = CGRectMake(_line2.left+(i%2)*(80+10), _pswField.top+_pswField.height+5, 80, raBtnHeight);
            }
            else
            {
                acBtn.frame = CGRectMake(_line2.left+(i%2)*(100+10), _pswField.top+_pswField.height+5, 100, raBtnHeight);
            }
            acBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -5, 0, 0);
            acBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -2, 0, 0);
        }
         acBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        
        acBtn.tag = ACC_CHOOSE_TAG+i;
        [acBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [acBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [acBtn setImage:[UIImage nnGetPlatImage:@"SygRememberAccNo.png"] forState:UIControlStateNormal];
        [acBtn setImage:[UIImage nnGetPlatImage:@"SygRememberAcc.png"] forState:UIControlStateSelected];
        [acBtn addTarget:self action:@selector(raBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:acBtn];
        
        NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
        int rememberPsw = [[keyChain kcObjectForKey:kRememberPsw] intValue];
        int autoLogin = [[keyChain kcObjectForKey:kAutoLogin] intValue];
        
        //首次安装默认勾选记住密码
        NSString *strfisrtInstall = [keyChain kcObjectForKey:firstInstall];
        
        if ([strfisrtInstall isEqualToString:@"notFirstInstall"]) {
            if(rememberPsw == 1 && acBtn.tag == ACC_CHOOSE_TAG){
                acBtn.selected = YES;
            }
        } else {
            if(acBtn.tag == ACC_CHOOSE_TAG){
                acBtn.selected = YES;
            }
            
            [keyChain kcSetObject:@"notFirstInstall" forKey:firstInstall];
        }
        
        NSString *userName = [keyChain nnPlatObjectForKey:kUserName];
        if (autoLogin == 1 && acBtn.tag == ACC_CHOOSE_TAG + 1)
        {
            acBtn.selected = YES;
            
            if (userName.length > 0)
            {
                self.loginAlertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                                message:@"正在登录中..."
                                                               delegate:self
                                                      cancelButtonTitle:@"取消"
                                                      otherButtonTitles:nil];
                self.loginAlertView.tag = 100002;
                
                self.loginAlertView.delegate = self;
                
                [self.loginAlertView show];
                
                self.loginTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(loginClick) userInfo:nil repeats:NO];
            }
        }
    }
    
    _remePswBtn = (UIButton *)[self viewWithTag:ACC_CHOOSE_TAG];
}

- (void)raBtnClick:(UIButton *)btn{
    if (btn.selected == YES) {
        if (btn.tag == ACC_CHOOSE_TAG) {
            for (UIButton *button in self.subviews) {
                if (button.tag == ACC_CHOOSE_TAG || button.tag == ACC_CHOOSE_TAG +1) {
                    button.selected = NO;
                }
            }
        }
        btn.selected = NO;
    } else {
        if (btn.tag == ACC_CHOOSE_TAG + 1) {
            for (UIButton *button in self.subviews) {
                if (button.tag == ACC_CHOOSE_TAG || button.tag == ACC_CHOOSE_TAG + 1) {
                    button.selected = YES;
                }
            }
        }
        
        btn.selected = YES;
    }
}

#pragma mark - 注册登录按钮
- (void)initBtnView{
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    loginBtn.frame = CGRectMake(offLeft_x_width, _remePswBtn.top+_remePswBtn.height+5, self.width-(offLeft_x_width*2), 40);
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [loginBtn setBackgroundImage:img forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(loginClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:loginBtn];
    
    CGFloat registerBtnWid = [NnnbLabelSizeToFit getWidthWithtext:@"注册" font:[UIFont systemFontOfSize:18]];
    UIButton *registerBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    registerBtn.frame = CGRectMake(offLeft_x_width, loginBtn.top+loginBtn.height+5, registerBtnWid, 40);
    registerBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    [registerBtn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateNormal];
    [registerBtn addTarget:self action:@selector(regiseterBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:registerBtn];
    
    CGFloat forgetPswBtnWid = [NnnbLabelSizeToFit getWidthWithtext:@"一键注册" font:[UIFont systemFontOfSize:18]];
    UIButton *forgetPswBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    forgetPswBtn.frame = CGRectMake(self.width-offLeft_x_width-forgetPswBtnWid, registerBtn.top, forgetPswBtnWid, 40);
    forgetPswBtn.titleLabel.font = [UIFont systemFontOfSize:18];
    [forgetPswBtn setTitle:@"一键注册" forState:UIControlStateNormal];
    [forgetPswBtn setTitleColor:RGBCOLOR(38, 180, 144) forState:UIControlStateNormal];
    [forgetPswBtn addTarget:self action:@selector(fastRegisterClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:forgetPswBtn];
}

#pragma mark - 注册按钮方法
- (void)regiseterBtnClick:(UIButton*)btn{
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    if (_delegate && [_delegate respondsToSelector:@selector(getRegisterAccountSuccess:andPsw:)]) {
        [_delegate getRegisterAccountSuccess:@"" andPsw:@""];
    }
}

#pragma mark - 一键注册方法
- (void)fastRegisterClick{
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    [self depictLoadView];
    
    [[NnnbFacadeCenter defaultFacade] fastRegistWithAccount:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        
        if (success) {
            [self registQuickResultHandler:notifi];
        }
        else {
            //提示错误
            NSString* errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)registQuickResultHandler:(NSNotification*)notif
{
    [CommonData GetCommonDataInstance].autoRememberAndLogin = YES;
    
    NSString* strValue = [notif.userInfo objectForKey:@"uname"];
    NSString* strPassword = [notif.userInfo objectForKey:@"pwd"];
    NSString* strTips = [NSString stringWithFormat:@"您的账号:%@\n您的密码:%@\n%@",
                         strValue, strPassword, @"保存好账号和密码！请到个人中心里修改密码和绑定手机号！"];
    
    _userName = strValue;
    _userCode = strPassword;
    
    UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:strTips
                                                      delegate:self
                                             cancelButtonTitle:@"完成并登录"
                                             otherButtonTitles:nil];
    alertView.tag = 1000;
    
    alertView.delegate = self;
    
    [alertView show];
}

#pragma mark - 登录按钮方法
- (void)loginClick{
    if (self.loginAlertView) {
        [self.loginAlertView dismissWithClickedButtonIndex:0 animated:NO];
        self.loginAlertView = nil;
    }
    
    if (self.loginTimer) {
        [self.loginTimer invalidate];
        self.loginTimer = nil;
    }
    
    if([NnnbCommons isFastDoubleClickInSecond:2.0 TagStr:@"depictLoginView"]){
        [NnnbTips depictCenterWithText:@"请勿频繁点击，稍等片刻再操作" duration:NN_TIPS_TIME2];
        return;
    }
    
    if ([_accountField.text length] <= 0){
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text]){
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] <= 0){
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text]){
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(login) withObject:nil afterDelay:0.5];
}

- (void)login{
    [self NnnbLoginViewWithName:_accountField.text password:_pswField.text];
}

- (void)NnnbLoginViewWithName:(NSString*)userName password:(NSString*)password{
    //等待加载节目单
    [self depictLoadView];
    
    _userName = userName;
    _userCode = password;
    
    [[NnnbFacadeCenter defaultFacade] loginWithName:userName password:password result:^(BOOL success, NSNotification *notifi) {
        //移除加载等待界面
        [self removeLoadView];
        if (success) {
            [self loginResultHandler:notifi];
        }
        else {
            NSString *errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

- (void)loginResultHandler:(NSNotification*)notif
{
    //保存用户名和用户密码
    [DataManger getInstance].currentUserInfo.strUserName = _userName;
    [DataManger getInstance].currentUserInfo.strUserPassWord = _userCode;
    
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    [keyChain kcSetObject:AccountLogin forKey:LoginType];
    
    [keyChain nnStringSetObject:_userName forKey:kUserName];
    
    NSString *rememberPsw = [NSString new];
    NSString *autoLogin = [NSString new];
    
    if ([CommonData GetCommonDataInstance].autoRememberAndLogin == YES) {
        [CommonData GetCommonDataInstance].autoRememberAndLogin = NO;
        rememberPsw = @"1";
        autoLogin = @"1";
        [keyChain kcSetObject:@"1" forKey:kRememberPsw];
        [keyChain nnStringSetObject:_userCode forKey:kUserCode];
        [keyChain kcSetObject:@"1" forKey:kAutoLogin];
    } else {
        for (UIButton *button in self.subviews) {
            if (button.tag == ACC_CHOOSE_TAG) {
                if (button.selected == YES) {
                    rememberPsw = @"1";
                    [keyChain kcSetObject:@"1" forKey:kRememberPsw];
                    [keyChain nnStringSetObject:_userCode forKey:kUserCode];
                } else {
                    rememberPsw = @"0";
                    [keyChain kcSetObject:@"0" forKey:kRememberPsw];
                    [keyChain nnStringSetObject:@"" forKey:kUserCode];
                }
            }
            
            if (button.tag == ACC_CHOOSE_TAG+1) {
                if (button.selected == YES) {
                    autoLogin = @"1";
                    [keyChain kcSetObject:@"1" forKey:kAutoLogin];
                } else {
                    autoLogin = @"0";
                    [keyChain kcSetObject:@"0" forKey:kAutoLogin];
                }
            }
        }
    }
    
    [[NnnbUserAccountManager getInstance] setLoginAccount:_userName andPwd:_userCode andRememberPsw:rememberPsw andAutoLogin:autoLogin];
    
    //抛出登录成功的消息
    [NnnbCommons postLoginSuccessMsg];
    
    [[NnnbIAPManager sharedManager] checkReceipt];
    
    //保证每次登录成功后展现
    [[NnnbFloatWindow getInstance] depictWindow];
    
    [self.delegate closeLoginView];
}

#pragma mark - 选择用户
- (void)depictSelectUserAccount:(UIButton*)btn{
    [_accountField resignFirstResponder];
    
    if(btn.selected == NO) {
        [self.userMenu showMenu];
    }
    else {
        [self.userMenu hideMenu];
    }
    
    btn.selected = !btn.selected;
}

#pragma mark - 下拉用户菜单
//LMJDropdownMenu Delegate
- (void)dropdownMenu:(NnnbUserMenu *)menu selectedCellNumber:(NSInteger)number
{
    NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
    NSDictionary *dic = [userAccountArr objectAtIndex:number];
    _accountField.text = [dic objectForKey:@"login_userId"];
    _pswField.text = [dic objectForKey:@"login_pwd"];
    
    self.selectUserBtn.selected = NO;
}

- (void)dropdownMenuWithDeleteAtIndex:(NSInteger)index
{
    NSArray *accountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
    
    [[NnnbUserAccountManager getInstance] deleteAccountWithIndex:(index % accountArr.count)];
}

//懒加载
- (NnnbUserMenu *)userMenu{
    if (_userMenu == nil) {
        _userMenu = [[NnnbUserMenu alloc] init];
        [_userMenu setFrame:CGRectMake(CGRectGetMinX(_line1.frame), _line1.tp_bottom, _line1.width, raBtnHeight)];
        _userMenu.delegate = self;
        [self addSubview:_userMenu];
        
        NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
        NSMutableArray * dataArray = [NSMutableArray array];
        for (NSDictionary * dict in userAccountArr) {
            [dataArray addObject:dict[@"login_userId"]];
        }
        
        [_userMenu setMenuWords:dataArray rowHeight:raBtnHeight];
    }
    
    return _userMenu;
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.userMenu hideMenu];
    self.selectUserBtn.selected = NO;
    
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    if (textField.text && textField.text.length > 0 && [NnnbCommons checkChinese:textField.text]){
        //输入数据里面包括了汉字
        textField.text = @"";
        
        [NnnbTips depictCenterWithText:@"亲，不能输入汉字哦！" duration:NN_TIPS_TIME2];
    }
    
    if (textField == _accountField){
        [self.delegate moveBgViewBottom:60];
        
        //帐号只能是字母，数字和下划线
        if (textField.text && textField.text.length > 0 && ![NnnbCommons checkAccount:textField.text])
        {
            textField.text = @"";
            
            [NnnbTips depictCenterWithText:@"亲，请输入数字、字母或者下划线！" duration:NN_TIPS_TIME2];
        }
        
        NSArray *userAccountArr = [[NnnbUserAccountManager getInstance] getLoginAccounts];
        
        for (NSDictionary *dict in userAccountArr) {
            NSString *user_Account = [dict objectForKey:@"login_userId"];
            
            if ([user_Account isEqualToString:_accountField.text]) {
                _pswField.text = [dict objectForKey:@"login_pwd"];
                return;
            } else {
                _pswField.text = nil;
            }
        }
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField){
        [_accountField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else {
        [_pswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField) {
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= 32) || (textField.text && (textField.text.length + string.length > 32))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

#pragma mark - UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 1000) {
        [self loginResultHandler:nil];
    }
    
    if (alertView.tag == 100002) {
        if (self.loginTimer) {
            [self.loginTimer invalidate];
            self.loginTimer = nil;
        }
    }
}

@end

