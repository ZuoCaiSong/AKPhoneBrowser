//
//  NnnbPhoneLoginView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSuperView.h"

@protocol NnnbPhoneLoginViewDelegate <NSObject>

-(void)plMoveBgViewTop:(NSInteger)moveNum;

-(void)plMoveBgViewBottom:(NSInteger)moveNum;

-(void)closePhoneLoginView;

@end

@interface NnnbPhoneLoginView : NnnbSuperView<UITextFieldDelegate>
@property (nonatomic,weak) id<NnnbPhoneLoginViewDelegate> delegate;
@end
