//
//  NnnbFloatWindow.h
//  testTab
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NnnbLoginViewController.h"
#import "NnnbTppCenterViewController.h"
#import "NnnbUserCenterViewController.h"
#import "NnnbBindPhoneViewController.h"

@interface NnnbFloatWindow : UIView

+(NnnbFloatWindow *)getInstance;

// 设置
- (void)setIsdepictFloat:(BOOL)bdepictFloat;

- (void)depictWindow;

- (void)removeWindow;

@property (nonatomic,strong) NnnbLoginViewController *loginViewController;
@property (nonatomic,strong) NnnbTppCenterViewController *topUpCenterController;
@property (nonatomic,strong) NnnbUserCenterViewController *userCenterController;
@property (nonatomic,strong) NnnbBindPhoneViewController *bindPhoneController;
@end
