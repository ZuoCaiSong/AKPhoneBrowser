//
//  NnnbTppCenterView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbTppCenterView.h"
#import "NnnbColorEx.h"
#import "NnnbIAPManager.h"
#import "NnnbFacade+Get.h"
#import "NnnbScrollLabelView.h"

@interface NnnbTppCenterView ()
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *jinLable;
@property (nonatomic,strong) UILabel *chTypeLable;
@property (nonatomic,strong) UIButton *confirmBtn;
@property (nonatomic,strong) UIImageView  *headFootLine;
@property (nonatomic,strong) UIImageView  *chBtnBgView;
@property (nonatomic,assign) int chType;
@property (nonatomic,assign) NSInteger direction;
@property (nonatomic,strong) NSArray *titleArr;
@property (nonatomic,strong) NSArray *imageArr;
@end

@implementation NnnbTppCenterView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    _direction = [[CommonData GetCommonDataInstance] judgeDirection];
    
    UILabel *serverNameLab = [[UILabel alloc] init];
    serverNameLab.text = [NSString stringWithFormat:@"【%@】",[CommonData GetCommonDataInstance].strServerName];
    serverNameLab.textColor = RGBCOLOR(105, 186, 242);
    serverNameLab.textAlignment = UITextAlignmentCenter;
    [self addSubview:serverNameLab];
    
    CGFloat serverNameLabWid = [NnnbLabelSizeToFit getWidthWithtext:serverNameLab.text font:[UIFont systemFontOfSize:17]];
    CGFloat halfSelfWid = self.width/2;
    
    if ([CommonData GetCommonDataInstance].pmdStr.length > 0) {
        UIView *pmdBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 30)];
        pmdBgView.backgroundColor = RGBCOLOR(255, 245, 227);
        [self addSubview:pmdBgView];
        
        UIImageView *soundImg = [[UIImageView alloc] initWithFrame:CGRectMake(15, 5, 20, 20)];
        NSArray *gifArray = [NSArray arrayWithObjects:[UIImage nnGetPlatImage:@"SygSound1.png"],[UIImage nnGetPlatImage:@"SygSound2.png"],[UIImage nnGetPlatImage:@"SygSound3.png"],nil];
        soundImg.animationImages = gifArray;
        soundImg.animationDuration = 3; //执行一次完整动画所需的时长
        [soundImg startAnimating];
        [pmdBgView addSubview:soundImg];
        
        NnnbScrollLabelView *scrollView = [NnnbScrollLabelView scrollWithTitle:[CommonData GetCommonDataInstance].pmdStr type:NnnbScrollLabelViewTypeLeftRight velocity:1 options:UIViewAnimationOptionCurveEaseInOut];
        scrollView.frame = CGRectMake(soundImg.left+soundImg.width+10, 0, self.width-soundImg.width-25, 30);
        scrollView.scrollTitleColor = RGBCOLOR(255, 106, 91);
        scrollView.backgroundColor = RGBCOLOR(255, 245, 227);
        [pmdBgView addSubview:scrollView];
        [scrollView beginScrolling];
        
        serverNameLab.frame = CGRectMake(halfSelfWid-(serverNameLabWid/2), pmdBgView.top+pmdBgView.height+5, serverNameLabWid, 30);
    } else {
        serverNameLab.frame = CGRectMake(halfSelfWid-(serverNameLabWid/2), 15, serverNameLabWid, 30);
    }
    
    CGFloat jqLabWidth = [NnnbLabelSizeToFit getWidthWithtext:[NSString stringWithFormat:@"%lu元获得%@",(unsigned long)[CommonData GetCommonDataInstance].ijin,[CommonData GetCommonDataInstance].strProductName] font:[UIFont boldSystemFontOfSize:28]];
    UILabel *jqLab = [[UILabel alloc] initWithFrame:CGRectMake((self.width/2)-(jqLabWidth/2), serverNameLab.top+serverNameLab.height+5, jqLabWidth, 30)];
    jqLab.text = [NSString stringWithFormat:@"%lu元获得%@",(unsigned long)[CommonData GetCommonDataInstance].ijin,[CommonData GetCommonDataInstance].strProductName];
    jqLab.font = [UIFont boldSystemFontOfSize:18];
    jqLab.textColor = RGBCOLOR(244, 188, 14);
    jqLab.textAlignment = UITextAlignmentCenter;
    [self addSubview:jqLab];
    
    UIImageView *leftline = [[UIImageView alloc] initWithFrame:CGRectMake(0, jqLab.top+jqLab.height+25, (self.width-100)/2, 1)];
    leftline.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:leftline];
    
    UILabel *typeLab = [[UILabel alloc] initWithFrame:CGRectMake((self.width-150)/2, leftline.top-10, 150, 20)];
    typeLab.text = @"请选择方式";
    typeLab.font = [UIFont systemFontOfSize:15];
    typeLab.textAlignment = UITextAlignmentCenter;
    [self addSubview:typeLab];
    
    UIImageView *rightline = [[UIImageView alloc] initWithFrame:CGRectMake(self.width-leftline.width, leftline.top, leftline.width, 1)];
    rightline.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:rightline];
    
    NSString *wfStr1 = @"微";
    NSString *wfStr2 = @"信";
    NSString *wfStrTip = [NSString stringWithFormat:@"%@ %@",wfStr1,wfStr2];
    
    NSString *zfStr1 = @"支";
    NSString *zfStr2 = @"付";
    NSString *zfStr3 = @"宝";
    NSString *zfStrTip = [NSString stringWithFormat:@"%@ %@ %@",zfStr1,zfStr2,zfStr3];
    
    NSString *ngStr1 = @"苹";
    NSString *ngStr2 = @"果";
    NSString *ngStrTip = [NSString stringWithFormat:@"%@ %@",ngStr1,ngStr2];
    
    NSInteger depictRechargeCount = [[CommonData GetCommonDataInstance] iSAppleRecharge];
    
    if (depictRechargeCount == 1) {
        _imageArr = @[@"SygGreen.png",@"SygBlue.png",@"SygPurple.png"];
        _titleArr = @[wfStrTip,zfStrTip,ngStrTip];
    } else {
        _imageArr = @[@"SygGreen.png",@"SygBlue.png"];
        _titleArr = @[wfStrTip,zfStrTip];
    }
    
    for (int i = 0; i < _titleArr.count; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage nnGetPlatImage:_imageArr[i]] forState:UIControlStateNormal];
        [btn setTitle:_titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(chButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        if (_direction == 1) {
            if (depictRechargeCount == 1) {
                btn.frame = CGRectMake((self.width/2)-(60+40+30)+(i%3)*(60+40), typeLab.top+typeLab.height+15+5, 60, 60);
            } else {
                btn.frame = CGRectMake((self.width/2)-(60+40)+(i%3)*(60+80), typeLab.top+typeLab.height+15+5, 60, 60);
            }
        } else {
            if (depictRechargeCount == 1) {
                btn.frame = CGRectMake((self.width/2)-(60+30+30)+(i%3)*(60+30), typeLab.top+typeLab.height+15+5, 60, 60);
            } else {
                btn.frame = CGRectMake((self.width/2)-(60+30)+(i%3)*(60+60), typeLab.top+typeLab.height+15+5, 60, 60);
            }
        }
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, -58, 0, 0);
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:12];
        
        switch (i) {
            case 0:
                btn.tag = ewChong;
                break;
                
            case 1:
                btn.tag = ezChong;
                break;
                
            case 2:
                btn.tag = eaChong;
                break;
                
            default:
                break;
        }
        [self addSubview:btn];
    }
    
}

-(void)chButtonClick:(UIButton*)button{
    [self conformButtonClickWithTag:button.tag Mon:[NSString stringWithFormat:@"%lu",(unsigned long)[CommonData GetCommonDataInstance].ijin]];
}

-(void)conformButtonClickWithTag:(NSInteger)tag Mon:(NSString *)mon{
    [self depictLoadView];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(getResultPopView:)
                                                name:NN_NOTIF_APPLE
                                              object:nil];
    
    if (tag == ezChong)
    {
        _chType = ezChong;
    }
    else if (tag == ewChong)
    {
        _chType = ewChong;
    }
    else if (tag == eaChong )
    {
        [[NnnbIAPManager sharedManager] makeIAP];
        return;
    }
    
    [self getOrder];
}

-(void)getResultPopView:(NSNotification*)notif
{
    [self removeLoadView];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NN_NOTIF_APPLE object:nil];
    
    [self.delegate closeOwnView];
}

- (void)getOrder{
    if (_chType==ezChong || _chType == ewChong) {
        [[NnnbFacadeCenter defaultFacade] dingOrdFuby:_chType bill:[CommonData GetCommonDataInstance].ijin subject:[CommonData GetCommonDataInstance].ijin result:^(BOOL success, NSNotification *notifi) {
            [self removeLoadView];
            
            if (success)
            {
                [self.delegate PlayerMsg:notifi.userInfo];
            }
            else
            {
                //提示错误
                NSString *strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
            }
        }];
    }
}

@end
