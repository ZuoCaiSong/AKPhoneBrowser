//
//  NnnbTppCenterView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@protocol NnnbTppCenterViewDelegate <NSObject>

-(void)closeOwnView;

- (void)PlayerMsg:(NSDictionary *)info;

@end

@interface NnnbTppCenterView : NnnbSuperView
@property (nonatomic,weak) id<NnnbTppCenterViewDelegate> delegate;
@end
