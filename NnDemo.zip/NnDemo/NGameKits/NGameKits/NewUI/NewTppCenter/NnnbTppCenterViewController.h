//
//  NnnbTppCenterViewController.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperViewController.h"
#import "NnnbTppCenterView.h"

@interface NnnbTppCenterViewController : NnnbSuperViewController<NnnbTppCenterViewDelegate, UIWebViewDelegate>
@end
