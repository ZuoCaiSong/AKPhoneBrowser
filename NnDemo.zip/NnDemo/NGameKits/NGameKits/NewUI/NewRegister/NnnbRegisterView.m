//
//  NnnbRegisterView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbRegisterView.h"
#import "NnnbFacade+Facade_VerificationTimer.h"

//左边off宽度
#define offLeft_x_width 20
//顶部off高度
#define offTop_x_height 30

@interface NnnbRegisterView ()<UITextFieldDelegate>
@property (nonatomic,strong) UITextField *accountField;
@property (nonatomic,strong) UITextField *pswField;
@end

@implementation NnnbRegisterView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *labelArr = @[@"账号：",@"密码："];
    
    for (int i = 0; i < labelArr.count; i ++) {
        CGFloat labWid = [NnnbLabelSizeToFit getWidthWithtext:labelArr[i] font:[UIFont systemFontOfSize:17]];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_x_height+i*(30+30), labWid, 30)];
        label.text = labelArr[i];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(label.left+label.width, label.top, self.width-label.width-offLeft_x_width*2, label.height)];
        if (i != labelArr.count-1) {
            textField.returnKeyType = UIReturnKeyNext;
        } else {
            textField.returnKeyType = UIReturnKeyDone;
        }
        
        textField.borderStyle = UITextBorderStyleNone;
        textField.adjustsFontSizeToFitWidth = YES;
        textField.delegate = self;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
        textField.tag = 100+i;
        [self addSubview:textField];
        
        UIImageView *lineImg = [[UIImageView alloc] initWithFrame:CGRectMake(label.left, label.top+label.height+5, self.width-offLeft_x_width*2, 1)];
        lineImg.backgroundColor = [UIColor lightGrayColor];
        lineImg.alpha = 0.3;
        [self addSubview:lineImg];
    }
    
    _accountField = (UITextField *)[self viewWithTag:100];
    _pswField = (UITextField *)[self viewWithTag:101];
    
    UIButton *registerBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    registerBtn.frame = CGRectMake((self.width/2)-80, _pswField.top+_pswField.height+40, 80*2, 40);
    [registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    [registerBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [registerBtn setBackgroundImage:img forState:UIControlStateNormal];
    [registerBtn addTarget:self action:@selector(registerClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:registerBtn];
}

#pragma mark 已分配的注册账号
- (void)setUserName:(NSString *)userName {
    _userName = userName;
    self.accountField.text = _userName;
}

- (void)setPsw:(NSString *)psw {
    _psw = psw;
    self.pswField.text = _psw;
}

#pragma mark - 注册按钮点击
- (void)registerClick{
    if ([_accountField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入账号" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkAccount:_accountField.text])
    {
        [NnnbTips depictCenterWithText:@"账号只能由字母， 数字， 下划线组成！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if ([_accountField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"账号长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_accountField.text length] > 20)
    {
        [NnnbTips depictCenterWithText:@"账号长度不能大于20个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    
    if ([_pswField.text length] <= 0)
    {
        [NnnbTips depictCenterWithText:@"请输入密码" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] < 6)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能小于6个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if ([_pswField.text length] > 18)
    {
        [NnnbTips depictCenterWithText:@"密码长度不能大于18个字符" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    if (![NnnbCommons checkPassword:_pswField.text])
    {
        [NnnbTips depictCenterWithText:@"密码只能为字母，数字，符号！" duration:NN_TIPS_TIME2];
        
        return;
    }
    
    //取消键盘
    [_pswField resignFirstResponder];
    [_accountField resignFirstResponder];
    
    /**
     *  延时操作
     */
    [self performSelector:@selector(doRegister) withObject:nil afterDelay:0.5];
}

- (void)doRegister{
    [self registerBtnClick:_accountField.text andPsw:_pswField.text];
}

- (void)registerBtnClick:(NSString *)account andPsw:(NSString *)psw{
    [self depictLoadView];
    
    _userName = account;
    _psw = psw;
    
    //注册
    [[NnnbFacadeCenter defaultFacade] registWithAccount:account andPsd:psw result:^(BOOL success, NSNotification *notifi) {
        [self removeLoadView];
        
        if (success) {
            [CommonData GetCommonDataInstance].autoRememberAndLogin = YES;
            if (_delegate && [_delegate respondsToSelector:@selector(backToLastView:andPsw:)]) {
                [_delegate backToLastView:_userName andPsw:_psw];
            }
        }else {
            //提示错误
            NSString* errorString = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
            [NnnbTips depictCenterWithText:errorString duration:NN_TIPS_TIME2];
        }
    }];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewTop:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewTop:90];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (textField == _accountField) {
        [self.delegate moveBgViewBottom:60];
    }
    
    if (textField == _pswField) {
        [self.delegate moveBgViewBottom:90];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _accountField) {
        [_accountField resignFirstResponder];
        [_pswField becomeFirstResponder];
    } else{
        [_pswField resignFirstResponder];
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (string && string.length > 0 && [NnnbCommons checkChinese:string]){
        return NO;
    }
    
    if (textField == _accountField){
        //帐号只能是字母，数字和下划线
        if (string && string.length > 0 && ![NnnbCommons checkAccount:string]){
            return NO;
        }
    }
    
    if ((range.location >= __WP_INPUT_MAX__) || (textField.text && (textField.text.length + string.length > __WP_INPUT_MAX__))){
        //输入的字数超过限制
        return NO;
    }
    
    return YES;
}

@end
