//
//  NnnbFastRegisterView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbFastRegisterView.h"

#define offLeft_x_width 20
#define offTop_y_height 20

@implementation NnnbFastRegisterView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
    _userName = [userDef objectForKey:@"fastRegisterName"];
    _userPsw = [userDef objectForKey:@"fastRegisterPsw"];
    
    UILabel *userLabel = [[UILabel alloc] initWithFrame:CGRectMake(offLeft_x_width, offTop_y_height, 60, 30)];
    userLabel.text = @"账号：";
    userLabel.font = [UIFont boldSystemFontOfSize:16];
    [self addSubview:userLabel];
    
    UILabel *account = [[UILabel alloc] initWithFrame:CGRectMake(userLabel.left+userLabel.width-10, userLabel.top-5, self.width-offLeft_x_width*2-userLabel.width, userLabel.height+10)];
    account.text = _userName;
    account.textColor = RGBCOLOR(38, 180, 144);
    account.font = [UIFont boldSystemFontOfSize:20];
    [self addSubview:account];
    
    UILabel *pswLabel = [[UILabel alloc] initWithFrame:CGRectMake(userLabel.left, userLabel.top+userLabel.height+10, userLabel.width, userLabel.height)];
    pswLabel.text = @"密码：";
    pswLabel.font = [UIFont boldSystemFontOfSize:16];
    [self addSubview:pswLabel];
    
    UILabel *psw = [[UILabel alloc] initWithFrame:CGRectMake(pswLabel.left+pswLabel.width-10, pswLabel.top-5, self.width-offLeft_x_width*2-pswLabel.width, pswLabel.height+10)];
    psw.text = _userPsw;
    psw.textColor = RGBCOLOR(38, 180, 144);
    psw.font = [UIFont boldSystemFontOfSize:20];
    [self addSubview:psw];
    
    UILabel *tipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(pswLabel.left, pswLabel.top+pswLabel.height+10, self.width-offLeft_x_width*2, userLabel.height+10)];
    tipsLabel.text = @"提示：为保证账号安全，请尽快到用户中心修改密码";
    tipsLabel.textColor = [UIColor lightGrayColor];
    tipsLabel.font = [UIFont boldSystemFontOfSize:15];
    tipsLabel.numberOfLines = 0;
    [self addSubview:tipsLabel];
    
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    loginBtn.frame = CGRectMake((self.width/2)-80, tipsLabel.top+tipsLabel.height+15, 80*2, 40);
    UIImage *img = [UIImage nnGetPlatImage:@"SygGreenBtn.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    [loginBtn setBackgroundImage:img forState:UIControlStateNormal];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(loginClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:loginBtn];
    
//    [self performSelector:@selector(screenshotToAlbum) withObject:nil afterDelay:0.2];
}

- (void)loginClick{
    [self.delegate backToLastViewWithAccount:_userName andPsw:_userPsw];
}

//#pragma mark - 截图保存截图到相册中到相册中
//- (void)screenshotToAlbum
//{
//    // 判断是否为retina屏, 即retina屏绘图时有放大因子
//    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
//        UIGraphicsBeginImageContextWithOptions([UIScreen mainScreen].bounds.size, NO, [UIScreen mainScreen].scale);
//    } else {
//        UIGraphicsBeginImageContext([UIScreen mainScreen].bounds.size);
//    }
//
//    [self.window.layer renderInContext:UIGraphicsGetCurrentContext()];
//    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
//
//    //写入相册中
//    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
//}
//
//#pragma mark - 写入相册回调方法
//- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
//{
//    if(error != NULL){
//        NSLog(@"保存图片失败");
//    }else{
//        NSLog(@"保存图片成功");
//        [NnnbTips depictCenterWithText:@"账号密码已保存到相册" duration:3.0];
//    }
//}

@end
