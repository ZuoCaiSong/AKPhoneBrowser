//
//  NnnbFastRegisterViewController.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSuperViewController.h"
#import "NnnbFastRegisterView.h"

@protocol NnnbFastRegisterViewControllerDelegate <NSObject>

-(void)fastRegisterSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw;

@end

@interface NnnbFastRegisterViewController : NnnbSuperViewController<NnnbFastRegisterViewDelegate>
@property (nonatomic,strong) NnnbFastRegisterView *fastRegisterView;
@property (nonatomic,weak) id<NnnbFastRegisterViewControllerDelegate> delegate;
@end
