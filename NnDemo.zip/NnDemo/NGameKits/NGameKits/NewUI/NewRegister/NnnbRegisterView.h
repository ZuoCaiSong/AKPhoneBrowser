//
//  NnnbRegisterView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"
#import "NnnbTextField.h"

@protocol NnnbRegisterViewDelegate <NSObject>

-(void)backToLastView:(NSString *)account andPsw:(NSString *)psw;

-(void)moveBgViewTop:(NSInteger)moveNum;

-(void)moveBgViewBottom:(NSInteger)moveNum;

@end

@interface NnnbRegisterView : NnnbSuperView
@property (nonatomic,weak) id<NnnbRegisterViewDelegate> delegate;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *psw;
@end
