//
//  NnnbFastRegisterViewController.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbFastRegisterViewController.h"

@interface NnnbFastRegisterViewController ()

@end

@implementation NnnbFastRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    self.closeBtn.hidden = YES;
    [self.closeBtn removeFromSuperview];
    
    CGFloat titleWid = [NnnbLabelSizeToFit getWidthWithtext:@"注册成功" font:[UIFont systemFontOfSize:18]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWid)/2, 5, titleWid, 30)];
    title.text = @"注册成功";
    title.font = [UIFont systemFontOfSize:18];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];
    
    [self depictFastRegisterView];
}

- (void)depictFastRegisterView{
    _fastRegisterView = [[NnnbFastRegisterView alloc] initWithFrame:CGRectMake(0, self.titleIg.top+self.titleIg.height, self.bgView.width, self.bgView.height-self.titleIg.height)];
    _fastRegisterView.delegate = self;
    [self.bgView addSubview:_fastRegisterView];
    [self.view addSubview:self.bgView];
}

#pragma mark - NnnbFastRegisterViewDelegate
- (void)backToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw{
    [self popView];
    UIView *view = [self.view superview];
    [view removeFromSuperview];
    [self.delegate fastRegisterSuccessWithAccount:account andPsw:psw];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
