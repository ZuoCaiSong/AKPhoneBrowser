//
//  NnnbRegisterViewController.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperViewController.h"
#import "NnnbRegisterView.h"

@protocol NnnbRegisterViewControllerDelegate <NSObject>

-(void)registerSuccessWithAccount:(NSString*)account andPsw:(NSString *)psw;

@end

@interface NnnbRegisterViewController : NnnbSuperViewController<NnnbRegisterViewDelegate>
@property (nonatomic,strong) NnnbRegisterView *registerView;
@property (nonatomic,weak) id<NnnbRegisterViewControllerDelegate> delegate;
@property (nonatomic,copy) NSString *registerAccount;
@property (nonatomic,copy) NSString *registerPsd;
@end
