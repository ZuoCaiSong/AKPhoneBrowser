//
//  NnnbFastRegisterView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//

#import "NnnbSuperView.h"

@protocol NnnbFastRegisterViewDelegate <NSObject>

-(void)backToLastViewWithAccount:(NSString *)account andPsw:(NSString *)psw;

@end

@interface NnnbFastRegisterView : NnnbSuperView
@property (nonatomic,strong) UILabel *user;
@property (nonatomic,strong) UILabel *psw;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *userPsw;
@property (nonatomic,weak) id<NnnbFastRegisterViewDelegate> delegate;
@end
