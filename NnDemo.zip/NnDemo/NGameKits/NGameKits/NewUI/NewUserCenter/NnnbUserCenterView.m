//
//  NnnbUserCenterView.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbUserCenterView.h"

#define awayLeft 20

@implementation NnnbUserCenterView

- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

- (void)initView{
    self.backgroundColor = [UIColor whiteColor];
    
    if (!([DataManger getInstance].currentUserInfo.isBind))
    {
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        BOOL bHasTip = [userDef boolForKey:kBingFlag];
        if (!bHasTip)
        {
            [userDef setBool:YES forKey:kBingFlag];
            [userDef synchronize];
            
            _alertView = [[UIAlertView alloc]initWithTitle:@"注意"
                                                   message:@"您的账号尚未绑定手机，忘记密码或者被盗时将无法通过手机找回密码！"
                                                  delegate:self
                                         cancelButtonTitle:@"稍后绑定"
                                         otherButtonTitles:@"立刻绑定", nil];
            _alertView.tag = 100003;
            _alertView.delegate = self;
            [_alertView show];
        }
    }
    
    UIImage *img = [UIImage nnGetPlatImage:@"SygLightGray.png"];
    img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight:img.size.height/2];
    
    NSArray *iconArr = @[@"SygChangePsw.png",@"SygBindPhone.png",@"SygNameCheck.png",@"SygLogOut.png"];
    NSArray *titleArr = @[@"修改密码",@"绑定手机",@"实名认证",@"注销账户"];
    
    for (int i = 0; i < titleArr.count; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(awayLeft, (i%5)*50, self.width-awayLeft*2, 50);
        btn.tag = 40+i;
        [btn setBackgroundImage:img forState:UIControlStateHighlighted];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        
        UIImageView *line = [[UIImageView alloc] initWithFrame:CGRectMake(btn.left, btn.top+btn.height, btn.width, 1)];
        line.backgroundColor = [UIColor lightGrayColor];
        line.alpha = 0.3;
        [self addSubview:line];
        
        UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(10, 15, 20, 20)];
        icon.image = [UIImage nnGetPlatImage:iconArr[i]];
        [btn addSubview:icon];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(icon.left+icon.width+10, 15, 150, 20)];
        label.tag = 50+i;
        label.text = titleArr[i];
        label.font = [UIFont systemFontOfSize:15];
        [btn addSubview:label];
        
        UIImageView *jianTou = [[UIImageView alloc] initWithFrame:CGRectMake(btn.width-11-20, 16, 11, 18)];
        jianTou.tag = 60+i;
        jianTou.image = [UIImage nnGetPlatImage:@"SygRightJianTou.png"];
        [btn addSubview:jianTou];
        
        if (btn.tag == 41) {
            if ([DataManger getInstance].currentUserInfo.isBind) {
                btn.enabled = NO;
                label.text = @"绑定手机(已绑定)";
                label.textColor = [UIColor lightGrayColor];
                [jianTou removeFromSuperview];
            }
        }
        
        if (btn.tag == 42) {
            if ([DataManger getInstance].currentUserInfo.isCheck) {
                btn.enabled = NO;
                label.text = @"实名认证(已认证)";
                label.textColor = [UIColor lightGrayColor];
                [jianTou removeFromSuperview];
            }
        }
    }
}

- (void)btnClick:(UIButton *)btn{
    UILabel *btnLab = (UILabel *)[btn viewWithTag:btn.tag+10];
    
    if ([btnLab.text isEqualToString:@"修改密码"])
    {
        [self.delegate presentViewChangePswView];
    }
    else if ([btnLab.text isEqualToString:@"绑定手机"])
    {
        [self.delegate presentViewBindPhoneView];
    }
    else if ([btnLab.text isEqualToString:@"实名认证"])
    {
        [self.delegate presentViewRealNameCheck];
    }
    else if ([btnLab.text isEqualToString:@"注销账户"])
    {
        [self loginOutBtnClick];
    }
}

#pragma mark - 退出登录
- (void)loginOutBtnClick{
    UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:@"确定要退出登录吗?"
                                                      delegate:self
                                             cancelButtonTitle:@"否"
                                             otherButtonTitles:@"是", nil];
    [alertView show];
    alertView.tag = 10001;
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 10001)
    {
        if (buttonIndex == 1)
        {
            [self.delegate backToLastView];
            [[NnnbFloatWindow getInstance] removeWindow];
            
            [[DataManger getInstance] clear];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_LOGOUT_SUCCESS object:nil];
        }
    }
    
    if (alertView.tag == 100003) {
        if (buttonIndex == 1) {
            [self.delegate presentViewBindPhoneView];
        }
    }
}

#pragma mark - 刷新标题
- (void)updateBindPhoneView{
    UIButton *btn = (UIButton *)[self viewWithTag:41];
    UILabel *label = (UILabel *)[self viewWithTag:51];
    UIImageView *jianTou = (UIImageView *)[self viewWithTag:61];
    
    btn.enabled = NO;
    label.text = @"绑定手机(已绑定)";
    label.textColor = [UIColor lightGrayColor];
    [jianTou removeFromSuperview];
}

- (void)updateRealNameCheckView{
    UIButton *btn = (UIButton *)[self viewWithTag:42];
    UILabel *label = (UILabel *)[self viewWithTag:52];
    UIImageView *jianTou = (UIImageView *)[self viewWithTag:62];
    
    btn.enabled = NO;
    label.text = @"实名认证(已认证)";
    label.textColor = [UIColor lightGrayColor];
    [jianTou removeFromSuperview];
}

@end
