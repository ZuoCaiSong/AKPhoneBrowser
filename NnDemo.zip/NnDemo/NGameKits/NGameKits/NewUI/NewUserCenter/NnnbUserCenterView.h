//
//  NnnbUserCenterView.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSuperView.h"

@protocol  NnnbUserCenterViewDelegate<NSObject>

- (void)backToLastView;

- (void)presentViewChangePswView;

- (void)presentViewRealNameCheck;

- (void)presentViewBindPhoneView;

@end

@interface NnnbUserCenterView : NnnbSuperView<UIAlertViewDelegate>
@property (nonatomic,weak) id<NnnbUserCenterViewDelegate>delegate;
@property (nonatomic,strong) UIAlertView *alertView;

- (void)updateBindPhoneView;

- (void)updateRealNameCheckView;

@end
