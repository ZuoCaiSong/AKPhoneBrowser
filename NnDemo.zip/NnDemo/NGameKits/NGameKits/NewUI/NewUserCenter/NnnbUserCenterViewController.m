//
//  NnnbUserCenterViewController.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbUserCenterViewController.h"
#import "NnnbChangePswViewController.h"
#import "NnnbRealNameCheckViewController.h"
#import "NnnbBindPhoneViewController.h"

@interface NnnbUserCenterViewController ()

@end

@implementation NnnbUserCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backBtn.hidden = YES;
    [self.backBtn removeFromSuperview];
    
    [[NnnbFloatWindow getInstance] removeWindow];
    
    CGFloat titleWid = [NnnbLabelSizeToFit getWidthWithtext:@"账号" font:[UIFont systemFontOfSize:18]];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake((self.titleIg.width-titleWid)/2, 5, titleWid, 30)];
    title.text = @"账号";
    title.font = [UIFont systemFontOfSize:18];
    title.textAlignment = UITextAlignmentCenter;
    [self.titleIg addSubview:title];

    [self depictUserCenterView];
}

- (void)depictUserCenterView{
    _userCenterView = [[NnnbUserCenterView alloc] initWithFrame:CGRectMake(0, self.titleIg.top+self.titleIg.height, self.bgView.width, self.bgView.height-self.titleIg.height)];
    _userCenterView.delegate = self;
    [self.bgView addSubview:_userCenterView];
    [self.view addSubview:self.bgView];
    
    self.bgView.alpha = 0;
    self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, -self.bgViewFrame.size.height, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    [UIView animateWithDuration:0.4 animations:^{
        self.bgView.alpha = 1;
        self.bgView.frame = CGRectMake(self.bgViewFrame.origin.x, self.bgViewFrame.origin.y, self.bgViewFrame.size.width, self.bgViewFrame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - NnnbUserCenterViewDelegate
- (void)backToLastView{
    [self popView];
    [self closeView];
}

- (void)presentViewChangePswView{
    NnnbChangePswViewController *cVc = [[NnnbChangePswViewController alloc] init];
    [self presentViewController:cVc animated:YES completion:nil];
}

- (void)presentViewRealNameCheck{
    NnnbRealNameCheckViewController *rVc = [[NnnbRealNameCheckViewController alloc] init];
    [self presentViewController:rVc animated:YES completion:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateRealNameCheckSuccess:)
                                                 name:NN_NOTIF_CHECKPERSONID_SUCCESS
                                               object:nil];
}

- (void)presentViewBindPhoneView{
    NnnbBindPhoneViewController *bVc = [[NnnbBindPhoneViewController alloc] init];
    bVc.closeBtnRemove = YES;
    [self presentViewController:bVc animated:YES completion:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateBindPhoneSuccess:)
                                                 name:NN_NOTIF_BINDPHONE_SUCCESS
                                               object:nil];
}

- (void)updateBindPhoneSuccess:(NSNotification*)notif{
    [_userCenterView updateBindPhoneView];
}

- (void)updateRealNameCheckSuccess:(NSNotification*)notif{
    [_userCenterView updateRealNameCheckView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
