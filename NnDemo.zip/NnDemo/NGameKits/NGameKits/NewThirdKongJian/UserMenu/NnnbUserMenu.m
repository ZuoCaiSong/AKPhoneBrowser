//
//  NnnbUserMenu.m
//
//  Created by leisurlylife on 2018/5/3.
//  Copyright © 2018年 kafi. All rights reserved.
//


#import "NnnbUserMenu.h"
#define VIEW_CENTER(aView)       ((aView).center)
#define VIEW_CENTER_X(aView)     ((aView).center.x)
#define VIEW_CENTER_Y(aView)     ((aView).center.y)

#define FRAME_ORIGIN(aFrame)     ((aFrame).origin)
#define FRAME_X(aFrame)          ((aFrame).origin.x)
#define FRAME_Y(aFrame)          ((aFrame).origin.y)

#define FRAME_SIZE(aFrame)       ((aFrame).size)
#define FRAME_HEIGHT(aFrame)     ((aFrame).size.height)
#define FRAME_WIDTH(aFrame)      ((aFrame).size.width)

#define VIEW_BOUNDS(aView)       ((aView).bounds)

#define VIEW_FRAME(aView)        ((aView).frame)

#define VIEW_ORIGIN(aView)       ((aView).frame.origin)
#define VIEW_X(aView)            ((aView).frame.origin.x)
#define VIEW_Y(aView)            ((aView).frame.origin.y)

#define VIEW_SIZE(aView)         ((aView).frame.size)
#define VIEW_HEIGHT(aView)       ((aView).frame.size.height)
#define VIEW_WIDTH(aView)        ((aView).frame.size.width)

#define VIEW_X_Right(aView)      ((aView).frame.origin.x + (aView).frame.size.width)
#define VIEW_Y_Bottom(aView)     ((aView).frame.origin.y + (aView).frame.size.height)

#define AnimateTime 0.25f   // 下拉动画时间

@interface NnnbUserMenu ()
@property (nonatomic,strong) UIView *listView; // 下拉列表背景View
@property (nonatomic,strong) UITableView *tableView; // 下拉列表
@property (nonatomic,strong) NSMutableArray *titleArr; // 选项数组
@property (nonatomic,assign) CGFloat rowHeight; // 下拉列表行高
@end

@implementation NnnbUserMenu

- (void)setMenuWords:(NSArray *)titlesArr rowHeight:(CGFloat)rowHeight
{
    if (self == nil) {
        return;
    }
    
    _titleArr  = [NSMutableArray arrayWithArray:titlesArr];
    _rowHeight = rowHeight;
    
    // 下拉列表背景View
    _listView = [[UIView alloc] init];
    _listView.frame = CGRectMake(VIEW_X(self) , CGRectGetMinY(self.frame), VIEW_WIDTH(self),  0);
    _listView.clipsToBounds       = YES;
    _listView.layer.masksToBounds = NO;
    _listView.layer.borderColor   = [UIColor lightTextColor].CGColor;
    _listView.layer.borderWidth   = 0.5f;
    [self.superview addSubview:_listView];
    
    // 下拉列表TableView
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,_listView.width, VIEW_HEIGHT(_listView))];
    _tableView.delegate        = self;
    _tableView.dataSource      = self;
    _tableView.separatorStyle  = UITableViewCellSeparatorStyleNone;
    [_listView addSubview:_tableView];
}

- (void)showMenu
{
    // 显示下拉列表
    self.hidden = NO;
    
    if ([self.delegate respondsToSelector:@selector(dropdownMenuWillShow:)]) {
        [self.delegate dropdownMenuWillShow:self]; // 将要显示回调代理
    }
    
    [UIView animateWithDuration:AnimateTime animations:^{
        _listView.frame  = CGRectMake(VIEW_X(_listView), CGRectGetMinY(self.frame), VIEW_WIDTH(_listView), _rowHeight *_titleArr.count);
        _tableView.frame = CGRectMake(0, 0, _listView.width, VIEW_HEIGHT(_listView));
    }completion:^(BOOL finished) {
        if ([self.delegate respondsToSelector:@selector(dropdownMenuDidShow:)])
        {
            [self.delegate dropdownMenuDidShow:self]; // 已经显示回调代理
        }
    }];
}

- (void)hideMenu
{
    // 隐藏下拉列表
    self.hidden = YES;
    
    if ([self.delegate respondsToSelector:@selector(dropdownMenuWillHidden:)])
    {
        [self.delegate dropdownMenuWillHidden:self]; // 将要隐藏回调代理
    }
    
    [UIView animateWithDuration:AnimateTime animations:^{
        _listView.frame  = CGRectMake(VIEW_X(_listView), VIEW_Y(_listView), VIEW_WIDTH(_listView), 0);
        _tableView.frame = CGRectMake(0, 0, _listView.width, VIEW_HEIGHT(_listView));
    }completion:^(BOOL finished) {
        if ([self.delegate respondsToSelector:@selector(dropdownMenuDidHidden:)]) {
            [self.delegate dropdownMenuDidHidden:self]; // 已经隐藏回调代理
        }
    }];
}

#pragma mark - UITableView Delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return _rowHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_titleArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        //---------------------------下拉选项样式，可在此处自定义-------------------------
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.textLabel.font          = [UIFont systemFontOfSize:16];
        cell.textLabel.textColor     = [UIColor blackColor];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.selectionStyle          = UITableViewCellSelectionStyleNone;
        
        UIView * line = [[UIView alloc] initWithFrame:CGRectMake(0, _rowHeight -0.5, self.width, 0.5)];
        line.backgroundColor = [UIColor lightGrayColor];
        line.alpha = 0.5;
        [cell addSubview:line];
        
        UIButton *deleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        deleBtn.tag = (_titleArr.count-1-indexPath.row)+10;
        deleBtn.frame = CGRectMake(self.width-30*2, (_rowHeight - 30)/2, 30, 30);
        [deleBtn setImage:[UIImage nnGetPlatImage:@"TygWrong.png"] forState:UIControlStateNormal];
        [deleBtn addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:deleBtn];
    }
    
    cell.textLabel.text =[_titleArr objectAtIndex:(_titleArr.count-1-indexPath.row)];
    
    return cell;
}

- (void)deleteAction:(UIButton *)button{
    NSInteger tag = button.tag - 10;
    
    [_titleArr removeObjectAtIndex:tag];
    [_tableView reloadData];
    
    _listView.frame  = CGRectMake(VIEW_X(_listView), CGRectGetMinY(self.frame), VIEW_WIDTH(_listView), _rowHeight *_titleArr.count);
    _tableView.frame = CGRectMake(0, 0, _listView.width, VIEW_HEIGHT(_listView));

    if ([self.delegate respondsToSelector:@selector(dropdownMenuWithDeleteAtIndex:)]) {
        [self.delegate dropdownMenuWithDeleteAtIndex:tag];
    }
    
    if (_titleArr.count == 0) {
        [self hideMenu];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.delegate respondsToSelector:@selector(dropdownMenu:selectedCellNumber:)]) {
        [self.delegate dropdownMenu:self selectedCellNumber:(_titleArr.count-1-indexPath.row)]; // 回调代理
    }
    
    [self hideMenu];
}

@end
