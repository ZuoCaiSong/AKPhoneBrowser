//
//  NnnbUserMenu.m
//
//  Created by leisurlylife on 2018/5/3.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NnnbUserMenu;

@protocol NnnbUserMenuDelegate <NSObject>

@optional

- (void)dropdownMenuWillShow:(NnnbUserMenu *)menu;    // 当下拉菜单将要显示时调用
- (void)dropdownMenuDidShow:(NnnbUserMenu *)menu;     // 当下拉菜单已经显示时调用
- (void)dropdownMenuWillHidden:(NnnbUserMenu *)menu;  // 当下拉菜单将要收起时调用
- (void)dropdownMenuDidHidden:(NnnbUserMenu *)menu;   // 当下拉菜单已经收起时调用

- (void)dropdownMenu:(NnnbUserMenu *)menu selectedCellNumber:(NSInteger)number; // 当选择某个选项时调用

- (void)dropdownMenuWithDeleteAtIndex:(NSInteger)index;//当删除某个选项时调用

@end

@interface NnnbUserMenu : UIView <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, assign) id <NnnbUserMenuDelegate>delegate;

- (void)setMenuWords:(NSArray *)titlesArr rowHeight:(CGFloat)rowHeight;  // 设置下拉菜单控件样式

- (void)showMenu; // 显示下拉菜单

- (void)hideMenu; // 隐藏下拉菜单

@end
