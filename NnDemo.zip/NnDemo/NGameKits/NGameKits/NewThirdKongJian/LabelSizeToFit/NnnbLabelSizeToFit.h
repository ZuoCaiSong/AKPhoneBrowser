//
//  NnnbLabelSizeToFit.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NnnbLabelSizeToFit : NSObject
+ (CGFloat)getWidthWithtext:(NSString *)text font:(UIFont *)font;
+ (CGFloat)getHeightByWidth:(CGFloat)width text:(NSString *)text font:(UIFont*)font;
@end
