//
//  NnnbLabelSizeToFit.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbLabelSizeToFit.h"

@implementation NnnbLabelSizeToFit
+ (CGFloat)getWidthWithtext:(NSString *)text font:(UIFont *)font {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 1000, 0)];
    label.text = text;
    label.font = font;
    [label sizeToFit];
    return label.width;
}

+ (CGFloat)getHeightByWidth:(CGFloat)width text:(NSString *)text font:(UIFont*)font{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, 0)];
    label.text = text;
    label.font = font;
    label.numberOfLines = 0;
    [label sizeToFit];
    CGFloat height = label.height;
    return height;
}

@end
