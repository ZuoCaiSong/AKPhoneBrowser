//
//  LCLoadingHUD.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbLoadingHUD.h"

@interface NnnbLoadingHUD ()

@property (nonatomic, strong) NnnbLoadingHUD *loadingHUD;

+ (instancetype)shared;

@end

@implementation NnnbLoadingHUD

- (NnnbLoadingHUD *)loadingHUD {

    if (!_loadingHUD) {

        _loadingHUD       = [[NnnbLoadingHUD alloc] initWithView:[UIApplication sharedApplication].keyWindow];
        _loadingHUD.shape = NnnbProgressHUDShapeLinear;
        _loadingHUD.type  = NnnbProgressHUDTypeDarkForground;
    }
    return _loadingHUD;
}

+ (instancetype)shared {

    static NnnbLoadingHUD *loadingHUD = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        loadingHUD = [[NnnbLoadingHUD alloc] init];
    });
    return loadingHUD;
}

+ (void)depictLoading:(NSString *)text inView:(UIView *)view {

    NnnbLoadingHUD *hud = [[NnnbLoadingHUD alloc] initWithView:view];
    hud.text  = text ?: @"";
    hud.shape = NnnbProgressHUDShapeLinear;
    hud.type  = NnnbProgressHUDTypeDarkForground;
    [view addSubview:hud];
    [hud depictWithAnimation:YES];
}

+ (void)depictLoading:(NSString *)text {

    if (![UIApplication sharedApplication].keyWindow) {

        return;
    }

    NnnbLoadingHUD *loadingHUD = [NnnbLoadingHUD shared].loadingHUD;
    loadingHUD.text = text ?: @"";
    [[UIApplication sharedApplication].keyWindow addSubview:loadingHUD];
    [loadingHUD depictWithAnimation:YES];
}

+ (void)removeInKeyWindow {

    NnnbLoadingHUD *loadingHUD = [NnnbLoadingHUD shared].loadingHUD;
    [loadingHUD dismissWithAnimation:YES];
    [NnnbLoadingHUD shared].loadingHUD = nil;
}

+ (void)removeInView:(UIView *)view {

    for (UIView *childView in view.subviews) {

        if ([childView isKindOfClass:[NnnbLoadingHUD class]]) {

            [(NnnbLoadingHUD *)childView dismissWithAnimation:YES];
        }
    }
}

@end
