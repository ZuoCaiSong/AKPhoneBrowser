//
//  LCLoadingHUD.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//
//  Mail:   mailto:devtip@163.com
//  GitHub: http://github.com/iTofu
//  如有问题或建议请给我发 Email, 或在该项目的 GitHub 主页提 Issue, 谢谢 :)
//
//  LCCoolHUD 系列库之一
//
//  致谢 CLProgressHUD (https://github.com/cleexiang/CLProgressHUD) !

#import "NnnbProgressHUD.h"

@interface NnnbLoadingHUD : NnnbProgressHUD

#pragma mark - HUD 添加到 KeyWindow

/**
 * HUD 到 KeyWindow 上
 *
 *  @param text 文字
 */
+ (void)depictLoading:(NSString *)text;

/**
 *  移除添加到 KeyWindow 上的 HUD
 */
+ (void)removeInKeyWindow;

#pragma mark - HUD 添加到 View

/**
 * HUD 到 View 上
 *
 *  @param text 文字
 *  @param view view
 */
+ (void)depictLoading:(NSString *)text inView:(UIView *)view;

/**
 *  移除添加到 View 上的 HUD
 *
 *  @param view view
 */
+ (void)removeInView:(UIView *)view;

@end
