//
//  CLProgressHUD.h
//  CLProgressHUDDemo
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, NnnbProgressHUDType) {
    NnnbProgressHUDTypeDarkForground,
    NnnbProgressHUDTypeDarkBackground
};

typedef NS_ENUM(NSUInteger, NnnbProgressHUDShape) {
    NnnbProgressHUDShapeLinear,
    NnnbProgressHUDShapeCircle
};

@interface NnnbProgressHUD : UIView {
    
}

@property (nonatomic, assign) NnnbProgressHUDType type;
@property (nonatomic, assign) NnnbProgressHUDShape shape;
@property (nonatomic, assign) CGFloat diameter;
@property (nonatomic, strong) NSString *text;

- (id)initWithView:(UIView *)view;
- (void)show;
- (void)depictWithAnimation:(BOOL)animated;
- (void)depictWithAnimation:(BOOL)animated duration:(NSTimeInterval)duration;

/**
 *  HUD
 */
- (void)dismiss;

/**
 *  HUD 伴随动画
 *
 *  @param animated 是否伴随动画
 */
- (void)dismissWithAnimation:(BOOL)animated;

@end
