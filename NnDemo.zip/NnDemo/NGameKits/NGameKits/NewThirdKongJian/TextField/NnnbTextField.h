//
//  NnnbTextField.h
//  shuoshuo
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NnnbTextField : UITextField
- (id)initWithFrame:(CGRect)frame andFromRight:(CGFloat)fromRight;
@end
