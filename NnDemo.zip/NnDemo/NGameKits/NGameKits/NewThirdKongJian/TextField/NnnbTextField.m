//
//  NnnbTextField.m
//  shuoshuo
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbTextField.h"

@interface NnnbTextField ()
@property(nonatomic,assign)CGFloat fromRight;
@end

@implementation NnnbTextField
-(CGRect)placeholderRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x + self.fromRight, bounds.origin.y, bounds.size.width - self.fromRight - 17, bounds.size.height);
}

-(CGRect)editingRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x + self.fromRight, bounds.origin.y, bounds.size.width - self.fromRight-17, bounds.size.height);
}

-(CGRect)textRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x + self.fromRight, bounds.origin.y, bounds.size.width - self.fromRight - 17, bounds.size.height);
}

- (id)initWithFrame:(CGRect)frame andFromRight:(CGFloat)fromRight
{
    self = [super initWithFrame:frame];
    if (self)
	{
        self.backgroundColor = [UIColor whiteColor];
        self.fromRight = fromRight;
    }
    return self;
}
@end
