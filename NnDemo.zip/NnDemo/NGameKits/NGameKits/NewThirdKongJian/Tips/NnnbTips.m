//
//  XHToast.m

//  Copyright (c) 2016 XHToast ( https://github.com/CoderZhuXH/XHToast )

//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.

#import "NnnbTips.h"

//Toast默认停留时间
#define ToastDispalyDuration 1.2f
//Toast到顶端/底端默认距离
#define ToastSpace 100.0f
//Toast背景颜色
#define ToastBackgroundColor [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.75]

@interface NnnbTips ()
@property(nonatomic,strong)UIButton *contentView;
@property(nonatomic,assign)CGFloat duration;
@end

@implementation NnnbTips

- (id)initWithText:(NSString *)text{
    if (self = [super init]) {

        UIFont *font = [UIFont boldSystemFontOfSize:16];
        NSDictionary * dict=[NSDictionary dictionaryWithObject: font forKey:NSFontAttributeName];
        CGRect rect=[text boundingRectWithSize:CGSizeMake(250,CGFLOAT_MAX) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil];
        UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0,rect.size.width + 40, rect.size.height+ 20)];
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.textColor = [UIColor whiteColor];
        textLabel.textAlignment = NSTextAlignmentCenter;
        textLabel.font = font;
        textLabel.text = text;
        textLabel.numberOfLines = 0;
        
        self.contentView = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, textLabel.width, textLabel.height)];
        self.contentView.layer.cornerRadius = 8.0f;
        self.contentView.backgroundColor = ToastBackgroundColor;
        [self.contentView addSubview:textLabel];
        self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.contentView addTarget:self action:@selector(toastTaped:) forControlEvents:UIControlEventTouchDown];
        self.contentView.alpha = 0.0f;
        self.duration = ToastDispalyDuration;
        
    }
    
    return self;
}

-(void)dismissToast{
    
    [self.contentView removeFromSuperview];
}

-(void)toastTaped:(UIButton *)sender{
    
    [self removeAnimation];
}

-(void)showAnimation{
    [UIView beginAnimations:@"show" context:NULL];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationDuration:0.3];
    self.contentView.alpha = 1.0f;
    [UIView commitAnimations];
}

-(void)removeAnimation{
    [UIView beginAnimations:@"hide" context:NULL];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(dismissToast)];
    [UIView setAnimationDuration:0.3];
    self.contentView.alpha = 0.0f;
    [UIView commitAnimations];
}
+(UIWindow *)window
{
    return [[[UIApplication sharedApplication] delegate] window];
}

- (void)depictIn:(UIView *)view{
    self.contentView.center = view.center;
    [view  addSubview:self.contentView];
    [self showAnimation];
    [self performSelector:@selector(removeAnimation) withObject:nil afterDelay:self.duration];
}

- (void)depictIn:(UIView *)view fromTopOffset:(CGFloat)top{
    self.contentView.center = CGPointMake(view.center.x, top + self.contentView.height/2);
    [view  addSubview:self.contentView];
    [self showAnimation];
    [self performSelector:@selector(removeAnimation) withObject:nil afterDelay:self.duration];
}

- (void)depictIn:(UIView *)view fromBottomOffset:(CGFloat)bottom{
    self.contentView.center = CGPointMake(view.center.x, view.height-(bottom + self.contentView.height/2));
    [view  addSubview:self.contentView];
    [self showAnimation];
    [self performSelector:@selector(removeAnimation) withObject:nil afterDelay:self.duration];
}

#pragma mark-中间
+ (void)depictCenterWithText:(NSString *)text{
    
    [NnnbTips depictCenterWithText:text duration:ToastDispalyDuration];
}

+ (void)depictCenterWithText:(NSString *)text duration:(CGFloat)duration{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:[self window]];
}
#pragma mark-上方
+ (void)depictTopWithText:(NSString *)text{
    
    [NnnbTips depictTopWithText:text  topOffset:ToastSpace duration:ToastDispalyDuration];
}
+ (void)depictTopWithText:(NSString *)text duration:(CGFloat)duration
{
     [NnnbTips depictTopWithText:text  topOffset:ToastSpace duration:duration];
}
+ (void)depictTopWithText:(NSString *)text topOffset:(CGFloat)topOffset{
    [NnnbTips depictTopWithText:text  topOffset:topOffset duration:ToastDispalyDuration];
}

+ (void)depictTopWithText:(NSString *)text topOffset:(CGFloat)topOffset duration:(CGFloat)duration{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:[self window] fromTopOffset:topOffset];
}
#pragma mark-下方
+ (void)depictBottomWithText:(NSString *)text{
    
    [NnnbTips depictBottomWithText:text  bottomOffset:ToastSpace duration:ToastDispalyDuration];
}
+ (void)depictBottomWithText:(NSString *)text duration:(CGFloat)duration
{
      [NnnbTips depictBottomWithText:text  bottomOffset:ToastSpace duration:duration];
}
+ (void)depictBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset{
    [NnnbTips depictBottomWithText:text  bottomOffset:bottomOffset duration:ToastDispalyDuration];
}

+ (void)depictBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset duration:(CGFloat)duration{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:[self window] fromBottomOffset:bottomOffset];
}

@end


@implementation UIView (NnnbTips)

#pragma mark-中间
- (void)depictNnnbTipsCenterWithText:(NSString *)text
{
    [self depictNnnbTipsCenterWithText:text duration:ToastDispalyDuration];
}

- (void)depictNnnbTipsCenterWithText:(NSString *)text duration:(CGFloat)duration
{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:self];
}

#pragma mark-上方
- (void)depictNnnbTipsTopWithText:(NSString *)text
{
    [self depictNnnbTipsTopWithText:text topOffset:ToastSpace duration:ToastDispalyDuration];
}

- (void)depictNnnbTipsTopWithText:(NSString *)text duration:(CGFloat)duration
{
    [self depictNnnbTipsTopWithText:text topOffset:ToastSpace duration:duration];
}

- (void)depictNnnbTipsTopWithText:(NSString *)text topOffset:(CGFloat)topOffset
{
    [self depictNnnbTipsTopWithText:text topOffset:topOffset duration:ToastDispalyDuration];
}

- (void)depictNnnbTipsTopWithText:(NSString *)text topOffset:(CGFloat)topOffset duration:(CGFloat)duration
{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:self fromTopOffset:topOffset];
}

#pragma mark-下方
- (void)depictNnnbTipsBottomWithText:(NSString *)text
{
    [self depictNnnbTipsBottomWithText:text bottomOffset:ToastSpace duration:ToastDispalyDuration];
}

- (void)depictNnnbTipsBottomWithText:(NSString *)text duration:(CGFloat)duration
{
    [self depictNnnbTipsBottomWithText:text bottomOffset:ToastSpace duration:duration];
}

- (void)depictNnnbTipsBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset
{
    [self depictNnnbTipsBottomWithText:text bottomOffset:bottomOffset duration:ToastDispalyDuration];
}

- (void)depictNnnbTipsBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset duration:(CGFloat)duration
{
    NnnbTips *toast = [[NnnbTips alloc] initWithText:text];
    toast.duration = duration;
    [toast depictIn:self fromBottomOffset:bottomOffset];
}

@end

