//
//  UITabBar+NnnbTabBar.h
//  RedBadge
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBar (DKSTabBar)

/**
 *  小红点
 *
 *  @param index 传入需要现实的位置
 */
- (void)showBadgeIndex:(NSInteger)index;

/**
 *  小红点
 *
 *  @param index 传入需要的位置
 */
- (void)hideBadgeIndex:(NSInteger)index;

@end
