//
//  UITabBarItem+NnnbBadge.m
//  RedBadge
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "UITabBarItem+NnnbBadge.h"
#import "UIView+NnnbBadge.h"

@implementation UITabBarItem (DKSBadge)

- (void)showBadge
{
    [[self getActualBadgeSuperView] showBadge]; //调用UIView的方法
}

- (void)hidenBadge
{
    [[self getActualBadgeSuperView] hidenBadge]; //调用UIView的方法
}

- (UIView *)getActualBadgeSuperView
{
    // 1.get UITabbarButtion
    UIView *bottomView = [self valueForKeyPath:@"_view"];
    
    // 2.get imageView, to make sure badge front at anytime.
    UIView *actualSuperView = nil;
    if (bottomView) {
        actualSuperView = [self findView:bottomView firstSubviewWithClass:NSClassFromString(@"UITabBarSwappableImageView")];
    }
    // badge label will be added onto imageView
    return actualSuperView;
}

/**
 * 获取UIView
 */
- (UIView *)findView:(UIView *)view firstSubviewWithClass:(Class)cls
{
    __block UIView *targetView = nil;
    [view.subviews enumerateObjectsUsingBlock:^(UIView *subview, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([subview isKindOfClass:cls]) {
            targetView = subview;
            *stop = YES;
        }
    }];
    return targetView;
}

@end
