//
//  UITabBarItem+NnnbBadge.h
//  RedBadge
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarItem (DKSBadge)

/**
 * 小红点
 * 需要在哪个item上面红点时，就用那个item调用
 */
- (void)showBadge;

/**
 * 小红点
 * 需要哪个item上面红点时，就用那个item调用
 */
- (void)hidenBadge;

@end
