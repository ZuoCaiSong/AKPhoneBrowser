//
//  UIView+NnnbBadge.h
//  TestProject
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (DKSBadge)

/**
 *  通过创建label，小红点；
 */
@property (nonatomic, strong) UILabel *badge;

/**
 *  小红点
 */
- (void)showBadge;

/**
 * 几个小红点儿
 * parameter redCount 小红点儿个数
 */
- (void)showBadgeWithCount:(NSInteger)redCount;

/**
 *  小红点
 */
- (void)hidenBadge;

@end
