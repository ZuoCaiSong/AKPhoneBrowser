//
//  NnnbColorEx.h
//  扩展颜色的功能
//  将＃ffffff  or  oxfffffff转化为UIColor
//  将UIColor转为字符串
//  ...
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIColor (NnnbColorEx)

- (NSString *) stringFromColor;  
// stringToConvert格式为(r,g,b,a)
+ (UIColor *) colorWithString: (NSString *) stringToConvert;  

- (NSString *) hexStringFromColor;  

// 由外界释放返回的color
+ (UIColor *) colorWithHexStringBeta: (NSString *) stringToConvert;


+ (UInt32) RGBWithString: (NSString *) stringToRGB;


+ (UIColor *) colorWithHexString: (NSString *) stringToConvert;
@end
