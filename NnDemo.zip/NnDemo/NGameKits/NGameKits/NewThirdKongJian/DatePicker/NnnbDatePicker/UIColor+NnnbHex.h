//
//  UIColor+NnnbHex.h
//  HooDatePickerDemo
//
//  Created by piggybear on 2017/7/25.
//  Copyright © 2017年 piggybear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (PGHex)
+ (UIColor *)colorWithHexString:(NSString *)hexString;
@end
