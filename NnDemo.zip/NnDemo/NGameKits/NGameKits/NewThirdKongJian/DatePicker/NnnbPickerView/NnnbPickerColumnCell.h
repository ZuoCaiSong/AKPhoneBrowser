//
//  NnnbPickerColumnCell.h
//  NnnbPickerView
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NnnbPickerColumnCell : UITableViewCell
@property (nonatomic, weak) UILabel *label;
@end
