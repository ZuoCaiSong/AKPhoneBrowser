//
//  NSBundle+Game.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NSBundle+Game.h"

#define TwSTRING_TABLE @"Localizable"
#define MYBUNDLE_PATH [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: MYBUNDLE_NAME]
#define MYBUNDLE [NSBundle bundleWithPath: MYBUNDLE_PATH]

@implementation NSBundle(Game)

+(NSBundle*)nnBuddle
{
    return MYBUNDLE;
}

+(NSString*)nnLocalizedString:(NSString *)key
{
    NSString* strTable = @"zh_CN.lproj/";
    NSString *currentLanuage=[[NSLocale preferredLanguages] objectAtIndex:0];
	if ([currentLanuage isEqualToString:@"en"])
    {
        strTable = @"English.lproj/";

	}
    else if([currentLanuage isEqualToString:@"zh-Hant"])
    {
		strTable = @"zh_TW.lproj/";
	}
    
    strTable = [strTable stringByAppendingString:TwSTRING_TABLE];
    return [[NSBundle nnBuddle]localizedStringForKey:key value:@"" table:strTable];
}
@end
