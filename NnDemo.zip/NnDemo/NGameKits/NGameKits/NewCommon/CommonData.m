//
//  CommonData.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "CommonData.h"

static CommonData *_twCommonDataInstance = nil;

@implementation CommonData

+(CommonData *)GetCommonDataInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _twCommonDataInstance = [[CommonData alloc] init];
    });
    
    return _twCommonDataInstance;
}

- (id)init
{
    self = [super init];
    
    if (self)
    {
        _strExtInfo = @"";
        _ijin = 6;
        _defaultServerId = 1;
        _strServerName = @"";
        _strProductId = @"";
        _strProductName = @"";
        _strProductDes = @"";
        _roleName = @"";
        _roleID = @"";
        _bIsBuying = NO;
        _packageState = -1;
        _sVersion = -1;
        _sRecr = -1;
        _sCur = -1;
        _sPub = -1;
        _accState = 0;
        _randomAccReq = NO;
        _bHadLogin = NO;
        _currentDirection = -1;
    }
    
    return self;
}

- (NSInteger)judgeDirection{
    // 横竖屏判断
    UIInterfaceOrientation interfaceOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    
    if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
        return 1;
    } else {
        return 0;
    }
}

- (void)saveExt:(NSString *)strCustomInfo jin:(NSUInteger)iJin serverID:(NSInteger)serverID serverName:(NSString *)servername roleName:(NSString *)rolename roleID:(NSString*)strRoleID productID:(NSString *)productid productName:(NSString *)productName productDes:(NSString *)ProductDes
{
    _strExtInfo = strCustomInfo;
    _ijin = iJin;
    _defaultServerId = serverID;
    _strServerName = servername;
    _roleName = rolename;
    _roleID = strRoleID;
    _strProductId = productid;
    _strProductName = productName;
    _strProductDes = ProductDes;
}

@end
