//
//  UIView+Game.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView(Game)
-(CGFloat)left;
-(CGFloat)top;
-(CGFloat)width;
-(CGFloat)height;

#pragma - 为了不影响之前的使用保留上面四个方法，以后推荐使用下面方法
@property (assign, nonatomic) CGFloat tp_x;
@property (assign, nonatomic) CGFloat tp_y;
@property (assign, nonatomic) CGFloat tp_w;
@property (assign, nonatomic) CGFloat tp_h;
@property (assign, nonatomic) CGSize  tp_size;
@property (assign, nonatomic) CGFloat tp_centerX;
@property (assign, nonatomic) CGFloat tp_centerY;
@property (assign, nonatomic) CGFloat tp_left;
@property (assign, nonatomic) CGFloat tp_top;
@property (assign, nonatomic) CGFloat tp_right;
@property (assign, nonatomic) CGFloat tp_bottom;
@property (assign, nonatomic) CGPoint tp_origin;

@end

