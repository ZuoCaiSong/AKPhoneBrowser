//
//  NnnbCommons.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbCommons.h"
#import "UIDevice+Game.h"
#import "RegexKitLite.h"
#import "Reachability.h"
#import "sys/utsname.h"
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>

//分辨率
#define     DISPLAY_640_1136                    @"640*1136"
#define     DISPLAY_640_960						@"640*960"
#define     DISPLAY_320_480						@"320*480"
#define     DISPLAY_1024_768					@"1024*768"

//设备
#define     DEVICE_IPHONE4                      @"iPhone3,1"
#define     DEVICE_IPHONE4S                     @"iPhone4,1"
#define     DEVICE_IPHONE5                      @"iPhone5,1"

//@interface NnnbCommons (){
//    NSDate *_lastClickTime;
//    NSTimeInterval _timeInterval;
//}
//@end

@implementation NnnbCommons

//获取当前语言
+ (NSInteger)getCurrentLanguage
{
	NSInteger lang = 1;//english
	NSString *currentLanuage=[[NSLocale preferredLanguages] objectAtIndex:0];
	if ([currentLanuage isEqualToString:@"zh-Hans"])
    {
		lang = 2;//简体中文
	}
    else if([currentLanuage isEqualToString:@"zh-Hant"])
    {
		lang = 3;//繁体中文
	}
    
	return lang;
}

//获取屏幕分辨率
+ (NSString *)getCurrentScreenDpi
{
	NSString *strPlat = [UIDevice currentPlats];
	
	NSString *deviceName =[[UIDevice currentDevice] model];
	NSString *key = [[deviceName substringToIndex:4]lowercaseString];
	
	if([key isEqualToString:@"ipad"])
	{
		return @"1024*768";
	}
    else if([key isEqualToString:@"ipod"])
	{
		return DISPLAY_320_480;
	}
    else if([key isEqualToString:@"ipho"])
	{
        if ([strPlat isEqualToString:DEVICE_IPHONE5])
        {
            return DISPLAY_640_1136;
        }
		else if([strPlat isEqualToString:DEVICE_IPHONE4] | [strPlat isEqualToString:DEVICE_IPHONE4S])
		{
			return DISPLAY_640_960;
		}
		else
        {
			return DISPLAY_320_480;
		}
		
	}
	
	return DISPLAY_320_480;
}

+ (BOOL)isEmail:(NSString *)mailStr
{
    BOOL bIsEmail = NO;
    if (mailStr && [mailStr stringByMatching:@"\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*"])
    {
        bIsEmail=YES;
	}
    
    return bIsEmail;
}

+ (BOOL)isURL:(NSString *)urlStr
{
    BOOL bIsURL = NO;
    if (urlStr && [urlStr stringByMatching:@"[a-zA-z]+://[^\\s]*"])
    {
        bIsURL=YES;
	}
    
    return bIsURL;
}

+(BOOL)isPhoneNumber:(NSString*)strPhoneNum
{
    BOOL bIsPhone = NO;
    if (strPhoneNum && [strPhoneNum stringByMatching:@"^\\d{11}$"])
    {
        bIsPhone = YES;
	}
    
    return bIsPhone;
}



+ (BOOL)checkPassword:(NSString*)strPassword
{
    BOOL bCorrect = NO;
    if (strPassword
        && [strPassword stringByMatching:@"^[\\x00-\\xff]+$"])
    {
        if ([strPassword stringByMatching:@"^[\\u4e00-\\u9fa5]"])
        {
            bCorrect=NO;
        }
        else
        {
            bCorrect=YES;
        }
	}
    
    return bCorrect;
}

+ (BOOL)checkAccount:(NSString*)strAccount
{
    BOOL bCorrect = NO;
    if (strAccount
        && [strAccount stringByMatching:@"^\\w+$"])
    {
        if ([strAccount stringByMatching:@"^[\\u4e00-\\u9fa5]"])
        {
            bCorrect=NO;
        }
        else
        {
            bCorrect=YES;
        }
	}
    
    return bCorrect;
}

//只能输入数字
+ (BOOL)isNumber:(NSString*)strNum
{
    BOOL bIsNum = NO;
    
    if (strNum && [strNum stringByMatching:@"^[0-9]*$"])
    {
        bIsNum = YES;
	}
    
    return bIsNum;
}

+ (BOOL)checkChinese:(NSString*)strPassword
{
    BOOL bCorrect = NO;
    if (strPassword
        && [strPassword stringByMatching:@"[\\u4e00-\\u9fff]"])
    {
        bCorrect=YES;
	}
    
    return bCorrect;
}

+ (BOOL)isChinese:(NSString *)str
{
    NSString *match = @"(^[\u4e00-\u9fa5]+$)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF matches %@", match];
    return [predicate evaluateWithObject:str];
}

+ (BOOL)checkPersonID:(NSString *)str
{
    if (str.length != 18) return NO;
    // 正则表达式判断基本 身份证号是否满足格式
    NSString *regex2 = @"^(^[1-9]\\d{7}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])\\d{3}$)|(^[1-9]\\d{5}[1-9]\\d{3}((0\\d)|(1[0-2]))(([0|1|2]\\d)|3[0-1])((\\d{4})|\\d{3}[Xx])$)$";
    NSPredicate *identityStringPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    //如果通过该验证，说明身份证格式正确，但准确性还需计算
    if(![identityStringPredicate evaluateWithObject:str]) return NO;
    
    //** 开始进行校验 *//
    
    //将前17位加权因子保存在数组里
    NSArray *idCardWiArray = @[@"7", @"9", @"10", @"5", @"8", @"4", @"2", @"1", @"6", @"3", @"7", @"9", @"10", @"5", @"8", @"4", @"2"];
    
    //这是除以11后，可能产生的11位余数、验证码，也保存成数组
    NSArray *idCardYArray = @[@"1", @"0", @"10", @"9", @"8", @"7", @"6", @"5", @"4", @"3", @"2"];
    
    //用来保存前17位各自乖以加权因子后的总和
    NSInteger idCardWiSum = 0;
    for(int i = 0;i < 17;i++) {
        NSInteger subStrIndex = [[str substringWithRange:NSMakeRange(i, 1)] integerValue];
        NSInteger idCardWiIndex = [[idCardWiArray objectAtIndex:i] integerValue];
        idCardWiSum+= subStrIndex * idCardWiIndex;
    }
    
    //计算出校验码所在数组的位置
    NSInteger idCardMod=idCardWiSum%11;
    //得到最后一位身份证号码
    NSString *idCardLast= [str substringWithRange:NSMakeRange(17, 1)];
    //如果等于2，则说明校验码是10，身份证号码最后一位应该是X
    if(idCardMod==2) {
        if(![idCardLast isEqualToString:@"X"]||[idCardLast isEqualToString:@"x"]) {
            return NO;
        }
    }
    else{
        //用计算出的验证码与最后一位身份证号码匹配，如果一致，说明通过，否则是无效的身份证号码
        if(![idCardLast isEqualToString: [idCardYArray objectAtIndex:idCardMod]]) {
            return NO;
        }
    }
    return YES;
}

+ (BOOL)isEnable3G
{
    return ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] != NotReachable);
}

+ (BOOL)isJailBroken
{
    return [UIDevice isJailBroken];
}

+ (BOOL)isIpad
{	
	NSString *deviceName =[[UIDevice currentDevice] model];
	NSString *key = [[deviceName substringToIndex:4]lowercaseString];
	
	if([key isEqualToString:@"ipad"])
	{
		return YES;
	}
    else
    {
        return NO;
    }
}

//获取app名称
+ (NSString *)getAppName
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    // app名称
    NSString *app_Name = [infoDictionary objectForKey:@"CFBundleDisplayName"];
    return app_Name;
}

//获取app的build版本号
+ (NSString *)getAppBuildVersion
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    // app build版本
    NSString *app_build = [infoDictionary objectForKey:@"CFBundleVersion"];
    return app_build;
}

//获取app的版本号
+ (NSString *)getAppVersion
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    // app版本
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    return app_Version;
}

/****************************************************
  *  函数名:  postLoginSuccessMsg
  *  功  能:  抛出登录成功的消息
  *  入  参: 
  *         无
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
+ (void)postLoginSuccessMsg
{
    DataManger *_dataManger = [DataManger getInstance];
    
    NSDictionary* dicUserInfo  = [NSDictionary dictionaryWithObjectsAndKeys:
                                  [NSString stringWithFormat:@"%ld",_dataManger.currentUserInfo.lUserId], KEY_USER_ID,
                                  _dataManger.systemInfo.strSessionId, KEY_LOGIN_SIGN, nil];

    [[NSNotificationCenter defaultCenter]postNotificationName:NN_NOTIF_LOGIN_SUCCESS
                                                       object:nil
                                                     userInfo:dicUserInfo];
}

//获取当前设备型号
+ (NSString *)GetDevideModel
{
    struct utsname TwSystemInfoSta;
    uname(&TwSystemInfoSta);
    NSString *deviceString = [NSString stringWithCString:TwSystemInfoSta.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone 2G";
    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    
    if ([deviceString isEqualToString:@"iPhone3,1"] || [deviceString isEqualToString:@"iPhone3,2"] || [deviceString isEqualToString:@"iPhone3,3"])
        return @"iPhone 4";
    
    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    
    if ([deviceString isEqualToString:@"iPhone5,1"] || [deviceString isEqualToString:@"iPhone5,2"])
        return @"iPhone 5";
    
    if ([deviceString isEqualToString:@"iPhone5,3"]|| [deviceString isEqualToString:@"iPhone5,4"])
        return @"iPhone 5C";
    
    if ([deviceString isEqualToString:@"iPhone6,1"] || [deviceString isEqualToString:@"iPhone6,2"] || [deviceString isEqualToString:@"iPhone6,3"])
        return @"iPhone 5S";
    
    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6Plus";
    
    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6S";
    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6S Plus";
    
    if ([deviceString isEqualToString:@"iPhone8,4"])    return@"iPhone SE";
    
    if ([deviceString isEqualToString:@"iPhone9,1"])    return @"iPhone7";
    if ([deviceString isEqualToString:@"iPhone9,2"])    return @"iPhone7Plus";
    
    if([deviceString isEqualToString:@"iPhone10,1"] || [deviceString isEqualToString:@"iPhone10,4"])
        return@"iPhone 8";
    
    if([deviceString isEqualToString:@"iPhone10,2"] || [deviceString isEqualToString:@"iPhone10,5"])
        return@"iPhone 8 Plus";
    
    if([deviceString isEqualToString:@"iPhone10,3"] || [deviceString isEqualToString:@"iPhone10,6"])
        return@"iPhone X";
    
    if ([deviceString isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    if ([deviceString isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    if ([deviceString isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    if ([deviceString isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    if ([deviceString isEqualToString:@"iPod5,1"])      return @"iPod Touch 5G";
    
    if([deviceString isEqualToString:@"iPad1,1"])  return@"iPad 1G";
    
    if([deviceString isEqualToString:@"iPad2,1"] || [deviceString isEqualToString:@"iPad2,2"] || [deviceString isEqualToString:@"iPad2,3"] || [deviceString isEqualToString:@"iPad2,4"])
        return@"iPad 2";
    
    if([deviceString isEqualToString:@"iPad2,5"] || [deviceString isEqualToString:@"iPad2,6"] || [deviceString isEqualToString:@"iPad2,7"])
        return@"iPad Mini 1G";
    
    if([deviceString isEqualToString:@"iPad3,1"] || [deviceString isEqualToString:@"iPad3,2"] || [deviceString isEqualToString:@"iPad3,3"])
        return@"iPad 3";
    
    if([deviceString isEqualToString:@"iPad3,4"] || [deviceString isEqualToString:@"iPad3,5"] || [deviceString isEqualToString:@"iPad3,6"])
        return@"iPad 4";
    
    if([deviceString isEqualToString:@"iPad4,1"] || [deviceString isEqualToString:@"iPad4,2"] || [deviceString isEqualToString:@"iPad4,3"])
        return@"iPad Air";
    
    if([deviceString isEqualToString:@"iPad4,4"] || [deviceString isEqualToString:@"iPad4,5"] || [deviceString isEqualToString:@"iPad4,6"])
        return@"iPad Mini 2G";
    
    if([deviceString isEqualToString:@"iPad4,7"] || [deviceString isEqualToString:@"iPad4,8"] || [deviceString isEqualToString:@"iPad4,9"])
        return@"iPad Mini 3";
    
    if([deviceString isEqualToString:@"iPad5,1"] || [deviceString isEqualToString:@"iPad5,2"])
        return@"iPad Mini 4";
    
    if([deviceString isEqualToString:@"iPad5,3"] || [deviceString isEqualToString:@"iPad5,4"])
        return@"iPad Air 2";
    
    if([deviceString isEqualToString:@"iPad6,3"] || [deviceString isEqualToString:@"iPad6,4"])
        return@"iPad Pro 9.7";
    
    if([deviceString isEqualToString:@"iPad6,7"] || [deviceString isEqualToString:@"iPad6,8"])  return@"iPad Pro 12.9";
    
    if ([deviceString isEqualToString:@"i386"])         return @"iPhone Simulator";
    if ([deviceString isEqualToString:@"x86_64"])       return @"iPhone Simulator";
    
    return @"unknown";
}

//获取 app URL Schemes
+ (NSString *)getAppUrlSchemes{
    NSBundle *mainBundle = [NSBundle mainBundle];
    NSArray* types=[mainBundle objectForInfoDictionaryKey:@"CFBundleURLTypes"];
    NSDictionary* dictionary=[types objectAtIndex:0];
    NSArray* schemes=[dictionary objectForKey:@"CFBundleURLSchemes"];
    NSString * urlSchemes = [schemes objectAtIndex:0];
    if (urlSchemes == nil) {
        return urlSchemes = @"";
    }
    
    NSRange range1 = [urlSchemes rangeOfString:@"("];
    NSRange range2 = [urlSchemes rangeOfString:@")"];
    NSRange range3 = [urlSchemes rangeOfString:@"\n"];
    NSRange range4 = [urlSchemes rangeOfString:@" "];
    
    //  此时获取的URL Schemes 形式为  （\n (\n   URL Schemes  \n)  \n）
    if ((range1.length > 0) || (range2.length > 0) || (range3.length > 0) || (range4.length > 0))
    {
        urlSchemes = [urlSchemes stringByReplacingOccurrencesOfString:@" " withString:@""];
        urlSchemes = [urlSchemes stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        urlSchemes = [urlSchemes stringByReplacingOccurrencesOfString:@"(" withString:@""];
        urlSchemes = [urlSchemes stringByReplacingOccurrencesOfString:@")" withString:@""];
    }

    return urlSchemes;
}

//是不是NSNotification对象
+ (BOOL)isNSNotificationObject:(NSNotification*)noti
{
    if ([noti isKindOfClass:[NSNotification class]]) {
        return YES;
    }
    else
    {
        return NO;
    }
}

//是不是NSDictionary对象
+ (BOOL)isNSDictionaryObject:(NSDictionary*)dict
{
    if ([dict isKindOfClass:[NSDictionary class]]) {
        return YES;
    }
    else
    {
        return NO;
    }
}

+ (BOOL)isFastDoubleClickInSecond:(CGFloat)second TagStr:(NSString *)tagStr{
    if (![tagStr isEqualToString:[CommonData GetCommonDataInstance].TagStr]) {
        [CommonData GetCommonDataInstance].lastClickTime = nil;
        [CommonData GetCommonDataInstance].TagStr = tagStr;
    }
    
    NSDate *lastClickTime = [CommonData GetCommonDataInstance].lastClickTime;
    
    NSDate *date = [NSDate date];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate:date];
    NSDate *currentTime = [date dateByAddingTimeInterval:interval];
    
    if (lastClickTime == nil) {
        [CommonData GetCommonDataInstance].lastClickTime = currentTime;
        return NO;
    }
    
    NSTimeInterval timeInterval = [currentTime timeIntervalSinceDate:lastClickTime];
    
    [CommonData GetCommonDataInstance].lastClickTime = currentTime;
    
    if (timeInterval < second) {
        return YES;
    } else {
        return NO;
    }
}

+(void)iapLocalVerifier:(NSString*)strReceipt
{
    NSURL *url = [NSURL URLWithString:@"https://sandbox.itunes.apple.com/verifyReceipt"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10.0f];
    request.HTTPMethod = @"POST";
    NSString *dataload = [NSString stringWithFormat:@"{\"receipt-data\":\"%@\"}", strReceipt];
    NSData *paloadData = [dataload dataUsingEncoding:NSUTF8StringEncoding];
    request.HTTPBody = paloadData;
    NSData *result = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    if (result == nil) {

        return;
    }
    
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:result options:NSJSONReadingAllowFragments error:nil];
}

//1电@信，2联@通，3移@动，4wifi、5铁@通、6其它[未连接网络或其他运商]
+(NSString *)GetInternetStatus
{
    Reachability *reachability   = [Reachability reachabilityWithHostName:@"www.apple.com"];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    NSString *net = @"4";
    switch (internetStatus) {
        case ReachableViaWiFi:
            net = @"4";
            break;
            
        case ReachableViaWWAN:
            net = [self getOperatorsType];
            break;
            
        case NotReachable:
            net = @"6";
            
        default:
            break;
    }
    
    return net;
}

+(NSString *)getOperatorsType{
    CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [telephonyInfo subscriberCellularProvider];
    
    NSString *currentCountryCode = [carrier mobileCountryCode];
    NSString *mobileNetWorkCode = [carrier mobileNetworkCode];
    
    if (![currentCountryCode isEqualToString:@"460"]) {
        return @"6";
    }
    
    if ([mobileNetWorkCode isEqualToString:@"00"] ||
        [mobileNetWorkCode isEqualToString:@"02"] ||
        [mobileNetWorkCode isEqualToString:@"07"]) {
        return @"3";
    }
    
    if ([mobileNetWorkCode isEqualToString:@"01"] ||
        [mobileNetWorkCode isEqualToString:@"06"] ||
        [mobileNetWorkCode isEqualToString:@"09"]) {
        return @"2";
    }
    
    if ([mobileNetWorkCode isEqualToString:@"03"] ||
        [mobileNetWorkCode isEqualToString:@"05"] ||
        [mobileNetWorkCode isEqualToString:@"11"]) {
        return @"1";
    }
    
    if ([mobileNetWorkCode isEqualToString:@"20"]) {
        return @"5";
    }
    
    return @"6";
}

@end
