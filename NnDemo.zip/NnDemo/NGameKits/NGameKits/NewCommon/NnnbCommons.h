//
//  NnnbCommons.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NnnbCommons : NSObject

//获取当前语言
// 1 英文， 2 中文， 3 繁体
+ (NSInteger)getCurrentLanguage;

//获取屏幕分辨率
+ (NSString *)getCurrentScreenDpi;

// 是否是邮箱
+ (BOOL)isEmail:(NSString *)mailStr;

//isURL
+ (BOOL)isURL:(NSString *)urlStr;

//是否手机号码
+(BOOL)isPhoneNumber:(NSString*)strPhoneNum;

/**
 检测密码有效性,密码由半角字符（字母、数字、符号）组成，区分大小写
 @param strPassword 密码
 @returns YES有效，NO表示无效
 */
+ (BOOL)checkPassword:(NSString*)strPassword;


/**
 检测账号有效性,账号由字母， 数字， 下划线组成
 @param strAccount 账号
 @returns YES有效，NO表示无效
 */
+ (BOOL)checkAccount:(NSString*)strAccount;

/**
 检测字符串是否全部由数字组成
 @param strNum 需要被检测的字符串
 @returns YES，NO
 */
+ (BOOL)isNumber:(NSString*)strNum;

/**
 检测字符串是否包括汉字
 @param strPassword 需要被检测的字符串
 @returns YES，NO
 */
+ (BOOL)checkChinese:(NSString*)strPassword;

/**
 检测字符串是否汉字
 @param strPassword 需要被检测的字符串
 @returns YES，NO
 */
+ (BOOL)isChinese:(NSString *)str;

+ (BOOL)checkPersonID:(NSString *)str;

/**
 是否启用WIFI
 @returns YES表示启用，否则不启用
 */
+ (BOOL)isEnableWIFI;

/**
 是否启用3G
 @returns YES表示启用，否则不启用
 */
+ (BOOL)isEnable3G;

+ (BOOL)isJailBroken;

/**
 判断是否是ipad
 @returns YES表示是，否则是
 */
+ (BOOL)isIpad;

//获取app名称
+ (NSString *)getAppName;

//获取app的build版本号
+ (NSString *)getAppBuildVersion;

//获取app的版本号
+ (NSString *)getAppVersion;

/****************************************************
 *  函数名:  postLoginSuccessMsg
 *  功  能:  抛出登录成功的消息
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
+ (void)postLoginSuccessMsg;

//获取当前设备型号
+ (NSString *)GetDevideModel;

//获取 app URL Schemes
+ (NSString *)getAppUrlSchemes;

//是不是NSNotification对象
+ (BOOL)isNSNotificationObject:(NSNotification*)noti;

//是不是NSDictionary对象
+ (BOOL)isNSDictionaryObject:(NSDictionary*)dict;

//是否快速点击
/*
 参数：
 second   快速点击的间隔时间
 tagStr   快速点击的识别字符，随意输入即可，但需要确认工程内是否已有此字符，不能相同
 */
+ (BOOL)isFastDoubleClickInSecond:(CGFloat)second TagStr:(NSString *)tagStr;

+(void)iapLocalVerifier:(NSString*)strReceipt;

+(NSString *)GetInternetStatus;
+(NSString *)getOperatorsType;

@end
