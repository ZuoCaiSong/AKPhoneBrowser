//
//  NnnbSButton.m
//  NGameKits
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSButton.h"

#define imageLeft 20
#define imageTop 10

@implementation NnnbSButton

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(imageLeft, imageTop, contentRect.size.height-imageTop*2, contentRect.size.height-imageTop*2);//图片的位置大小
}

-(CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(imageLeft+(contentRect.size.height-imageTop*2)+10, 0, contentRect.size.width-(imageLeft+(contentRect.size.height-imageTop*2)+10), contentRect.size.height);//文本的位置大小
}

@end
