//
//  UIView+Game.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "UIView+Game.h"

@implementation UIView(Game)

-(CGFloat)left
{
    return self.frame.origin.x;
}

-(CGFloat)top
{
    return self.frame.origin.y;
}

-(CGFloat)width
{
    return self.frame.size.width;
}

-(CGFloat)height
{
    return self.frame.size.height;
}


#pragma - 为了不影响之前的使用保留上面四个方法，以后推荐使用下面方法
- (void)setTp_x:(CGFloat)tp_x
{
    CGRect frame = self.frame;
    frame.origin.x = tp_x;
    self.frame = frame;
}

- (CGFloat)tp_x
{
    return self.frame.origin.x;
}

- (void)setTp_y:(CGFloat)tp_y
{
    CGRect frame = self.frame;
    frame.origin.y = tp_y;
    self.frame = frame;
}

- (CGFloat)tp_y
{
    return self.frame.origin.y;
}

- (void)setTp_w:(CGFloat)tp_w
{
    CGRect frame = self.frame;
    frame.size.width = tp_w;
    self.frame = frame;
}

- (CGFloat)tp_w
{
    return self.frame.size.width;
}

- (void)setTp_h:(CGFloat)tp_h
{
    CGRect frame = self.frame;
    frame.size.height = tp_h;
    self.frame = frame;
}

- (CGFloat)tp_h
{
    return self.frame.size.height;
}

- (void)setTp_size:(CGSize)tp_size
{
    CGRect frame = self.frame;
    frame.size = tp_size;
    self.frame = frame;
}

- (CGSize)tp_size
{
    return self.frame.size;
}

- (CGFloat)tp_centerX
{
    return self.center.x;
}

- (void)setTp_centerX:(CGFloat)tp_centerX
{
    CGPoint center = self.center;
    center.x = tp_centerX;
    self.center = center;
}

- (CGFloat)tp_centerY
{
    return self.center.y;
}

- (void)setTp_centerY:(CGFloat)tp_centerY
{
    CGPoint center = self.center;
    center.y = tp_centerY;
    self.center = center;
}

- (CGFloat)tp_left
{
    return self.frame.origin.x;
}

- (void)setTp_left:(CGFloat)tp_left
{
    CGRect frame = self.frame;
    frame.origin.x = tp_left;
    self.frame = frame;
}

- (CGFloat)tp_top
{
    return self.frame.origin.y;
}

- (void)setTp_top:(CGFloat)tp_top
{
    CGRect frame = self.frame;
    frame.origin.y = tp_top;
    self.frame = frame;
}

- (CGFloat)tp_right
{
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setTp_right:(CGFloat)tp_right
{
    CGRect frame = self.frame;
    frame.origin.x = tp_right - frame.size.width;
    self.frame = frame;
}

- (CGFloat)tp_bottom
{
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setTp_bottom:(CGFloat)tp_bottom
{
    CGRect frame = self.frame;
    frame.origin.y = tp_bottom - frame.size.height;
    self.frame = frame;
}

- (void)setTp_origin:(CGPoint)tp_origin
{
    CGRect frame = self.frame;
    frame.origin = tp_origin;
    self.frame = frame;
}

- (CGPoint)tp_origin
{
    return self.frame.origin;
}


@end
