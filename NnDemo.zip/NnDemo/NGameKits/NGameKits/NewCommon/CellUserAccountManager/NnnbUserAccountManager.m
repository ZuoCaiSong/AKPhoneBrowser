//
//  NnnbUserAccountManager.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbUserAccountManager.h"
static NnnbUserAccountManager* _userAccountManagerInstance = nil;

@interface NnnbUserAccountManager ()

@property(nonatomic,strong)NSMutableArray *userAccountsArr;

@end

@implementation NnnbUserAccountManager
+(NnnbUserAccountManager*)getInstance
{
    @synchronized(self)
    {
        if (_userAccountManagerInstance == nil)
        {
            _userAccountManagerInstance = [[NnnbUserAccountManager alloc]init];
        }
    }
    return _userAccountManagerInstance;
}

-(void)setLoginAccount:(NSString*)user_id andPwd:(NSString*)pwd andRememberPsw:(NSString *)rpsw andAutoLogin:(NSString *)autoLogin{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    self.userAccountsArr = [NSMutableArray arrayWithArray:[keyChain kcObjectForKey:@"login_userArr"]];
    if (!self.userAccountsArr) {
        self.userAccountsArr = [NSMutableArray array];
    }
    NSMutableArray *arr = [NSMutableArray array];
    for (NSDictionary *dict in self.userAccountsArr) {
        NSString *user_Account = [dict objectForKey:@"login_userId"];
        if (![user_Account isEqualToString:user_id]) {
            [arr addObject:dict];
        }
    }
    self.userAccountsArr = arr;
    if (self.userAccountsArr.count >= 3) {
        [self.userAccountsArr removeObjectAtIndex:0];
    }
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:user_id forKey:@"login_userId"];
    [dic setObject:pwd forKey:@"login_pwd"];
    [dic setObject:rpsw forKey:@"rememberPsw"];
    [dic setObject:autoLogin forKey:@"autoLogin"];
    [self.userAccountsArr addObject:dic];
    [keyChain kcSetObject:self.userAccountsArr forKey:@"login_userArr"];
}

-(NSArray *)getLoginAccounts{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    self.userAccountsArr = [keyChain kcObjectForKey:@"login_userArr"];
    return self.userAccountsArr;
}

-(void)deleteAccountWithIndex:(NSInteger)index{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    self.userAccountsArr = [NSMutableArray arrayWithArray:[keyChain kcObjectForKey:@"login_userArr"]];
    if (self.userAccountsArr.count > index) {
        [self.userAccountsArr removeObjectAtIndex:index];
    }
    [keyChain kcSetObject:self.userAccountsArr forKey:@"login_userArr"];
}
@end
