//
//  UIDevice.h
//  MeYou
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIDevice.h>
#import <Foundation/Foundation.h>


@interface UIDevice(Game)

/**
	获取设备模式信息
	@returns 设备模式,返回值如下：
	 iPhone1,1 ->    iPhone 1G
	 iPhone1,2 ->    iPhone 3G
	 iPhone2,1 ->    iPhone 3GS
	 iPhone3,1 ->    iPhone 4
	 
	 iPod1,1   -> iPod touch 1G
	 iPod2,1   -> iPod touch 2G
	 iPod2,2   -> iPod touch 2.5G
	 iPod3,1   -> iPod touch 3G
	 iPod4,1   -> iPod touch 4
	 
	 iPad1,1   -> iPad 1G, WiFi
 */
+ (NSString *)currentPlats;

/**
	获取网卡的MAC地址
	@returns MAC地址
 */
+ (NSString *)macaddress;

/**
	获取运营商名称
	@returns 运营商名称
 */
+ (NSString *)carrierName;


/**
	获取运营商国家码
	@returns 运营商国家码
 */
+ (NSString *)carrierCountryCode;

/**
	获取手机所属国家码
	@returns 手机所属国家码
 */
+ (NSString *)mobileCountryCode;

/**
	获取系统
	@returns YES表示已经，否则没有。
 */
+ (BOOL)isJailBroken;

/**
	获取设备生产商名称
	@returns 固定返回"Apple"
 */
+ (NSString *)deviceManufacturer;

/****************************************************
 *  函数名:  getNnAdID
 *  功  能:  获取广告ID
 *  入  参:
 *         无
 *  出  参:
 *         广告
 *  说  明:
 ****************************************************/
+ (NSString *)getNnAdID;

@end
