//
//  UIDevice.m
//  MeYou
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "UIDevice+Game.h"
#import <sys/sysctl.h>
#import <sys/socket.h>
#import <net/if.h>
#import <net/if_dl.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import "NSString+Additions.h"
#import <AdSupport/AdSupport.h>

/**
	应用列表，用于检测机器是否进行
 */
static const char* jailbreak_apps[] =
{
	"/Applications/Cydia.app",
	"/Applications/limera1n.app",
	"/Applications/greenpois0n.app",
	"/Applications/blackra1n.app",
	"/Applications/blacksn0w.app",
	"/Applications/redsn0w.app",
	NULL,
};

@implementation UIDevice(Game)

+ (NSString *)currentPlats
{
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    
    char *answer = malloc(size);
    sysctlbyname("hw.machine", answer, &size, NULL, 0);
    
    NSString *results = [NSString stringWithCString:answer encoding: NSUTF8StringEncoding];
    free(answer);
    
    return results;
}

+ (NSString *)macaddress
{
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
     mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error\n");
        return nil;
    }
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1\n");
        return nil;
    }

    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!\n");
        return nil;
    }

    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0)
    {
        free(buf);
        printf("Error: sysctl, take 2");
        return nil;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X", 
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_6_0
   return [self getNnAdID];
#endif
    
    return outstring;
}

+ (NSString *)carrierName
{
	if ([[UIDevice currentDevice].systemVersion versionStringCompare:@"4.0"] != NSOrderedAscending)
	{
		//4.0以上版本才支持此功能
		CTTelephonyNetworkInfo *netinfo = [[CTTelephonyNetworkInfo alloc] init];
		CTCarrier *carrier = [netinfo subscriberCellularProvider];
		NSString *carrierName = [carrier carrierName];
		[netinfo release];
		return carrierName;
	}
	return @"";
}

+ (NSString *)carrierCountryCode
{
	if ([[UIDevice currentDevice].systemVersion versionStringCompare:@"4.0"] != NSOrderedAscending)
	{
		//4.0以上版本才支持此功能
		CTTelephonyNetworkInfo *netinfo = [[CTTelephonyNetworkInfo alloc] init];
		CTCarrier *carrier = [netinfo subscriberCellularProvider];
		NSString *isoCountryCode = [carrier isoCountryCode];
		[netinfo release];
		
		return isoCountryCode;
	}
	return @"";
}

+ (NSString *)mobileCountryCode
{
	if ([[UIDevice currentDevice].systemVersion versionStringCompare:@"4.0"] != NSOrderedAscending)
	{
		//4.0以上版本才支持此功能
		CTTelephonyNetworkInfo *netinfo = [[CTTelephonyNetworkInfo alloc] init];
		CTCarrier *carrier = [netinfo subscriberCellularProvider];
		NSString *mobileCountryCode = [carrier mobileCountryCode];
		[netinfo release];
		return mobileCountryCode;
	}
	return @"";
}

+ (BOOL)isJailBroken
{
	for (NSInteger i = 0; jailbreak_apps[i] != NULL; ++i)
	{
		//检测应用路径的方式来判断是否
		if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithUTF8String:jailbreak_apps[i]]])
		{
			return YES;
		}		
	}
	
	return NO;
}

+ (NSString *)deviceManufacturer
{
	return @"Apple";
}

/****************************************************
 *  函数名:  getSaveAdIDFromKeyChain
 *  功  能:  从钥匙串中获取广告id
 *  入  参:
 *         无
 *  出  参:
 *  		获取的广告id
 *  说  明:
 ****************************************************/
+ (NSString *)getSaveAdIDFromKeyChain
{
    NnnbKeyChain *keychain = [NnnbKeyChain standardKeyChain];
    NSString *strAdID = [keychain kcObjectForKey:NN_IDFA_CHAINKEY];
    
    if ((strAdID == nil) || (strAdID == NULL) || (strAdID.length == 0))
    {
        //重新创建广告id
        strAdID = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
        
        //保存创建的广告id
        [keychain kcSetObject:strAdID forKey:NN_IDFA_CHAINKEY];
    }
    
    return strAdID;
}

/****************************************************
 *  函数名:  getNnAdID
 *  功  能:  获取广告ID
 *  入  参:
 *         无
 *  出  参:
 *         广告
 *  说  明:
 ****************************************************/
+ (NSString *)getNnAdID
{
    NSString *strAdID = [self getSaveAdIDFromKeyChain];
    return strAdID;
}

@end
