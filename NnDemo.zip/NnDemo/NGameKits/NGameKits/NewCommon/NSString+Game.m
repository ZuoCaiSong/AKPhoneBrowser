//
//  UIImage+Game.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NSString+Game.h"

@implementation NSString(Game)
+ (NSString *)nnnbNSStringFromFileName:(NSString *)name
{
    NSBundle * libBundle = [NSBundle nnBuddle];
    if (libBundle != nil
        && name != nil)
    {
         NSString* fileName = [[libBundle resourcePath ] stringByAppendingPathComponent: name];
        
        NSString* str = [NSString stringWithContentsOfFile:fileName encoding:NSUTF8StringEncoding error:nil];
        
        return str;
    }
    
    return nil;

}

+ (BOOL)GGRar_isEmpty:(id)thing
{
    return thing == nil || [thing isEqual:[NSNull null]] || ([thing respondsToSelector:@selector(length)] &&
                                                             [(NSData*)thing length] == 0) || ([thing respondsToSelector:@selector(count)] &&
                                                                                               [(NSArray*)thing count] == 0);
}
@end
