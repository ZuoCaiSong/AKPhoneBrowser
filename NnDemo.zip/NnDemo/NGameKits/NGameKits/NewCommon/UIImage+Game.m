//
//  UIImage+Game.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "UIImage+Game.h"

@implementation UIImage(Game)
+ (UIImage *)nnGetPlatImage:(NSString *)imageName {
    if (!imageName||[imageName isKindOfClass:[NSNull class]]) {
        return nil;
    }
    else {
        NSString *imgName = [MYBUNDLE_NAME stringByAppendingPathComponent:imageName];
        return [UIImage imageNamed:imgName];
    }
}
+ (UIImage *)nnImageWithUrl:(NSString *)imgUrlString{
    if ([self isUrlSting:imgUrlString]) {
        NSData *imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imgUrlString]];
        return [UIImage imageWithData:imgData];
    }
    
    return [UIImage nnGetPlatImage:@"Syg_no_img.png"];
}
+ (BOOL)isUrlSting:(NSString *)UrlString{
    
    if([UrlString isKindOfClass:[NSNull class]] || !UrlString) {
        return NO;
    }
    if(UrlString && UrlString.length < 4) {
        return NO;
    }
    NSString *urlRegex = @"[a-zA-z]+://[^\\s]*";
    NSPredicate* urlPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegex];
    
    return [urlPredicate evaluateWithObject:UrlString];
}
@end
