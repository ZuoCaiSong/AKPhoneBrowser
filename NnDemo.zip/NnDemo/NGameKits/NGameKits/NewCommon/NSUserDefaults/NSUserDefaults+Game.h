//
//  NSUserDefaults+Game.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (Game)

/****************************************************
 *  函数名:  nnIntegerForKey
 *  功  能:  获取加密后的key对应的整数值
 *  入  参:
 *			 (NSString *) defaultName 				明文key
 *  出  参:
 *  		加密后的key对应的整数值
 *  说  明:
 ****************************************************/
- (NSInteger)nnIntegerForKey:(NSString *)defaultName;

/****************************************************
 *  函数名:  nnSetInteger:forKey:
 *  功  能:  保存整型数据
 *  入  参:
 *			 (NSInteger *) value 				整型数据
 *			 (NSString *) defaultName 			key
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)nnSetInteger:(NSInteger)value forKey:(NSString *)defaultName;

/****************************************************
 *  函数名:  nnPlatObjectForKey
 *  功  能:  获取key对应的对象
 *  入  参:
 *			 (NSString *) defaultName 				key
 *  出  参:
 *  		key对应的对象的数据
 *  说  明:
 ****************************************************/
- (id)nnPlatObjectForKey:(NSString *)defaultName;

/****************************************************
 *  函数名:  nnStringSetObject:forKey:
 *  功  能:  保存加密后的字符串
 *  入  参:
 *			 (NSString *) value 				原始字符串
 *			 (NSString *) defaultName 			key
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)nnStringSetObject:(NSString *)value forKey:(NSString *)defaultName;

@end
