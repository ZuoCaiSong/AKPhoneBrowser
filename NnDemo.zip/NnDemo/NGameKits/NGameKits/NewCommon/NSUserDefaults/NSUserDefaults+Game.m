//
//  NSUserDefaults+Game.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NSUserDefaults+Game.h"

@implementation NSUserDefaults (Game)

//使用加密
#define __USER_ENCRYPT__

//定义数据加密解密key
#define __ENCRYPT_KEY__         @"nnFormencrypt"

/****************************************************
  *  函数名:  nnIntegerForKey
  *  功  能:  获取加密后的key对应的整数值
  *  入  参: 
  *			 (NSString *) defaultName 				明文key
  *  出  参: 
  *  		加密后的key对应的整数值
  *  说  明: 
 ****************************************************/
- (NSInteger)nnIntegerForKey:(NSString *)defaultName
{
    return [self integerForKey:[NnnbEncrypt sha1:defaultName]];
}

/****************************************************
  *  函数名:  nnSetInteger:forKey:
  *  功  能:  保存整型数据
  *  入  参: 
  *			 (NSInteger *) value 				整型数据
  *			 (NSString *) defaultName 			key
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)nnSetInteger:(NSInteger)value forKey:(NSString *)defaultName
{
    [self setInteger:value forKey:[NnnbEncrypt sha1:defaultName]];
}

/****************************************************
  *  函数名:  nnPlatObjectForKey
  *  功  能:  获取key对应的对象
  *  入  参:
  *			 (NSString *) defaultName 				key
  *  出  参: 
  *  		key对应的对象的数据
  *  说  明: 
 ****************************************************/
- (id)nnPlatObjectForKey:(NSString *)defaultName
{
#ifdef __USER_ENCRYPT__
    id data = [self objectForKey:[NnnbEncrypt sha1:defaultName]];
    
    if ([data isKindOfClass:[NSString class]])
    {
        //是字符串
        return [NnnbEncrypt decryptString:data withKey:__ENCRYPT_KEY__];
    }
    else
    {
        return data;
    }
#else
    return [self objectForKey:defaultName];
#endif
}

/****************************************************
  *  函数名:  nnStringSetObject:forKey:
  *  功  能:  保存加密后的字符串
  *  入  参: 
  *			 (NSString *) value 				原始字符串
  *			 (NSString *) defaultName 			key
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)nnStringSetObject:(NSString *)value forKey:(NSString *)defaultName
{
#ifdef __USER_ENCRYPT__
    [self setObject:[NnnbEncrypt encryptString:value withKey:__ENCRYPT_KEY__]
             forKey:[NnnbEncrypt sha1:defaultName]];
#else
    [self setObject:value forKey:defaultName];
#endif
}

@end
