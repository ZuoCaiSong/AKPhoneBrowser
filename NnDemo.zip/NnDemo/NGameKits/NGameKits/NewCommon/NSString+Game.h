//
//  UIImage+Game.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <UIKit/UIKit.h>

#define GGRar_isEmpty(obj)                [NSString GGRar_isEmpty:obj]

@interface NSString(Game)
+ (NSString *)nnnbNSStringFromFileName:(NSString *)name;
+ (BOOL)GGRar_isEmpty:(id)thing;
@end
