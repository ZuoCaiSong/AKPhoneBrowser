//
//  NnnbIAPManager.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbIAPManager.h"
#import "NnnbFacade+Get.h"

#define TW_INTERNET_TIMEOUT 10
static NnnbIAPManager *iapManager = nil;

@interface NnnbIAPManager() <SKProductsRequestDelegate, SKPaymentTransactionObserver>
@property(nonatomic, strong) SKProduct *myProduct;
@property(nonatomic, strong) NSMutableArray *receiptCheckArr;
@property(nonatomic, copy) NSString  *strProductID;      //id
@property(nonatomic, copy) NSString  *strOrderID;        //id
@end

@implementation NnnbIAPManager

#pragma mark - ****************  单例
+ (instancetype)sharedManager {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        iapManager = [[NnnbIAPManager alloc] init];
    });
    
    return iapManager;
}

- (void)makeIAP
{
    if ([CommonData GetCommonDataInstance].strProductId.length > 0)
    {
        if ([SKPaymentQueue canMakePayments])
        {
            [[NnnbFacadeCenter defaultFacade] downOrd:^(BOOL success, NSNotification *notifi) {
                if (success)
                {
                    NSDictionary *dict = [notifi.userInfo objectForKey:@"data"];
                    
                    self.strProductID = [dict objectForKey:@"pgPrdti"];
                    self.strOrderID = [dict  objectForKey:@"oi"];
                    
                    if (self.strOrderID == nil || self.strProductID == nil)
                    {
                        [self postMsgResult:@"0"];
                        return;
                    }
                    
                    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
                    [self requestProductWithId:self.strProductID];
                }
                else
                {
                    [self postMsgResult:@"0"];
                    //提示错误
                    NSString *strTips = [notifi.userInfo objectForKey:KEY_ERROR_TEXT];
                    [NnnbTips depictCenterWithText:strTips duration:NN_TIPS_TIME2];
                }
            }];
        }
        else
        {
            [NnnbTips depictCenterWithText:@"您禁止了应用权限,请到设置中开启" duration:NN_TIPS_TIME2];
            [self postMsgResult:@"0"];
        }
        
    }
    else
    {
        [NnnbTips depictCenterWithText:@"ID为空!" duration:NN_TIPS_TIME2];
        [self postMsgResult:@"0"];
    }
}

- (void)requestProductWithId:(NSString *)productId {
    
    NSSet *set = [NSSet setWithObject:productId];
    SKProductsRequest *productRequest = [[SKProductsRequest alloc]initWithProductIdentifiers:set];
    productRequest.delegate = self;
    [productRequest start];
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    
    NSArray *myProductArray = response.products;
    
    if (NULL == myProductArray || 0 == myProductArray.count) {
        [self getProductFail];
        [self postMsgResult:@"0"];
        return;
    } else {
        _myProduct = [myProductArray objectAtIndex:0];
    }
    
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    SKPayment * pment = [SKPayment paymentWithProduct:myProductArray[0]];
    [[SKPaymentQueue defaultQueue] addPayment:pment];
}

- (void)getProductFail{
    [NnnbTips depictCenterWithText:@"请重试" duration:NN_TIPS_TIME2];
}

/** TODO:请求完成*/
- (void)requestDidFinish:(SKRequest *)request{

}

/** TODO:请求错误（SKProductsRequest Delegate）*/
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error{
    [NnnbTips depictCenterWithText:@"请求错误" duration:NN_TIPS_TIME2];
    
    [self postMsgResult:@"0"];
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray<SKPaymentTransaction *> *)transactions {
    
    for (SKPaymentTransaction *transaction in transactions) {
        switch (transaction.transactionState) {
                
            case SKPaymentTransactionStatePurchasing:
                break;
                
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
                
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
                
            case SKPaymentTransactionStateRestored:
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                break;
                
            case SKPaymentTransactionStateDeferred:
                break;
                
            default:
                break;
        }
    }
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    [self removeAppStoreObserver];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
    NSData *receiptData = nil;
    
    if ([[NSBundle mainBundle] respondsToSelector:@selector(appStoreReceiptURL)]) {
        NSURL *receiptUrl = [[NSBundle mainBundle] appStoreReceiptURL];
        receiptData = [NSData dataWithContentsOfURL:receiptUrl];
    } else {
        if ([transaction respondsToSelector:@selector(transactionReceipt)]) {
            //Works in iOS3 - iOS8, deprected since iOS7, actual deprecated (returns nil) since iOS9
            receiptData = [transaction transactionReceipt];
        }
    }
    
    NSString *receiptStr = [receiptData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];

    NSString *info = [NSString stringWithFormat:@"user_name=%@&appid=%@&server_id=%ld&ext=%@&oiM=%ld",[DataManger getInstance].currentUserInfo.strUserName,[DataManger getInstance].systemInfo.strAppId,(long)[CommonData GetCommonDataInstance].defaultServerId,[CommonData GetCommonDataInstance].strExtInfo,(long)[CommonData GetCommonDataInstance].ijin];
    
    NSString *string = [NSString stringWithFormat:@"%@%@%@",receiptStr,info,[DataManger getInstance].systemInfo.strAppKey];
    NSString *sign = [NnnbEncrypt md5:string];
    
    NSString *dataload = [NSString stringWithFormat:@"{\"receipt-data\":\"%@\",\"receipt-data2\":\"%@\",\"receipt-data3\":\"sign=%@&version=%@&orderid=%@\"}",receiptStr,info,sign,NN_CURRENT_VERSION, self.strOrderID];
    NSData *paloadData = [dataload dataUsingEncoding:NSUTF8StringEncoding];
    
    [self saveReceipt:paloadData];

    NSURL *url = [NSURL URLWithString:RECEIPT_SERVER_URL];
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:TW_INTERNET_TIMEOUT];
    urlRequest.HTTPMethod = @"POST";
    
    urlRequest.HTTPBody = paloadData;
    
    //提交验证请求，并获得服务器返回的官方的验证JSON结果 iOS9后更改了另外的一个方法
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:nil delegateQueue:[NSOperationQueue mainQueue]];
    
    [[session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSString *strCode = @"";
        
        if (error) {
            
            [NnnbTips depictCenterWithText:@"请求超时" duration:NN_TIPS_TIME2];
            strCode = @"0";
            [self postMsgResult:strCode];
            
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObject:paloadData forKey:@"paLoadData"];
            [self checkReceiptAgain:dic];
            return;
        }
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        
        if ((dict != nil) && [NnnbCommons isNSDictionaryObject:dict] && [dict objectForKey:@"status"] && ([[dict objectForKey:@"status"] intValue] == 0)) {
            strCode = @"1";
            
            [self removeReceipt:paloadData];
        } else {
            strCode = @"0";
            
            [self removeReceipt:paloadData];
        }
        
        [self postMsgResult:strCode];
    }] resume];
}

- (void)saveReceipt:(NSData *)paloadData{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSMutableArray *receiptArr = [keyChain kcObjectForKey:@"receiptArray"];
    
    if (!receiptArr) {
        receiptArr = [NSMutableArray array];
    }
    
    NSString *userID = [NSString stringWithFormat:@"%ld",[DataManger getInstance].currentUserInfo.lUserId];
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:userID, @"userName",paloadData, @"paLoadData",nil];
    [receiptArr addObject:dic];
    
    [keyChain kcSetObject:receiptArr forKey:@"receiptArray"];
}

- (void)removeReceipt:(NSData *)paloadData{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSMutableArray *receiptArr = [keyChain kcObjectForKey:@"receiptArray"];
    NSMutableArray *tempArray = [NSMutableArray arrayWithArray:receiptArr];
    
    if ((tempArray) && (tempArray.count != 0)) {
        for (NSMutableDictionary *dic in tempArray) {
            NSData *PaLoadData = [dic objectForKey:@"paLoadData"];
            
            if ([PaLoadData isEqualToData:paloadData]) {
                [receiptArr removeObject:dic];
            }
        }
    }
    
    [keyChain kcSetObject:receiptArr forKey:@"receiptArray"];
}

- (void)checkReceipt{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSMutableArray *receiptArr = [keyChain kcObjectForKey:@"receiptArray"];
    
    if ((receiptArr) && (receiptArr.count != 0)) {
        [self performSelector:@selector(checkUnTestReceipt:) withObject:receiptArr afterDelay:10];
    }
}

- (void)checkUnTestReceipt:(NSMutableArray *)receiptArr{
    NSString *userID = [NSString stringWithFormat:@"%ld",[DataManger getInstance].currentUserInfo.lUserId];
    
    NSMutableDictionary *receiptDict = [receiptArr objectAtIndex:0];
    NSString *userName = [receiptDict objectForKey:@"userName"];
        
    if ([userName isEqualToString:userID]) {
        _receiptCheckArr = [NSMutableArray array];
            
        for (NSInteger index = 0; index < receiptArr.count; index ++) {
            [self performSelector:@selector(connectServerForUncheckReceipt:) withObject:receiptArr[index] afterDelay:((index + 1)*(TW_INTERNET_TIMEOUT + 2))];
        }
    }
}

- (void)connectServerForUncheckReceipt:(NSMutableDictionary *)plDataDic{
    NSData *plData = [plDataDic objectForKey:@"paLoadData"];
    
    NSURL *url = [NSURL URLWithString:RECEIPT_SERVER_URL];
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:TW_INTERNET_TIMEOUT];
    urlRequest.HTTPMethod = @"POST";
    
    urlRequest.HTTPBody = plData;
    
    //提交验证请求，并获得服务器返回的官方的验证JSON结果 iOS9后更改了另外的一个方法
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:nil delegateQueue:[NSOperationQueue mainQueue]];
    
    [[session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error) {
            return;
        }
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        
        if ((dict != nil) && [NnnbCommons isNSDictionaryObject:dict] && [dict objectForKey:@"status"] && ([[dict objectForKey:@"status"] intValue] == 0)) {
            [_receiptCheckArr addObject:plDataDic];
            
            [self updateReceiptArr];
        } else {            
            [_receiptCheckArr addObject:plDataDic];
            
            [self updateReceiptArr];
        }
        
    }] resume];
}

- (void)checkReceiptAgain:(NSMutableDictionary *)plDataDic{
    NSData *plData = [plDataDic objectForKey:@"paLoadData"];
    
    NSURL *url = [NSURL URLWithString:RECEIPT_SERVER_URL];
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:TW_INTERNET_TIMEOUT];
    urlRequest.HTTPMethod = @"POST";
    
    urlRequest.HTTPBody = plData;
    
    //提交验证请求，并获得服务器返回的官方的验证JSON结果 iOS9后更改了另外的一个方法
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:nil delegateQueue:[NSOperationQueue mainQueue]];
    
    [[session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error) {
            return;
        }
        
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
        
        if ((dict != nil) && [NnnbCommons isNSDictionaryObject:dict] && [dict objectForKey:@"status"] && ([[dict objectForKey:@"status"] intValue] == 0)) {            
            [_receiptCheckArr addObject:plDataDic];
            
            [self updateReceiptArr];
        } else {
            
            [_receiptCheckArr addObject:plDataDic];
            
            [self updateReceiptArr];
        }
        
    }] resume];
}

- (void)updateReceiptArr{
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSMutableArray *receiptArr = [keyChain kcObjectForKey:@"receiptArray"];
    
    if (_receiptCheckArr.count != 0) {
        NSPredicate *successCheckPre = [NSPredicate predicateWithFormat:@"NOT (SELF IN %@)",_receiptCheckArr];
        
        [receiptArr filterUsingPredicate:successCheckPre];
        
        [keyChain kcSetObject:receiptArr forKey:@"receiptArray"];
    }
}

- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    [self removeAppStoreObserver];
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
    if(transaction.error.code != SKErrorPaymentCancelled) {
        [NnnbTips depictCenterWithText:@"失败，请重试" duration:NN_TIPS_TIME2];
    } else {
    }
    
    [self postMsgResult:@"0"];
}

-(void)postMsgResult:(NSString*)strCode
{
    [CommonData GetCommonDataInstance].bIsBuying = NO;
    
    if ([CommonData GetCommonDataInstance].sVersion == 1) {
        [[NnnbSFloatW getInstance] depictWindow];
    }else{
        [[NnnbFloatWindow getInstance] depictWindow];
    }
    
    NSDictionary *flagD = [NSDictionary dictionaryWithObject:strCode forKey:@"stateFlag"];
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_APPLE
                                                        object:nil userInfo:flagD];
}

//移除监听
- (void)removeAppStoreObserver{
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
}

@end
