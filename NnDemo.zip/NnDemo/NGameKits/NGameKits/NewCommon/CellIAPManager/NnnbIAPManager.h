//
//  NnnbIAPManager.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

@interface NnnbIAPManager : NSObject

+ (instancetype)sharedManager;

- (void)makeIAP;

- (void)checkReceipt;

@end
