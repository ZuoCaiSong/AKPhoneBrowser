//
//  NnnbUpdate.m
//  NGameKits
//
//  Created by kafi on 2018/5/25.
//

#import "NnnbUpdate.h"
#import "NnnbNotDisAlertView.h"

//选择性
#define TW_UPDATESELECT_FLAG 1

//强制
#define TW_UPDATEFORCE_FLAG  2

static NnnbUpdate *_updateManger = nil;

@interface NnnbUpdate ()
@property (nonatomic,strong) NnnbNotDisAlertView *selectAlert;
@property (nonatomic,strong) NnnbNotDisAlertView *forceAlert;
@property (nonatomic,copy) NSString *appStoreUrl;
@end

@implementation NnnbUpdate

+(NnnbUpdate *)getInstance{
    @synchronized (self) {
        if (_updateManger == nil) {
            _updateManger = [[NnnbUpdate alloc] init];
        }
    }
    
    return _updateManger;
}

- (void)updateAppWithFlag:(NSInteger)flag url:(NSString *)urlStr
{
    _appStoreUrl = urlStr;
    
    if (([urlStr isEqualToString:@""] || urlStr == NULL) && (flag == TW_UPDATESELECT_FLAG || flag == TW_UPDATEFORCE_FLAG))
    {
        NSLog(@"Url地址异常，为空");
        return;
    }
    
    if (flag == TW_UPDATESELECT_FLAG)
    {
        _selectAlert = [[NnnbNotDisAlertView alloc] initWithTitle:@"升级" message:@"检测到有新版本，要马上去尝鲜吗？" delegate:self cancelButtonTitle:@"忽略此版本" otherButtonTitles:@"立即升级", nil];
        _selectAlert.tag = 10000;
        [_selectAlert show];
    }
    else if (flag == TW_UPDATEFORCE_FLAG)
    {
        _forceAlert = [[NnnbNotDisAlertView alloc] initWithTitle:@"提示" message:@"发现需要升级的版本，不升级将导致应用不可用" delegate:self cancelButtonTitle:@"立即升级" otherButtonTitles:nil, nil];
        _forceAlert.tag = 10001;
        _forceAlert.notDisMiss = YES;
        [_forceAlert show];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 10000) {
        if (buttonIndex == 1) {
            NSURL *url = [NSURL URLWithString:_appStoreUrl];
            [[UIApplication sharedApplication] openURL:url];
            _selectAlert.notDisMiss = YES;
        } else if (buttonIndex == 0){
            _selectAlert.notDisMiss = NO;
        }
    } else if (alertView.tag == 10001){
        if (buttonIndex == 0) {
            NSURL *url = [NSURL URLWithString:_appStoreUrl];
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}
@end
