//
//  NnnbUpdate.h
//  NGameKits
//
//  Created by kafi on 2018/5/25.
//

#import <Foundation/Foundation.h>

@interface NnnbUpdate : NSObject<UIAlertViewDelegate>
+ (NnnbUpdate *)getInstance;

- (void)updateAppWithFlag:(NSInteger)flag url:(NSString *)urlStr;
@end
