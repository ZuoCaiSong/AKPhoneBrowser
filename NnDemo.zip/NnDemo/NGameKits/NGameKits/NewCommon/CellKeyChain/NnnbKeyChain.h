//
//  NnnbKeyChain.h
//  NnnbKeyChain
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>

@interface NnnbKeyChain : NSObject

+ (NnnbKeyChain *)standardKeyChain;

- (void)kcSetObject:(id)object forKey:(NSString *)key;

- (id)kcObjectForKey:(NSString *)key;

- (void)kcDeleteObject:(NSString *)key;

- (BOOL)kcBoolForKey:(NSString *)key;

//保存加密后的字符串
- (void)nnStringSetObject:(NSString *)value forKey:(NSString *)defaultName;

//获取解密后的字符串
- (id)nnPlatObjectForKey:(NSString *)defaultName;

@end
