//
//  CommonData.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonData : NSObject

@property (nonatomic, copy) NSDate *lastClickTime;
@property (nonatomic, copy) NSString *TagStr;

@property (nonatomic, assign) NSInteger iSAppleRecharge;
@property (nonatomic, assign) BOOL bIsBuying;

@property (nonatomic, strong) NSString *strExtInfo;   //保存接入方自定义的数据
@property (nonatomic, assign) NSUInteger ijin;
@property (nonatomic, assign) NSInteger defaultServerId;    //服务器id
@property (nonatomic, copy) NSString *strServerName;   //区服名称
@property (nonatomic, copy) NSString *strProductId;
@property (nonatomic, copy) NSString *strProductName;
@property (nonatomic, copy) NSString *strProductDes;
@property (nonatomic, copy) NSString *roleName;           //角色名字
@property (nonatomic, copy) NSString *roleID;           //角色id

@property (nonatomic, assign) NSInteger packageState;
@property (nonatomic, assign) NSInteger sVersion;
@property (nonatomic, assign) NSInteger sRecr;
@property (nonatomic, assign) NSInteger sCur;
@property (nonatomic, assign) NSInteger sPub;

@property (nonatomic, assign) NSInteger accState;   //记录账号是否是随机账号
@property (nonatomic, assign) BOOL randomAccReq;   //记录是否进行了判断是否随机账号的请求
@property (nonatomic, assign) BOOL bHadLogin;
@property (nonatomic, assign) NSInteger currentDirection;
@property (nonatomic, assign) BOOL autoRememberAndLogin;   //默认记住密码和自动登录
@property (nonatomic, copy) NSString *pmdStr; //跑马灯字符
@property (nonatomic, strong) NSDictionary *cusDict;

+ (CommonData*)GetCommonDataInstance;

- (NSInteger)judgeDirection;

- (void)saveExt:(NSString *)strCustomInfo jin:(NSUInteger)iJin serverID:(NSInteger)serverID serverName:(NSString *)servername roleName:(NSString *)rolename roleID:(NSString*)strRoleID productID:(NSString *)productid productName:(NSString *)productName productDes:(NSString *)ProductDes;

@end
