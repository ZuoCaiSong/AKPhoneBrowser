//
//  FileUploader.m
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "FileUploader.h"

static NSString * const BOUNDRY = @"0xKhTmLbOuNdArY";
//#define ASSERT(x) NSAssert(x, @"")

@implementation FileUploader

@synthesize tag;
@synthesize percent;
@synthesize strResponse;

- (id)initWithURL: (NSString *)aServerURL  
		 filePath: (NSString *)aFilePath
		 formData: (NSData *)aFormData
		 delegate: (id)aDelegate
			  tag: (int)aTag
 progressSelector: (SEL)aProgressSelector
	 doneSelector: (SEL)aDoneSelector	 
	errorSelector: (SEL)anErrorSelector 
   cancelSelector: (SEL)anCancelSelector
{
	if ((self = [super init])) {
		//delegate = [aDelegate retain];
		delegate = aDelegate;
		serverURL = [aServerURL retain];
		filePath = [aFilePath retain];
		tag = aTag;
		progressSelector = aProgressSelector;
		doneSelector = aDoneSelector;
		errorSelector = anErrorSelector;
		cancelSelector = anCancelSelector;
		
		dataIncoming = [[NSMutableData alloc] initWithCapacity:0];
		//strResponse = [[NSString alloc] initWithString:@""];
		
		formData=[aFormData retain];
		
		[self upload];
	}
    
	return self;
}

/****************************************************
  *  函数名:  upload
  *  功  能:  上传文件
  *  入  参: 
  *         无
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)upload
{
    //先释放之前的网络资源
	if (conn != nil)
    {
		[conn release];
		conn = nil;
	}
	
    //读取文件数据
	NSData *data = [NSData dataWithContentsOfFile:filePath];
    
	if (!data)
    {
        //没有数据
		[self uploadSucceeded:NO];
		return;
	}
    
	if ([data length] == 0)
    {
		//没有数据, 便认为上传成功.
		[self uploadSucceeded:YES];
		return;
	}
	
	// 得到本地文件名(不包含路径)
	NSRange range = [filePath rangeOfString:@"/" options:NSBackwardsSearch];
	NSInteger location = range.location;
    
	if (location < 0 || location >= [filePath length])
    {
		location = 0;
	}
    
	NSString *strFileName = [filePath substringFromIndex:location+1];
    
	// 产生URLRequest
	NSURLRequest *urlRequest = [self createRequestWithLocalFile:strFileName 
													  ServerURL:[NSURL URLWithString:serverURL]
														Boundry:BOUNDRY
														   Data:data];
	if (!urlRequest)
    {
		[self uploadSucceeded:NO];
		return;
	}
	
	//开始连接并且发送数据
	conn = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:self];
    
	if (!conn)
    {
		[self uploadSucceeded:NO];
	}
}

/****************************************************
  *  函数名:  cancelUpload
  *  功  能:  取消上传文件
  *  入  参: 
  *         无
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)cancelUpload
{
	if (conn!=nil)
    {
		[conn cancel];
		[conn release];
		conn=nil;
        
		//向上层报告
		if ([delegate respondsToSelector:cancelSelector])
        {
			[delegate performSelector:cancelSelector withObject:self];
		}
	}
}

//产生一个Http Post请求
- (NSURLRequest *)createRequestWithLocalFile:(NSString*)filePath
								   ServerURL:(NSString *)url
									 Boundry:(NSString *)boundry
                                        Data:(NSData *)data
{
    NSString *strFormatData = [[NSString alloc] initWithData:formData encoding:NSUTF8StringEncoding];
    NSString *formatUrl = [NSString stringWithFormat:@"%@%@%@", url, @"?", strFormatData];
    [strFormatData release];
    strFormatData = nil;
    
    NSURL *destUrl = [NSURL URLWithString:formatUrl];
    
	NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:destUrl];
    
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setValue:[NSString stringWithFormat:@"application/x-www-form-urlencoded"]
      forHTTPHeaderField:@"Content-Type"];
	
	//写入数据
	[urlRequest setHTTPBody:data];
	return urlRequest;
}

//上传进度回调
- (void)		   connection:(NSURLConnection *)connection 
		didSendBodyData:(NSInteger)bytesWritten 
	  totalBytesWritten:(NSInteger)totalBytesWritten 
totalBytesExpectedToWrite:(NSInteger)totalBytesExpectedToWrite
{
	percent = totalBytesWritten*1.0/totalBytesExpectedToWrite;
	
	if (progressSelector)
    {
		[delegate performSelector:progressSelector withObject:self];
	}
}

//接收到服务器响应
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	
}

//接收到服务器返回的数据
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	//接收服务器返回的数据	
	[dataIncoming appendData:data];
}

//上传完成
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	uploadDidSucceed = YES;
	//[connection release];
	
	NSString *str = [[NSString alloc] initWithBytes:[dataIncoming bytes] 
											 length:[dataIncoming length]
										   encoding:NSUTF8StringEncoding];
	self.strResponse = str;
	[str release];
	
	[self uploadSucceeded:uploadDidSucceed];
}

//上传失败
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	[self uploadSucceeded:NO];
}

//通知委托者上传结果
- (void)uploadSucceeded: (BOOL)success
{
	SEL selector = success ? doneSelector : errorSelector;
    
	if (selector)
    {
		[delegate performSelector:selector withObject:self];
	}
	
	if (conn != nil)
    {
		[conn release];
		conn = nil;
	}
}

- (void)dealloc
{
	[formData release];
	[conn release];
	[dataIncoming release];
	self.strResponse=nil;
	//[strResponse release];
	
	[serverURL release];
	serverURL = nil;
	[filePath release];
	filePath = nil;
	//[delegate release];
	delegate = nil;
	progressSelector = NULL;
	doneSelector = NULL;
	errorSelector = NULL;
	cancelSelector = NULL;
	[super dealloc];
}

@end // Uploader
