//
//  SocketMsg.m
//  MeYou
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSocketMsg.h"

//对socket消息的封装
@implementation NnnbSocketMsg

@synthesize nMid;
@synthesize dicContent;

-(id) initWithMid:(int)mid Content:(NSDictionary*)content {
	if (!(self = [super init]))
		return nil;
	
	nMid = mid;
	self.dicContent = [content retain];
	
	return self;
}

- (void)dealloc {
	[dicContent release];
	
    [super dealloc];
}

@end


