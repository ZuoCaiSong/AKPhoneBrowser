//
//  Communicator.h
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommunicatorFactory.h"
#import "NnnbSocket.h"
#import "NnnbSocketMsg.h"
#import "FileUploader.h"
#import "FileDownloader.h"
#import "NnnbHttpWorker.h"
#import "NnnbJSON.h"

/********************************Communicator***********************************/

@interface Communicator : NSObject<ICommunicator,NnnbSocketDelegate>
{
	//各种worker
	NnnbSocket *socketSession;
    
	NSMutableDictionary *dicFileUploader;
	NSMutableDictionary *dicFileDownloader;
	NSMutableDictionary *dicHttpWorker;
	NSMutableDictionary *dicSessionMsg;
	
	//标签值
	int tagFileUploader;
	int tagFileDownloader;
	int tagHttpWorker;
	int tagSessionMsg;
	
	//Kek
	NSString *strKek;
	
	//消息中心用于
	NSNotificationCenter *_notificationCenter;
}

+ (Communicator *) getInstance;

//转换SocketMsg格式为真正要传输的数据
-(NSData*) convertFromSockMsg:(NnnbSocketMsg*)msg ToData:(NSMutableData*)data;
//转换Http净荷数据为真正要上传的数据
-(void) convertFromLoad:(NSArray*)arr ToPost:(NSMutableData*)data;

//开始Session心跳
-(void) startHB1;

//Session服务器重连
-(BOOL) isSessionServerReconnect;

//文件上传监听事件
- (void) onFileUploadProgress:(FileUploader*)uploader;
- (void) onFileUploadDone:(FileUploader*)uploader;
- (void) onFileUploadError:(FileUploader*)uploader;
- (void) onFileUploadCancel:(FileUploader*)uploader;

//文件下载监听事件
- (void) onFileDownloadProgress:(FileDownloader*)downloader;
- (void) onFileDownloadDone:(FileDownloader*)downloader;
- (void) onFileDownloadError:(FileDownloader*)downloader;
- (void) onFileDownloadCancel:(FileDownloader*)downloader;

//HTTP监听事件
- (void) onHttpPostDone:(NnnbHttpWorker*)worker;
- (void) onHttpPostError:(NnnbHttpWorker*)worker;
- (void) onHttpPostCancel:(NnnbHttpWorker*)worker;

/*******************************
 * 说明：派发通知
 * 参数：name					通知名称
 *		userInfo			用户自定义数据
 *******************************/
- (void) postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo;

/*******************************
 * 说明：添加通知目标，用于监听通知的派发。
 * 参数：target				监听通知的对象
 *		selector			通知到达后的处理方法
 *		notificationName	通知名称
 *******************************/
- (void) addNotificationTarget:(id)target selector:(SEL)selector notificationName:(NSString *)notificationName;

/********************************
 * 说明：移除通知监听目标。
 * 参数：target				监听通知的对象
 *		notificationName	通知名称
 ********************************/
- (void) removeNotificationTarget:(id)target notificationName:(NSString*)notificationName;

- (void) removeAllNotification:(id)target;

@end

/*******************************************************************************/
