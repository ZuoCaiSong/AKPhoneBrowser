//
//  Communicator.m
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "Communicator.h"
#import "NotificationDefinition.h"

static Communicator *sharedCommunicator = nil;

@implementation Communicator

+ (Communicator *) getInstance {
    @synchronized(self)
	{
        if (sharedCommunicator == nil) {
            sharedCommunicator = [[self alloc] init];
        }
    }
    return sharedCommunicator;
}

//转换SocketMsg格式为真正要传输的数据
-(NSData*) convertFromSockMsg:(NnnbSocketMsg*)msg ToData:(NSMutableData*)data {
	int iId = NSSwapInt(msg.nMid);
	NSData *dataMsgId = [NSData dataWithBytes:&iId  length:4];
	
	NSString *jsonBody = [NnnbJSON TwRepresentation:msg.dicContent];
	NSData *dataBody = [jsonBody dataUsingEncoding:NSUTF8StringEncoding];
	
	int lenBody = NSSwapInt([dataBody length]);
	NSData *dataLen = [NSData dataWithBytes:&lenBody length:4];
	
	[data appendData:dataMsgId];
	[data appendData:dataLen];
	[data appendData:dataBody];
	
	return data;	
}

//转换Http净荷数据为真正要上传的数据
-(void)convertFromLoad:(NSArray*)arr ToPost:(NSMutableData*)data {
	//构造净荷字符串
    NSString* strPost = [NSString string];
    NSArray *arrNV = nil;
    NSString *strName = nil;
    NSString *strValue = nil;
    
	for(int i = 0; i < [arr count]; i++)
    {
		arrNV = [arr objectAtIndex:i];
		strName = [arrNV objectAtIndex:0];
		strValue = [arrNV objectAtIndex:1];
		strValue = (NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
																	   (CFStringRef)strValue,
																	   NULL,
																	   (CFStringRef)@"!*'();:@&=+$,/?%#[]",
																	   kCFStringEncodingUTF8);
		NSString *strNV = [NSString stringWithFormat:@"%@=%@", strName, strValue];
		CFRelease(strValue);
        strValue = nil;
		
        strPost = (i == [arr count] - 1) ? [strPost stringByAppendingFormat:@"%@", strNV] : [strPost stringByAppendingFormat:@"%@&", strNV];
	}
    
    NSLog(@"%@",strPost);
    
    if ([strKek length] > 0)
    {
        strPost = [NnnbEncrypt encryptString:strPost withKey:strKek];
    }
    
	[data appendData:[strPost dataUsingEncoding:NSUTF8StringEncoding]];
}

-(void)startHB1
{
	//构造Session服务器心跳协议包
	int iMsgId = 81013;	
	NSMutableDictionary *dcMsgBody = [NSMutableDictionary dictionaryWithCapacity:0];	
	NnnbSocketMsg *msg = [[[NnnbSocketMsg alloc] initWithMid:iMsgId Content:dcMsgBody] autorelease];
	
	//转换SocketMsg数据为真正要上传的数据
	NSMutableData *data = [NSMutableData dataWithCapacity:0];
	[self convertFromSockMsg:msg ToData:data];
	
	//启动Socket心跳机制
	[socketSession startHB:data];
}

//Session服务器重连
-(BOOL) isSessionServerReconnect{
	return socketSession.isReconnect;
}

-(id)init
{
	if (!(self = [super init]))
		return NULL;
	
	_notificationCenter = [[NSNotificationCenter alloc] init];
	
	//创建文件上传器集合
	dicFileUploader = [[NSMutableDictionary alloc] initWithCapacity:0];
	
	//创建文件下载器集合
	dicFileDownloader = [[NSMutableDictionary alloc] initWithCapacity:0];
	
	//创建httpworker集合
	dicHttpWorker = [[NSMutableDictionary alloc] initWithCapacity:0];
	
	//创建Session消息标签集合
	dicSessionMsg = [[NSMutableDictionary alloc] initWithCapacity:0];
		
	//kek
	strKek = [[NSString alloc] initWithString:@""];
	
	return self;
}

- (void)dealloc
{
	[socketSession release];
	[dicFileDownloader release];
	[dicFileUploader release];
	[dicHttpWorker release];
	[dicSessionMsg release];
	[strKek release];
	
	[_notificationCenter release];
    [super dealloc];
}

- (void)release{
	[super release];
}

#pragma mark -
#pragma mark ICommunicator
-(void) genKek:(NSString*)key
{
    if (key != nil)
    {
        [key retain];
        [strKek release];
        strKek = key;
    }
	
}

- (NSString*) Kek
{
	return strKek;
}

//连接Session服务器
- (void)connectSessionServer:(NSString*)server Port:(NSInteger)port
{
	if (socketSession==nil)
    {
		socketSession = [[NnnbSocket alloc] initWithDelegate:self
													   Tag:1
										   ConnectSelector:@selector(onSocketConnected:)
										 ReconnectSelector:@selector(onSocketReconnected:)
											  DataSelector:@selector(onSocketDataReceived:)
											  SendSelector:@selector(onSocketDataSent:tag:)
										DisconnectSelector:@selector(onSocketDisconnected:)
											 ErrorSelector:@selector(onSocketError:error:)];
	}
    
	[socketSession connectServer:server Port:port];
}

//发送数据到Session服务器
- (int)sendSessionMsg:(NnnbSocketMsg*)msg
{
	//转换SocketMsg数据为真正要上传的数据
	NSMutableData *data = [[NSMutableData alloc] initWithCapacity:0];
	[self convertFromSockMsg:msg ToData:data];
	
	//写入Socket消息字典中，等待发送完毕后从字典中移除。
	tagSessionMsg++;
	[dicSessionMsg setObject:msg forKey:[NSNumber numberWithInt:tagSessionMsg]];
	
	//通过socket发送数据
	[socketSession sendData:data tag:tagSessionMsg];
	[data release];
	
	return tagSessionMsg;
}

//断开Session服务器
- (void)disconnectSessionServer
{
	//先断开socketSession
	[socketSession disconnectServer];	
}

//上传文件至文件服务器(HTTP协议)
-(int)uploadFile:(NSString*)filePath formData:(NSArray *)formData ToServer:(NSString*)url
{
	//生成文件上传器并添加至文件上传器集合中
	tagFileUploader++;
    
	//转换净荷数据为真正要上传的数据
	NSMutableData *data = [[NSMutableData alloc] initWithCapacity:0];
	[self convertFromLoad:formData ToPost:data];
    
	FileUploader *loader = [[FileUploader alloc] initWithURL:url
													filePath:filePath
													formData:data
													delegate:self
														 tag:tagFileUploader
											progressSelector:@selector(onFileUploadProgress:)
												doneSelector:@selector(onFileUploadDone:)
											   errorSelector:@selector(onFileUploadError:)
											  cancelSelector:@selector(onFileUploadCancel:)];
	[dicFileUploader setObject:loader forKey:[NSNumber numberWithInt:tagFileUploader]];
	[loader release];
    [data release];
    data = nil;
	
	return tagFileUploader;
}

- (void)cancelUploadFile:(NSInteger)tag{
	NSArray *allKeys=[dicFileUploader allKeys];
	for (int i=0; i<[allKeys count]; i++) {
		FileUploader *item=[dicFileUploader objectForKey:[allKeys objectAtIndex:i]];
		if (item.tag==tag) {
			//取消请求
			[item cancelUpload];
			break;
		}
	}
}

//下载文件至文件服务器(HTTP协议)
- (int)downloadFile:(NSString*)file FromServer:(NSString*)url {
	//生成文件上传器并添加至文件上传器集合中
	tagFileDownloader++;
	FileDownloader *downloader = [[FileDownloader alloc] initWithURL:url
															filePath:file
															delegate:self
																 tag:tagFileDownloader
													progressSelector:@selector(onFileDownloadProgress:)
														doneSelector:@selector(onFileDownloadDone:)
													   errorSelector:@selector(onFileDownloadError:)
													  cancelSelector:@selector(onFileDownloadCancel:)];
	[dicFileDownloader setObject:downloader forKey:[NSNumber numberWithInt:tagFileDownloader]];
	[downloader release];
	
	return tagFileDownloader;
}

- (void)cancelDownloadFile:(NSInteger)tag{
	NSArray *allKeys=[dicFileDownloader allKeys];
	for (int i=0; i<[allKeys count]; i++) {
		FileDownloader *item=[dicFileDownloader objectForKey:[allKeys objectAtIndex:i]];
		if (item.tag==tag) {
			//取消请求
			[item cancelDownload];
			break;
		}
	}
}

- (int)postData:(NSArray*)arr ToServer:(NSString*)url {
	//生成HttpWorker并添加至HttpWorker集合中
	tagHttpWorker++;
		
	//转换净荷数据为真正要上传的数据
	NSMutableData *data = [[NSMutableData alloc] initWithCapacity:0];
	[self convertFromLoad:arr ToPost:data];
    NSLog(@"postData:%@", [arr description]);
	
	NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:url
												 request:data
												delegate:self
													 tag:tagHttpWorker
											doneSelector:@selector(onHttpPostDone:)
										   errorSelector:@selector(onHttpPostError:)
										  cancelSelector:@selector(onHttpPostCancel:)];
	[dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
	[worker release];
	[data release];
	
	return tagHttpWorker;
	
}

- (int)requestServerByGetMethod2:(NSArray *)arr ToServer:(NSString *)url
{
    tagHttpWorker++;
    
    
    NSString* strPost = [NSString string];
    NSArray *arrNV = nil;
    NSString *strName = nil;
    NSString *strValue = nil;
    for(int i = 0; i < [arr count]; i++)
    {
		arrNV = [arr objectAtIndex:i];
		strName = [arrNV objectAtIndex:0];
		strValue = (NSString *)[arrNV objectAtIndex:1];
		strValue = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                                         (CFStringRef)strValue,
                                                                                         NULL,
                                                                                         (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                         kCFStringEncodingUTF8));
        
        
		NSString *strNV = [NSString stringWithFormat:@"%@=%@", strName, strValue];
        
        strValue = nil;
        
        strPost = (i == [arr count] - 1) ? [strPost stringByAppendingFormat:@"%@", strNV] : [strPost stringByAppendingFormat:@"%@&", strNV];
	}
    
    NSString* strUrl = url;
    strUrl = [strUrl stringByAppendingString:@"?"];
    strUrl = [strUrl stringByAppendingString:strPost];
    
    NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:strUrl
                                                                  delegate:self
                                                                       tag:tagHttpWorker
                                                              doneSelector:@selector(onHttpPostDone:)
                                                             errorSelector:@selector(onHttpPostError:)
                                                            cancelSelector:@selector(onHttpPostCancel:)];
    
    [dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
    
    return tagHttpWorker;
}

- (int)postChongData:(NSData*)postData  ToServer:(NSString*)url
{
    //生成HttpWorker并添加至HttpWorker集合中
	tagHttpWorker++;
    
	
	NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:url
												 request:postData
												delegate:self
													 tag:tagHttpWorker
											doneSelector:@selector(onHttpPostChongDataDone:)
										   errorSelector:@selector(onHttpPostError:)
										  cancelSelector:@selector(onHttpPostCancel:)];
    
	[dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
	[worker release];
	
	return tagHttpWorker;
}

- (int)requestServerByGetMethod:(NSString *)url
{
	//生成HttpWorker并添加至HttpWorker集合中
	tagHttpWorker++;
	
	
	NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:url
												delegate:self
													 tag:tagHttpWorker
											doneSelector:@selector(onHttpPostDone:)
										   errorSelector:@selector(onHttpPostError:)
										  cancelSelector:@selector(onHttpPostCancel:)];
	[dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
	[worker release];
	
	return tagHttpWorker;
}

- (int)sendHttpRequestWithUrl:(NSString *)url
						 data:(NSDictionary *)data
					   method:(HttpMethod)method
{
	tagHttpWorker ++;
	
	NSMutableString *tmpString = [NSMutableString string];
	for (int i = 0; i < [[data allKeys] count]; i++)
	{
		NSString *nameString = [[data allKeys] objectAtIndex:i];
		NSString *valueString = [data objectForKey:nameString];
		if (valueString == nil)
		{
			valueString = @"";
		}
		valueString = (NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
																		  (CFStringRef)valueString,
																		  NULL,
																		  (CFStringRef)@"!*'();:@&=+$,/?%#[]",
																		  kCFStringEncodingUTF8);	
		NSString *keyValueString = [NSString stringWithFormat:
									@"%@=%@",
									nameString,
									valueString];
		CFRelease(valueString);
		
		[tmpString appendFormat:@"%@&",keyValueString];
	}
	NSString *queryString = [tmpString substringToIndex:[tmpString length] - 1];
	
	if (method == HttpMethodPost)
	{
		NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:url
													 request:[queryString dataUsingEncoding:NSUTF8StringEncoding]
													delegate:self
														 tag:tagHttpWorker
												doneSelector:@selector(onHttpPostDone:)
											   errorSelector:@selector(onHttpPostError:)
											  cancelSelector:@selector(onHttpPostCancel:)];
		[dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
		[worker release];
	}
	else
	{
		NnnbHttpWorker *worker = [[NnnbHttpWorker alloc] initWithURL:[NSString stringWithFormat:@"%@?%@",url,queryString]
													delegate:self
														 tag:tagHttpWorker
												doneSelector:@selector(onHttpPostDone:)
											   errorSelector:@selector(onHttpPostError:)
											  cancelSelector:@selector(onHttpPostCancel:)];
		[dicHttpWorker setObject:worker forKey:[NSNumber numberWithInt:tagHttpWorker]];
		[worker release];
	}
	
	return tagHttpWorker;
}

- (void)cancelHttpRequest:(NSInteger)tag{
	NSArray *allKeys=[dicHttpWorker allKeys];
	for (int i=0; i<[allKeys count]; i++) {
		NnnbHttpWorker *item=[dicHttpWorker objectForKey:[allKeys objectAtIndex:i]];
		if (item.tag==tag) {
			//取消请求
			[item cancelRequest];
			break;
		}
	}
}

/*****************************************************************/
#pragma mark -
#pragma mark NnnbSocketDelegate

//连接Socket服务器成功
-(void) onSocketConnected:(NnnbSocket*)socket {
	if (socket.tagger == 1) 
	{ 
		//Session服务器
		[self startHB1];
        
		//派发Session服务器连接消息
		[self postNotification:NOTIF_SESSION_SERVER_CONNECT userInfo:nil];
	} 
}

- (void)onSocketReconnected:(NnnbSocket *)socket
{
	switch (socket.tagger)
	{
		case 1:
			[self startHB1];
			//派发Session服务器重新连接消息
			[self postNotification:NOTIF_SESSION_SERVER_RECONNECT userInfo:nil];
			break;
	}
}

//收到Socket服务器推送过来的数据
-(void) onSocketDataReceived:(NnnbSocket*)socket
{
	int tag = socket.tagger;
	int iMid = socket.nMsgId;
	NSString *strContent = socket.strMsgContent;
	NSDictionary *dic = [NnnbJSON TwValue:strContent];//解析服务器返回的JSON串
	NnnbSocketMsg *msg = [[[NnnbSocketMsg alloc] initWithMid:iMid Content:dic] autorelease];
	
	if (tag == 1) 
	{
		//Session服务器
		
		//派发消息
		[self postNotification:NOTIF_SESSION_SERVER_DATA_RECEIVE 
					  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
								msg,
								@"msg",
								nil]];
		
	}
}

-(void) onSocketDisconnected:(NnnbSocket *)socket {
	if (socket.tagger == 1) 
	{
		//派发Session服务器断开通知
		[self postNotification:NOTIF_SESSION_SERVER_DISCONNECT userInfo:nil];
	} 
}

-(void)onSocketDataSent:(NnnbSocket *)socket tag:(NSNumber *)tag{
	if (socket.tagger == 1) 
	{
		[dicSessionMsg removeObjectForKey:tag];

		//派发消息
		[self postNotification:NOTIF_SESSION_SERVER_DATA_SENT 
					  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
								tag,
								@"tag",
								nil]];
	}
}

-(void) onSocketError:(NnnbSocket *)socket error:(NSError *)error {
	NnnbSocketErrorType type;
	switch ([error code]) {
		case AsyncSocketWriteTimeoutError:
			type=NnnbSocketSendDataErrorType;
			break;
		case AsyncSocketCanceledError:
		case AsyncSocketIsConnectedError:
			type=NnnbSocketConnectErrorType;
			break;
		case AsyncSocketReadTimeoutError:
		case AsyncSocketReadMaxedOutError:
			type=NnnbSocketReceiveDataErrorType;
			break;
		default:
			type=NnnbSocketOtherErrorType;
			break;
	}
	
	if (socket.tagger == 1) 
	{
		//清除发送Session消息记录
		[dicSessionMsg removeAllObjects];
		
		//派发消息
		[self postNotification:NOTIF_SESSION_SERVER_SOCKET_ERROR 
					  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
								[NSNumber numberWithInt:type],
								@"type",
								error,
								@"error",
								nil]];
	}
}


/**********************************************************************/
#pragma mark -
#pragma mark UPLOAD

- (void) onFileUploadProgress:(FileUploader*)uploader {
	//向委托者报告上传进度
	//派发消息
	[self postNotification:NOTIF_UPLOAD_PROGRESS 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							[NSNumber numberWithFloat:uploader.percent],
							@"percent",
							nil]];
}
- (void) onFileUploadDone:(FileUploader*)uploader {
	NSDictionary *dicResponse = [NnnbJSON TwValue:uploader.strResponse];//解析服务器返回的JSON串
	
	//向委托者报告上传完成事件
	//派发消息
	[self postNotification:NOTIF_UPLOAD_DONE 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							dicResponse,
							@"response",
							nil]];
    
	NSString* strResponse = nil;
    if ([strKek length] > 0)
    {
        strResponse = [NnnbEncrypt decryptString:uploader.strResponse withKey:strKek];
    }
    else
    {
        strResponse = uploader.strResponse;
    }
    
	dicResponse = [NnnbJSON TwValue:strResponse];//解析服务器返回的JSON串
	
	//派发消息
	[self postNotification:NOTIF_HTTP_POST_DONE
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							dicResponse,
							@"response",
							nil]];
    
	//从上传器集合中移除该下载器
	int tag = uploader.tag;
	[dicFileUploader removeObjectForKey:[NSNumber numberWithInt:tag]];
	
	
}
- (void) onFileUploadError:(FileUploader*)uploader {
	//向委托者报告上传出错事件
	//派发消息
	[self postNotification:NOTIF_UPLOAD_ERROR 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							nil]];
	[self postNotification:NOTIF_HTTP_POST_ERROR
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							nil]];
    
	//从上传器集合中移除该下载器
	int tag = uploader.tag;
	[dicFileUploader removeObjectForKey:[NSNumber numberWithInt:tag]];	
}
- (void) onFileUploadCancel:(FileUploader*)uploader {
	//向委托者报告上传出错事件
	//派发消息
	[self postNotification:NOTIF_UPLOAD_CANCEL 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:uploader.tag],
							@"tag",
							nil]];
	
	//从上传器集合中移除该下载器
	int tag = uploader.tag;
	[dicFileUploader removeObjectForKey:[NSNumber numberWithInt:tag]];
}

/**********************************************************************/
#pragma mark -
#pragma mark DOWNLOAD

- (void) onFileDownloadProgress:(FileDownloader*)downloader {
	//向委托者报告下载进度
	//派发消息
	[self postNotification:NOTIF_DOWNLOAD_PROGRESS 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:downloader.tag],
							@"tag",
							[NSNumber numberWithFloat:downloader.percent],
							@"percent",
							nil]];
}
- (void) onFileDownloadDone:(FileDownloader*)downloader {
	//向委托者报告下载完成事件
	//派发消息
	[self postNotification:NOTIF_DOWNLOAD_DONE 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:downloader.tag],
							@"tag",
							nil]];
	
	//从下载器集合中移除该下载器
	int tag = downloader.tag;
	[dicFileDownloader removeObjectForKey:[NSNumber numberWithInt:tag]];	
}
- (void) onFileDownloadError:(FileDownloader*)downloader {
	//向委托者报告下载出错事件
	//派发消息
	[self postNotification:NOTIF_DOWNLOAD_ERROR 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:downloader.tag],
							@"tag",
							nil]];
	
	//从下载器集合中移除该下载器
	int tag = downloader.tag;
	[dicFileDownloader removeObjectForKey:[NSNumber numberWithInt:tag]];
}
- (void) onFileDownloadCancel:(FileDownloader*)downloader {
	//向委托者报告下载出错事件
	//派发消息
	[self postNotification:NOTIF_DOWNLOAD_CANCEL 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:downloader.tag],
							@"tag",
							nil]];
	
	//从下载器集合中移除该下载器
	int tag = downloader.tag;
	[dicFileDownloader removeObjectForKey:[NSNumber numberWithInt:tag]];
}

/**********************************************************************/
#pragma mark -
#pragma mark HTTP

- (void) onHttpPostChongDataDone:(NnnbHttpWorker*)worker
{
    int tag = worker.tag;
	
	//过滤处理
	//向委托者报告HttpWorker完成事件
	//从HttpWorker集合中移除该下载器
	[dicHttpWorker removeObjectForKey:[NSNumber numberWithInt:tag]];
	
	//派发消息
	[self postNotification:NOTIF_HTTP_POST_DONE
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:tag],
							@"tag",
							worker.strResponse,
							@"response",
							nil]];
}

- (void) onHttpPostDone:(NnnbHttpWorker*)worker
{
	int tag = worker.tag;
    NSString* strResponse = nil;
    if ([strKek length] > 0)
    {
        strResponse = [NnnbEncrypt decryptString:worker.strResponse withKey:strKek];
    }
    else
    {
        strResponse = worker.strResponse;
    }
    
    
    
	NSDictionary *dicResponse = [NnnbJSON TwValue:strResponse];//解析服务器返回的JSON串
	
    //****************处理非JSON格式数据
    
    if (nil == dicResponse) {
        [dicHttpWorker removeObjectForKey:[NSNumber numberWithInt:tag]];
        
        //派发消息
        [self postNotification:NOTIF_HTTP_POST_DONE
                      userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                                [NSNumber numberWithInt:tag],
                                @"tag",
                                strResponse,
                                @"response",
                                nil]];
    }
    
    //*********************************
    
    else
    {
        //过滤处理
        //向委托者报告HttpWorker完成事件
        //从HttpWorker集合中移除该下载器
        [dicHttpWorker removeObjectForKey:[NSNumber numberWithInt:tag]];
        
        //派发消息
        [self postNotification:NOTIF_HTTP_POST_DONE
                      userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                                [NSNumber numberWithInt:tag],
                                @"tag",
                                dicResponse,
                                @"response",
                                nil]];
    }
	
}

- (void) onHttpPostError:(NnnbHttpWorker*)worker {
	//向委托者报告HttpWorker出错事件
	//从HttpWorker集合中移除该下载器
	int tag = worker.tag;
	[dicHttpWorker removeObjectForKey:[NSNumber numberWithInt:tag]];
	
	//派发消息
	[self postNotification:NOTIF_HTTP_POST_ERROR 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:tag],
							@"tag",
							nil]];
}
-(void) onHttpPostCancel:(NnnbHttpWorker*)worker {
	//向委托报告HttpWorker取消事件
	//从HttpWorker集合中移除该下载器
	int tag = worker.tag;
	[dicHttpWorker removeObjectForKey:[NSNumber numberWithInt:tag]];
	
	//派发消息
	[self postNotification:NOTIF_HTTP_POST_CANCEL 
				  userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
							[NSNumber numberWithInt:tag],
							@"tag",
							nil]];
}

#pragma mark -
#pragma mark Notification

- (void) postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo{
	[_notificationCenter postNotificationName:name object:self userInfo:userInfo];
}

- (void) addNotificationTarget:(id)target selector:(SEL)selector notificationName:(NSString *)notificationName{
	[_notificationCenter addObserver:target selector:selector name:notificationName object:self];
}

- (void) removeNotificationTarget:(id)target notificationName:(NSString*)notificationName{
	[_notificationCenter removeObserver:target name:notificationName object:self];
}

- (void) removeAllNotification:(id)target
{
    [_notificationCenter removeObserver:target];
}

@end
