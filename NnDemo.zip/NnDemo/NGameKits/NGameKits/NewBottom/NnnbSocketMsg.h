//
//  SocketMsgCwSDK.h
//  MeYou
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NnnbSocketMsg : NSObject {
	int nMid;                  //功能号
	NSDictionary *dicContent;  //内容主体
}

@property(nonatomic, assign) int nMid;        
@property(nonatomic, assign) NSDictionary *dicContent;

-(id) initWithMid:(int)mid Content:(NSDictionary*)content;

@end

