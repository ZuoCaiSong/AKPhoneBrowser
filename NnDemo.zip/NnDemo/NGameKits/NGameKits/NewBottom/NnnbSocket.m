//
//  NnnbSocket.m
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbSocket.h"
#import "NSData+NnnbGZip.h"

#define NnnbSocketErrorDomain @"NnnbSocketErrorDomain"

/*********************************************************************/

@implementation NnnbSocket

@synthesize tagger;
@synthesize nMsgId;
@synthesize strMsgContent;
@synthesize isReconnect;


- (id) initWithDelegate:(id)dele
                    Tag:(int)ta
        ConnectSelector:(SEL)onServerConnected
      ReconnectSelector:(SEL)onServerReconnected
           DataSelector:(SEL)onDataReceived
           SendSelector:(SEL)onDataSent
     DisconnectSelector:(SEL)onServerDisconnected
          ErrorSelector:(SEL)onServerError
{
    if (self = [super init]) {
        //delegate = [dele retain];
        delegate = dele;
        tagger = ta;
        connectedSelector = onServerConnected;
        _reconnectedSelector = onServerReconnected;
        sendSelector = onDataReceived;
        disconnectedSelector = onServerDisconnected;
        errorSelector = onServerError;
        dataDidSendSelector = onDataSent;
        
        asynSocket = [[AsyncSocketNnnbSDK alloc] initWithDelegate:self];
        
        strServer=nil;
        iPort = 0;
        timer1 = NULL;
        timer2 = NULL;
        counterRC = 0;
        counterHB = 0;
        iStatus = 0;
        dataHB = [[NSMutableData alloc] initWithCapacity:0];
        
        isReconnect=NO;
        
    }
    return self;
}

- (void)dealloc {
    [dataHB release];
    [strServer release];
    [asynSocket release];
    [strMsgContent release];
    [super dealloc];
}

-(void) startHB:(NSData*)data {
    //保存心跳协议包
    [dataHB release];
    dataHB = [data retain];
    
    //启动心跳定时器
    if (timer1) {
        [timer1 invalidate];
        timer1 = NULL;
    }
    counterHB = 0;
    timer1 = [NSTimer scheduledTimerWithTimeInterval:15
                                              target:self
                                            selector:@selector(onTimer1)
                                            userInfo:nil
                                             repeats:YES];
}

- (void) onTimer1 {
    counterHB++;
    
    //发送服务器心跳协议包
    [self sendData:dataHB tag:0];
    
    if (counterHB > 3 || iStatus == 0) {  //已断线
        [self reconnectServer];
        
    }
}

-(void) connectServer:(NSString*)server Port:(NSInteger)port {
    [strServer release];
    strServer = [server retain];
    iPort = port;
    
    if ([asynSocket isConnected]) {
        hasError=YES;
        asynSocket.delegate=nil;
        [asynSocket disconnect];
        [asynSocket release];
        asynSocket = [[AsyncSocketNnnbSDK alloc] initWithDelegate:self];
    }
    
    @try {
        NSError *err = nil;
        if ([asynSocket connectToHost:strServer onPort:iPort error:&err]) {
            iStatus = 1;  //正在连接
        }
    }
    @catch (NSException * e) {
        //派发委托
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketError:error:)]) {
            [delegate onSocketError:self error:[NSError errorWithDomain:AsyncSocketErrorDomainNnpl code:AsyncSocketIsConnectedError userInfo:[e userInfo]]];
        }
    }
    @finally {
    }
}

-(void) reconnectServer {
    if (iStatus == 1) {  //正在连接
        return;
    }
    if ([asynSocket isConnected]) {
        hasError=YES;
        asynSocket.delegate=nil;
        [asynSocket disconnect];
        [asynSocket release];
        asynSocket = [[AsyncSocketNnnbSDK alloc] initWithDelegate:self];
    }
    
    //重连
    isReconnect=YES;
    
    @try {
        NSError *err = nil;
        if ([asynSocket connectToHost:strServer onPort:iPort error:&err]) {
            iStatus = 1;  //正在连接
        }
    }
    @catch (NSException * e) {
        //派发委托
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketError:error:)]) {
            [delegate onSocketError:self error:[NSError errorWithDomain:AsyncSocketErrorDomainNnpl code:AsyncSocketIsConnectedError userInfo:[e userInfo]]];
        }
    }
    @finally {
    }
    
    counterRC++; //重连次数加1
}

-(void) sendData:(NSData*)data tag:(NSInteger)tag
{
    if ([asynSocket isConnected])
    {
        //发送数据至服务器
        [asynSocket writeData:data withTimeout:-1 tag:tag];
    }
    else
    {
        //报告尚未连接服务器
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)]
            && [delegate respondsToSelector:@selector(onSocketError:error:)])
        {
            [delegate onSocketError:self
                              error:[NSError errorWithDomain:AsyncSocketErrorDomainNnpl
                                                        code:NnnbSocketErrorNotConnected
                                                    userInfo:nil]];
        }
    }
}

-(void) disconnectServer {
    //主动断开连接
    if ([asynSocket isConnected]) {
        [asynSocket disconnect];
        asynSocket.delegate=nil;
        [asynSocket release];
        asynSocket = [[AsyncSocketNnnbSDK alloc] initWithDelegate:self];
    }
    
    iStatus = 0; //已断开
    isReconnect=NO;
    
    if (timer1) {
        [timer1 invalidate];
        timer1 = NULL;
    }
    
    if (timer2) {
        [timer2 invalidate];
        timer2 = NULL;
    }
}

- (BOOL)onSocketWillConnect:(AsyncSocketNnnbSDK *)sock {
    return YES;
}

- (void)onSocket:(AsyncSocketNnnbSDK *)sock didConnectToHost:(NSString *)host port:(UInt16)port {
    iStatus = 2;   //当前状态为已连接
    counterRC = 0; //重连计数器清0
    
    if (isReconnect)
    {
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] &&
            [delegate respondsToSelector:@selector(onSocketReconnected:)])
        {
            [delegate onSocketReconnected:self];
        }
    }
    else
    {
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] &&
            [delegate respondsToSelector:@selector(onSocketConnected:)])
        {
            [delegate onSocketConnected:self];
        }
    }
    
    //准备接收8个字节(MessageID 和 ContentLength)
    [asynSocket readDataToLength:9 withTimeout:-1 tag:1];
}

- (void)onSocket:(AsyncSocketNnnbSDK *)sock didReadData:(NSData *)data withTag:(long)tag {
    counterHB = 0; //心跳计数器清0(只要服务器有响应，说明连接还存活着)
    if (tag==1) {
        //解析data中的9个字节(MessageID 和 ContentLength 和 压缩)
        int xxxx;
        [data getBytes:&xxxx length:4];
        nMsgId = NSSwapBigIntToHost(xxxx);  //网络字节序转换为主机字节序
        [data getBytes:&xxxx range:NSMakeRange(4, 4)];
        int nBodyLen = NSSwapBigIntToHost(xxxx);  //网络字节序转换为主机字节序
        
        //解析data中的压缩数据
        Byte compressFlag;
        [data getBytes:&compressFlag range:NSMakeRange(8, 1)];
        if (compressFlag==0) {
            isCompressData=YES;
        }else {
            isCompressData=NO;
        }
        
        if (nBodyLen-1 > 0) {//消息还未读完
            
            //再读取nBodyLen个字节
            [asynSocket readDataToLength:nBodyLen-1 withTimeout:-1 tag:2];
        } else {//消息已读完
            //构造消息体
            NSString *msg = [[NSString alloc] initWithString:@"{}"];
            self.strMsgContent = msg;
            [msg release];
            //向上层报告
            if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketDataReceived:)]) {
                [delegate onSocketDataReceived:self];
            }
            //准备下次接收9个字节(MessageID 和 ContentLength 和 压缩)
            [asynSocket readDataToLength:9 withTimeout:-1 tag:1];
        }
        
    }
    else if(tag==2) {
        //解压缩数据
        NSString *msg;
        if (isCompressData) {
            NSData *uncompressData=[NSData TwDataUncompressGZipData:data];
            msg = [[NSString alloc] initWithData:uncompressData encoding:NSUTF8StringEncoding];
        }else {
            msg = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        }
        
        //构造消息体
        self.strMsgContent = msg;
        [msg release];
        
        //向上层报告
        if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketDataReceived:)]) {
            [delegate onSocketDataReceived:self];
        }	
        //准备下次接收9个字节(MessageID 和 ContentLength 和 压缩)
        [asynSocket readDataToLength:9 withTimeout:-1 tag:1];
        
        
    }	
}


- (void)onSocket:(AsyncSocketNnnbSDK *)sock didWriteDataWithTag:(long)tag {
    if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketDataSent:tag:)]) {
        [delegate onSocketDataSent:self tag:[NSNumber numberWithInt:tag]];
    }
}

- (void)onSocket:(AsyncSocketNnnbSDK *)sock didReadPartialDataOfLength:(CFIndex)partialLength tag:(long)tag {
    
}

- (void)onSocket:(AsyncSocketNnnbSDK *)sock willDisconnectWithError:(NSError *)err {
    hasError=YES;
    if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketError:error:)]) {
        [delegate onSocketError:self error:err];
    }
}

- (void)onSocketDidDisconnect:(AsyncSocketNnnbSDK *)sock {
    if (iStatus == 0) {
        return;
    }
    
    iStatus = 0; //已断开(未连接)
    
    //报告状态
    if ([delegate conformsToProtocol:@protocol(NnnbSocketDelegate)] && [delegate respondsToSelector:@selector(onSocketDisconnected:)]) {
        [delegate onSocketDisconnected:self];
    }
    
    if (hasError && counterRC == 0) {
        /**
         异常并且首次断开则立即进行连接
         **/
        hasError=NO;
        [self reconnectServer];
    }
}

@end
