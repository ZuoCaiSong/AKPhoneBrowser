/*
 *  NotificationDefinition.h
 *  U6Comm
 *
 *  Created by hower on 8/8/11.
 *  Copyright 2015 __MyCompanyName__. All rights reserved.
 *
 */

//#pragma mark -
//#pragma mark SESSION通知
//
//Session服务器连接通知
#define NOTIF_SESSION_SERVER_CONNECT @"sessionServerConnect"

/**
	Session服务器重新连接通知
 */
#define NOTIF_SESSION_SERVER_RECONNECT @"sessionServerReconnect"


//Session服务器断开通知
#define NOTIF_SESSION_SERVER_DISCONNECT @"sessionServerDisconnect"

//Session服务器Socket异常
#define NOTIF_SESSION_SERVER_SOCKET_ERROR @"sessionServerSocketError"

//Session服务器数据接收
#define NOTIF_SESSION_SERVER_DATA_RECEIVE @"sessionServerDataReceive"

//Session服务器数据发送
#define NOTIF_SESSION_SERVER_DATA_SENT @"sessionServerDataSent"


#pragma mark -
#pragma mark HTTP通知

//提交数据完成
#define NOTIF_HTTP_POST_DONE @"httpPostDone"

//提交数据失败
#define NOTIF_HTTP_POST_ERROR @"httpPostError"

//取消提交数据
#define NOTIF_HTTP_POST_CANCEL @"httpPostCancel"

#pragma mark -
#pragma mark UPLOAD通知

//上传完成
#define NOTIF_UPLOAD_DONE @"uploadDone"

//上传失败
#define NOTIF_UPLOAD_ERROR @"uploadError"

//上传进度
#define NOTIF_UPLOAD_PROGRESS @"uploadProgress"

//上传取消
#define NOTIF_UPLOAD_CANCEL @"uploadCancel"

#pragma mark -
#pragma mark DOWNLOAD通知

//下载完成
#define NOTIF_DOWNLOAD_DONE @"downloadDone"

//下载失败
#define NOTIF_DOWNLOAD_ERROR @"downloadError"

//下载进度
#define NOTIF_DOWNLOAD_PROGRESS @"downloadProgress"

//下载取消
#define NOTIF_DOWNLOAD_CANCEL @"downloadCancel"
