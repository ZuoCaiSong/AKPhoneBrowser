//
//  CommunicatorFactory.m
//  U6Comm
//
//  zhang hower on 8/3/11.
//  Copyright 2015 __MyCompanyName__. All rights reserved.
//

#import "CommunicatorFactory.h"
#import "Communicator.h"

@implementation CommunicatorFactory

+(id<ICommunicator>)getCommunicator{
	return [Communicator getInstance];
}

@end
