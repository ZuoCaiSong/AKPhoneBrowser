//
//  Downloader.h
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileDownloader : NSObject {
	id delegate;
	NSString *serverURL;
	NSString *filePath;
	SEL progressSelector;
	SEL doneSelector;
	SEL errorSelector;
	SEL cancelSelector;
	
	NSFileHandle *fileHandler;
	NSURLConnection *conn;
	
	NSInteger nFileSumLen; //文件总长度
	NSInteger nDownloadedLen; //文件已下载的长度
	
	int tag;
	float percent;
}

@property(nonatomic, assign) int tag;
@property(nonatomic, assign) float percent;

- (id)initWithURL: (NSString *)serverURL
		 filePath: (NSString *)filePath
		 delegate: (id)delegate
			  tag: (int)tag
 progressSelector: (SEL)progressSelector
	 doneSelector: (SEL)doneSelector
	errorSelector: (SEL)errorSelector
   cancelSelector: (SEL)cancelSelector;

- (void)download;
- (void)downloadSucceeded: (BOOL)success;
//取消下载
- (void)cancelDownload;

@end
