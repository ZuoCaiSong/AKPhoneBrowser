//
//  FileUploader.h
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FileUploader : NSObject {
	id delegate;
	NSString *serverURL;
	NSString *filePath;
	SEL progressSelector;
	SEL doneSelector;
	SEL errorSelector;
	//取消上传事件委托
	SEL cancelSelector;
	BOOL uploadDidSucceed;
	
	NSMutableData *dataIncoming;
	NSURLConnection *conn;
	
	int tag;
	float percent;
	NSString *strResponse;
	//表单数据，如果不为nil，则表示需要和文件一起提交到服务器
	NSData *formData;
}

@property(nonatomic, assign) int tag;
@property(nonatomic, assign) float percent;
@property(nonatomic, retain) NSString *strResponse;

- (id)initWithURL: (NSString *)serverURL
		 filePath: (NSString *)filePath
		 formData: (NSData *)formData
		 delegate: (id)delegate
			  tag: (int)tag
 progressSelector: (SEL)progressSelector
	 doneSelector: (SEL)doneSelector
	errorSelector: (SEL)errorSelector
   cancelSelector: (SEL)cancelSelector;

- (void)upload;
- (NSURLRequest *)createRequestWithLocalFile:(NSString*)filePath
								   ServerURL:(NSString *)url
									 Boundry:(NSString *)boundry
										Data:(NSData *)data;
- (void)uploadSucceeded: (BOOL)success;

//取消上传
- (void)cancelUpload;

@end
