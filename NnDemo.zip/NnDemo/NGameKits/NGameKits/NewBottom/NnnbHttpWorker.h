//
//  HttpWorkerCwSDK.h
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NnnbHttpWorker : NSObject {
	id delegate;
	NSString *serverURL;
	NSData *dataRequest;
	SEL doneSelector;
	SEL errorSelector;
	//取消请求事件处理委托
	SEL cancelSelector;				
	
	NSMutableData *dataIncoming;
	NSURLConnection *conn;		
	int tag;
	NSString *strResponse;
	//压缩数据
	BOOL _isCompressData;
	
	NSTimer *_timeoutTimer;			//超时检测定时器
	BOOL _bIsTimeout;				//是否超时
    
    //超时重连的次数
    NSUInteger  _iReConnectCount;
    
    //get 还是 post 方式请求的
    BOOL    _bGetFlag;
}

@property(nonatomic, assign) int tag;
@property(nonatomic, retain) NSString *strResponse;

- (id)initWithURL: (NSString *)serverURL
		  request: (NSData *)dataRequest
		 delegate: (id)delegate
			  tag: (int)tag
	 doneSelector: (SEL)doneSelector
	errorSelector: (SEL)errorSelector
   cancelSelector: (SEL)cancelSelector;



/**
	初始化请求
	@param serverURL 服务器地址
	@param delegate 委托对象
	@param tag 请求
	@param doneSelector 加载完成处理器
	@param errorSelector 错误处理器
	@param cancelSelector 取消处理器
	@returns 请求对象
 */
- (id)initWithURL:(NSString *)serverURL
		 delegate:(id)delegate
			  tag:(int)tag
	 doneSelector:(SEL)doneSelector
	errorSelector:(SEL)errorSelector
   cancelSelector:(SEL)cancelSelector;



-(void) postRequest:(NSData *)data;

/**
	以GET方式请求
 */
- (void)getRequest;


//取消请求
-(void)cancelRequest;

@end
