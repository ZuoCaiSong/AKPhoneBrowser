//
//  Downloader.m
//  TestChat
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "FileDownloader.h"

@implementation FileDownloader

@synthesize tag;
@synthesize percent;

- (id)initWithURL: (NSString *)aServerURL  
		 filePath: (NSString *)aFilePath
		 delegate: (id)aDelegate
			  tag: (int)aTag
 progressSelector: (SEL)aProgressSelector
	 doneSelector: (SEL)aDoneSelector	 
	errorSelector: (SEL)anErrorSelector
   cancelSelector: (SEL)anCancelSelector
{
	if ((self = [super init])) {
		//delegate = [aDelegate retain];
		delegate = aDelegate;
		serverURL = [aServerURL retain];
		filePath = [aFilePath retain];
		tag = aTag;
		progressSelector = aProgressSelector;
		doneSelector = aDoneSelector;
		errorSelector = anErrorSelector;
		cancelSelector = anCancelSelector;
		
		[self download];
	}
	return self;
}


- (void)download
{
	if (conn!=nil) {
		[conn release];
	}
	NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:serverURL] 
											 cachePolicy:NSURLRequestReturnCacheDataElseLoad
										 timeoutInterval:60.0];
	conn=[[NSURLConnection connectionWithRequest:request delegate:self] retain];
	
	nFileSumLen = 0;
	nDownloadedLen = 0;
}

- (void)cancelDownload{
	if (!conn) {
		[conn cancel];
		//向上层报告
		if ([delegate respondsToSelector:cancelSelector]) {
			[delegate performSelector:cancelSelector withObject:self];
		}
		[conn release];
		conn=nil;
	}
}

//服务器有响应
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *) response {
	NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*)response;
	NSDictionary *fields = [httpResponse allHeaderFields];
	NSString *strLen = [fields valueForKey:@"Content-Length"];
	nFileSumLen = [strLen intValue];
	
	//创建文件
    NSFileManager *fileManager = [NSFileManager defaultManager]; 
    [fileManager removeItemAtPath:filePath error:nil]; 
	[fileManager createFileAtPath:filePath contents:nil attributes:nil];
	fileHandler = [[NSFileHandle fileHandleForUpdatingAtPath:filePath] retain];
}

//接收到服务器返回的数据
- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)incomingData {
	//写文件
	[fileHandler writeData:incomingData];
	
	//计算下载的进度
	nDownloadedLen += [incomingData length];
	percent = nDownloadedLen*1.0/nFileSumLen;
	
	if (progressSelector) {
		[delegate performSelector:progressSelector withObject:self];
	}
}

//数据加载完成
- (void) connectionDidFinishLoading:(NSURLConnection *)connection {
	[fileHandler closeFile];
	[fileHandler release];

	[self downloadSucceeded:YES];
}

//访问网络失败
- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	[self downloadSucceeded:NO];
}

//通知委托者上传结果
- (void)downloadSucceeded: (BOOL)success
{
	SEL selector = success ? doneSelector : errorSelector;
	if (selector) {
		[delegate performSelector:selector withObject:self];
	}	
	if (conn!=nil) {
		[conn release];
		conn=nil;
	}
}

- (void)dealloc
{
	[conn release];
	[serverURL release];
	serverURL = nil;
	[filePath release];
	filePath = nil;
	//[delegate release];
	delegate = nil;
	progressSelector = NULL;
	doneSelector = NULL;
	errorSelector = NULL;
	cancelSelector = NULL;
	[super dealloc];
}

@end

