
#import <Foundation/Foundation.h>


@interface NnnbJSON : NSObject {
	
}

+ (NSString*) TwRepresentation:(NSDictionary*)dic;
+ (NSDictionary*) TwValue:(NSString *)str;

@end
