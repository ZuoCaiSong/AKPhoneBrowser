//
//  EncryptCwSDK.h
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NnnbEncrypt : NSObject {

}

+ (NSString*) sha1:(NSString*)input;
+ (NSString*) md5:(NSString *)input;
+ (NSString*) sha1base64:(NSString*)input;
+ (NSString*) encryptString:(NSString*)plaintext withKey:(NSString*)key;
+ (NSString*) decryptString:(NSString*)ciphertext withKey:(NSString*)key;

@end
