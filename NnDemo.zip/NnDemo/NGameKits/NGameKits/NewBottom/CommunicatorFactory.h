/*
 *  ICommunicator.h
 *  TwComm
 *
 *  zhang hower on 8/3/11.
 *  Copyright 2015 __MyCompanyName__. All rights reserved.
 *
 */
#import <Foundation/Foundation.h>
#import "NnnbSocketMsg.h"

//socket异常类型，定义引起Socket错误的原因。
typedef enum{
	NnnbSocketConnectErrorType=1,
	NnnbSocketReceiveDataErrorType,
	NnnbSocketSendDataErrorType,
	NnnbSocketOtherErrorType
}NnnbSocketErrorType;

/**
	HTTP的请求方式
 */
typedef enum
{
	HttpMethodGet = 0, /**< GET方法 */
	HttpMethodPost = 1 /**< POST方法 */
}HttpMethod;

#pragma mark -
#pragma mark Communicator接口

@protocol ICommunicator

//Session服务器重连
-(BOOL) isSessionServerReconnect;

//通用方法
- (void)connectSessionServer:(NSString*)server Port:(NSInteger)port; //连接Session服务器
- (int)sendSessionMsg:(NnnbSocketMsg*)msg;                              //发送Session消息
- (void)disconnectSessionServer;                                     //断开Session服务器

- (int)uploadFile:(NSString*)filePath formData:(NSArray *)formData ToServer:(NSString*)url;           //上传文件

/********************************************
 * 说明：取消文件上传请求
 * 参数：tag					请求
 * 备注：此操作将会触发onFileUploadCancel委托事件
 ********************************************/
- (void)cancelUploadFile:(NSInteger)tag;

- (int)downloadFile:(NSString*)file FromServer:(NSString*)url;       //下载文件

/********************************************
 * 说明：取消文件下载请求
 * 参数：tag					请求
 * 备注：此操作将会触发onFileDownloadCancel委托事件
 ********************************************/
- (void)cancelDownloadFile:(NSInteger)tag;

- (int)postData:(NSArray*)data ToServer:(NSString*)url;              //Post数据至服务器(HTTP)

- (int)postChongData:(NSData*)postData ToServer:(NSString*)url;              //Post数据至服务器(HTTP)

/**
	通过GET方法请求服务器
	@param url 服务器路径
	@return 请求
 */
- (int)requestServerByGetMethod:(NSString *)url;


- (int)requestServerByGetMethod2:(NSArray *)arr ToServer:(NSString *)url;

/**
	发送HTTP请求
	@param url 请求地址
	@param data 请求数据
	@param method 请求方式
	@returns 请求
 */
- (int)sendHttpRequestWithUrl:(NSString *)url
						 data:(NSDictionary *)data
					   method:(HttpMethod)method;



/********************************************
 * 说明：取消Http请求
 * 参数：tag					请求
 * 备注：此操作将会触发onHttpWorkerCancel委托事件
 ********************************************/
- (void)cancelHttpRequest:(NSInteger)tag;

//密钥
- (void) genKek:(NSString*)key; //根据key产生Kek
- (NSString*) Kek; 

//释放对象
- (void)release;

/*******************************
 * 说明：添加通知目标，用于监听通知的派发。
 * 参数：target				监听通知的对象
 *		selector			通知到达后的处理方法
 *		notificationName	通知名称
 *******************************/
- (void) addNotificationTarget:(id)target selector:(SEL)selector notificationName:(NSString *)notificationName;

/********************************
 * 说明：移除通知监听目标。
 * 参数：target				监听通知的对象
 *		notificationName	通知名称
 ********************************/
- (void) removeNotificationTarget:(id)target notificationName:(NSString*)notificationName;

- (void) removeAllNotification:(id)target;

@end

//中间层对象工厂
@interface CommunicatorFactory : NSObject

//获取中间层对象
+(id<ICommunicator>)getCommunicator;

@end


