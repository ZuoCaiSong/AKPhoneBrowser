//
//  NSData+NnnbGZip.h
//  U6Comm
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSData(TwGZip)

//解压缩TwGZip文件数据
+(NSData *)TwDataUncompressGZipData:(NSData *)gzipData;

@end
