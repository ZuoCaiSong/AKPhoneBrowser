//
//  NSString+NnnbAESCrypt.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NSString+NnnbAESCrypt.h"

@implementation NSString (TwAESCrypt)

- (NSString *)TwAES128EncryptWithKey:(NSString *)key
{
	//先填充空格,以保证待加密字符串长度为16的倍数
	int nSrcLen = [self length];
	int nDstLen = 0;
	if (nSrcLen % 16 == 0) {
		nDstLen = nSrcLen;
	} else {
		nDstLen = (nSrcLen/16+1)*16;
	}	
	NSMutableString *strNewPlain = [NSMutableString stringWithString:self];
	for (int i=0; i<nDstLen-nSrcLen; i++) {
		[strNewPlain appendString:@" "];
	}
	
	//加密
	NSData *plainData = [strNewPlain dataUsingEncoding:NSUTF8StringEncoding];
	NSData *encryptedData = [plainData TwAES128EncryptWithKey:key];
	
	//输出16进制字符串
	int nLen = [encryptedData length];
	const uint8_t *bytes = (uint8_t*)[encryptedData bytes];
	NSMutableString* encryptedString = [NSMutableString stringWithCapacity:nLen * 2];	
	for(int i = 0; i < nLen; i++)
		[encryptedString appendFormat:@"%02x", bytes[i]];
	
	return encryptedString;
}

- (NSString *)TwAES128DecryptWithKey:(NSString *)key
{
	//将16进制字符串转换为16进制数
	const char *hexChars = [self UTF8String];
	NSUInteger hexLen = strlen(hexChars)/2;
	char *binChars = malloc(hexLen+1);
    *(binChars+hexLen+1) = '\0';
	const char *nextHex = hexChars;
	char *nextChar = binChars;
	for (NSUInteger i = 0; i < hexLen; i++)
	{
		sscanf(nextHex, "%2x", (unsigned int*)nextChar);
		nextHex += 2;
		nextChar++;
	}
	
	//解密
	NSData *encryptedData = [NSData dataWithBytes:binChars length:hexLen/2];
	NSData *plainData = [encryptedData TwAES128DecryptWithKey:key];
	free(binChars);
	
	//转换为字符串
	NSString *plainString = [[NSString alloc] initWithData:plainData encoding:NSUTF8StringEncoding];
	
	return [plainString autorelease];
}

- (NSString *)TwAES256EncryptWithKey:(NSString *)key
{
	//先填充空格,以保证待加密字符串长度为16的倍数
	int nSrcLen = [self length];
	int nDstLen = 0;
    
	if (nSrcLen % 16 == 0)
    {
		nDstLen = nSrcLen;
	}
    else
    {
		nDstLen = (nSrcLen / 16 + 1) * 16;
	}
    
	NSMutableString *strNewPlain = [NSMutableString stringWithString:self];
    
    //下面的这个需要去掉，否则解密出来会在有效数据后面添加很多空格
    //modify by lfy
//	for (int i = 0; i < nDstLen - nSrcLen; i++)
//    {
//		[strNewPlain appendString:@" "];
//	}
	//modify by lfy
    
	//加密
	NSData *plainData = [strNewPlain dataUsingEncoding:NSUTF8StringEncoding];
	NSData *encryptedData = [plainData TwAES256EncryptWithKey:key];
	
	//输出16进制字符串
	int nLen = [encryptedData length];
	const uint8_t *bytes = (uint8_t*)[encryptedData bytes];
	NSMutableString* encryptedString = [NSMutableString stringWithCapacity:nLen * 2];
    
	for(int i = 0; i < nLen; i++)
    {
		[encryptedString appendFormat:@"%02x", bytes[i]];
    }
	
	return encryptedString;
}

- (NSString *)TwAES256DecryptWithKey:(NSString *)key
{
	//将16进制字符串转换为16进制数
	const char *hexChars = [self UTF8String];
	NSUInteger hexLen = strlen(hexChars)/2;
	char *binChars = malloc(hexLen+1);
    *(binChars+hexLen+1) = '\0';
	const char *nextHex = hexChars;
	char *nextChar = binChars;
	for (NSUInteger i = 0; i < hexLen; i++)
	{
		sscanf(nextHex, "%2x", (unsigned int*)nextChar);
		nextHex += 2;
		nextChar++;
	}
	
	//解密
	NSData *encryptedData = [NSData dataWithBytes:binChars length:hexLen];
	NSData *plainData = [encryptedData TwAES256DecryptWithKey:key];
	free(binChars);
	
	//转换为字符串
	NSString *plainString = [[NSString alloc] initWithData:plainData encoding:NSUTF8StringEncoding];
	
	return [plainString autorelease];
}


@end
