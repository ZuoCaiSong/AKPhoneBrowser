//
//  HttpWorker.m
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbHttpWorker.h"
#import "NSData+NnnbGZip.h"

/**
	HTTP请求超时
 */
//#define REQUEST_TIMEOUT 15
#define REQUEST_TIMEOUT 20

//超时重连的最大次数
#define __TIMEOUT_RECONNECT_MAX_NUM__       2

@interface NnnbHttpWorker(Private)

/**
	取消检测超时
 */
- (void)cancelCheckTimeout;

/**
	请求超时处理器
 */
- (void)requestTimeoutHandler;


@end


@implementation NnnbHttpWorker

@synthesize tag;
@synthesize strResponse;

- (id)initWithURL:(NSString *)aServerURL
          request:(NSData *)aDataRequest
         delegate:(id)aDelegate
              tag:(int)aTag
     doneSelector:(SEL)aDoneSelector
    errorSelector:(SEL)anErrorSelector
   cancelSelector:(SEL)anCancelSelector
{
    if ((self = [super init])) {
        delegate = aDelegate;
        serverURL = [aServerURL retain];
        dataRequest = [aDataRequest retain];
        tag = aTag;
        doneSelector = aDoneSelector;
        errorSelector = anErrorSelector;
        cancelSelector = anCancelSelector;
        
        dataIncoming = [[NSMutableData alloc] initWithCapacity:0];
        
        //初始化数据
        _iReConnectCount = 0;
        [self postRequest:dataRequest];
    }
    return self;
}

- (id)initWithURL:(NSString *)aServerURL
         delegate:(id)aDelegate
              tag:(int)aTag
     doneSelector:(SEL)aDoneSelector
    errorSelector:(SEL)aErrorSelector
   cancelSelector:(SEL)aCancelSelector
{
    if ((self = [super init])) {
        delegate = aDelegate;
        serverURL = [aServerURL retain];
        tag = aTag;
        doneSelector = aDoneSelector;
        errorSelector = aErrorSelector;
        cancelSelector = aCancelSelector;
        
        dataIncoming = [[NSMutableData alloc] initWithCapacity:0];
        
        //初始化数据
        _iReConnectCount = 0;
        [self getRequest];
    }
    return self;
}

-(void) postRequest:(NSData *)data {
    if (conn!=nil) {
        [conn release];
    }
    _isCompressData=NO;
    //上传数据至服务器
    NSURL *url = [NSURL URLWithString:serverURL];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url
                                                                cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                            timeoutInterval:REQUEST_TIMEOUT];
    [request setHTTPMethod:@"POST"];
    [request setValue:[NSString stringWithFormat:@"application/x-www-form-urlencoded"] forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"Keep-Alive"] forHTTPHeaderField:@"Connection"];
    [request setValue:[NSString stringWithFormat:@"XXPT"] forHTTPHeaderField:@"User-Agent"];
    [request setHTTPBody:data];
    conn=[[NSURLConnection connectionWithRequest:request delegate:self] retain];
    [request setTimeoutInterval:REQUEST_TIMEOUT];
    [request release];
    
    //启动超时检测
    _bIsTimeout = NO;
    
    //get 还是 post 请求的
    _bGetFlag = NO;
    
    [self cancelCheckTimeout];
    _timeoutTimer = [NSTimer scheduledTimerWithTimeInterval:REQUEST_TIMEOUT
                                                     target:self
                                                   selector:@selector(requestTimeoutHandler)
                                                   userInfo:nil
                                                    repeats:NO];
}

- (void)getRequest
{
    if (conn!=nil) {
        [conn release];
    }
    _isCompressData=NO;
    //上传数据至服务器
    NSURL *url = [NSURL URLWithString:serverURL];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url
                                                                cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                            timeoutInterval:REQUEST_TIMEOUT];
    [request setHTTPMethod:@"GET"];
    [request setValue:[NSString stringWithFormat:@"application/x-www-form-urlencoded"] forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"Keep-Alive"] forHTTPHeaderField:@"Connection"];
    [request setValue:[NSString stringWithFormat:@"XXPT"] forHTTPHeaderField:@"User-Agent"];
    conn = [[NSURLConnection connectionWithRequest:request delegate:self] retain];
    [request setTimeoutInterval:REQUEST_TIMEOUT];
    [request release];
    
    //启动超时检测
    _bIsTimeout = NO;
    
    //get 还是 post 请求的
    _bGetFlag = YES;
    
    [self cancelCheckTimeout];
    _timeoutTimer = [NSTimer scheduledTimerWithTimeInterval:REQUEST_TIMEOUT
                                                     target:self
                                                   selector:@selector(requestTimeoutHandler)
                                                   userInfo:nil
                                                    repeats:NO];
}

-(void)cancelRequest{
    [self cancelCheckTimeout];
    
    if (conn!=nil) {
        [conn cancel];
        [conn release];
        conn=nil;
        
        //向上层报告
        if (!_bIsTimeout && [delegate respondsToSelector:cancelSelector]) {
            [delegate performSelector:cancelSelector withObject:self];
        }
    }
}



//服务器有响应，先发送HTTP头，准备发送数据
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *) response {
    //获得服务器端为客户访问建立的SessionID，并保存在全局变量中
    //	NSHTTPURLResponse *httpResponse=(NSHTTPURLResponse *)response;
    //	NSString *contentType=[[httpResponse allHeaderFields] objectForKey:@"Content-Type"];
    //	if ([contentType rangeOfString:@"application/x-gzip;"].location != NSNotFound ) {
    //		_isCompressData=YES;
    //	}else {
    //		_isCompressData=NO;
    //	}
}

//接收到服务器返回的数据
- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)incomingData {
    //接收服务器返回的数据
    [dataIncoming appendData:incomingData];
    
}

//数据加载完成
- (void) connectionDidFinishLoading:(NSURLConnection *)connection {
    [self cancelCheckTimeout];
    
    NSString *str;
    if (_isCompressData) {
        NSData *uncompressData=[NSData TwDataUncompressGZipData:dataIncoming];
        str = [[NSString alloc] initWithData:uncompressData encoding:NSUTF8StringEncoding];
    }else {
        str = [[NSString alloc] initWithBytes:[dataIncoming bytes]
                                       length:[dataIncoming length]
                                     encoding:NSUTF8StringEncoding];
    }
    
    self.strResponse = str;
    [str release];
    
    //访问服务器成功
    if (!_bIsTimeout && doneSelector) {
        [delegate performSelector:doneSelector withObject:self];
    }
    
    //释放连接对象
    if (conn!=nil) {
        [conn release];
        conn=nil;
    }
}


//访问网络失败
- (void) connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    NSLog(@"connection:didFailWithError:");
    
    [self cancelCheckTimeout];
    
    //访问服务器失败
    if (!_bIsTimeout && errorSelector) {
        [delegate performSelector:errorSelector withObject:self];
    }
    
    //释放链接对象
    if (conn!=nil) {
        [conn release];
        conn=nil;
    }
}

- (void)dealloc {
    [self cancelCheckTimeout];
    
    [conn release];
    [dataIncoming release];
    self.strResponse=nil;
    //[strResponse release];
    
    [serverURL release];
    serverURL = nil;
    [dataRequest release];
    dataRequest = nil;
    //[delegate release];
    delegate = nil;
    doneSelector = NULL;
    errorSelector = NULL;
    cancelSelector = NULL;
    [super dealloc];
}

#pragma mark -
#pragma mark Private

- (void)cancelCheckTimeout
{
    if (_timeoutTimer)
    {
        [_timeoutTimer invalidate];
        _timeoutTimer = nil;
    }
}

- (void)requestTimeoutHandler
{
    NSLog(@"requestTimeoutHandler， _iReConnectCount = %lu", (unsigned long)_iReConnectCount);
    
    [self cancelCheckTimeout];
    
    _bIsTimeout = YES;
    //取消请求
    if (conn!=nil) {
        [conn cancel];
        [conn release];
        conn=nil;
    }
    
    //超时重连机制
    if (_iReConnectCount < __TIMEOUT_RECONNECT_MAX_NUM__)
    {
        _iReConnectCount++;
        
        if (_bGetFlag)
        {
            [self getRequest];
        }
        else
        {
            [self postRequest:dataRequest];
        }
    }
    else
    {
        //报告超时委托
        if (errorSelector) {
            [delegate performSelector:errorSelector withObject:self];
        }
    }
}

@end
