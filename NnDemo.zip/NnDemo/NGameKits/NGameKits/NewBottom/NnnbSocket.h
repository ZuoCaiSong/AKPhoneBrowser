//
//  NnnbSocket.h
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "AsyncSocketNnnbSDK.h"

@class NnnbSocket;

/**
	Socket异常
 */
typedef enum{
	NnnbSocketErrorUncompressDataError,	/**< 解压数据异常 */
	NnnbSocketErrorNotConnected			/**< 尚未链接 */
}NnnbSocketError;


@protocol NnnbSocketDelegate

//连接事件
- (void) onSocketConnected:(NnnbSocket*)socket;

/**
	重连事件
	@param socket Socket对象
 */
- (void)onSocketReconnected:(NnnbSocket *)socket;


//数据接收事件
- (void) onSocketDataReceived:(NnnbSocket*)socket;
//链接关闭事件
- (void) onSocketDisconnected:(NnnbSocket *)socket;
//数据发送事件
- (void) onSocketDataSent:(NnnbSocket *)socket tag:(NSNumber *)tag;
//异常事件
- (void) onSocketError:(NnnbSocket *)socket error:(NSError *)error;

@end


@interface NnnbSocket : NSObject {	
	id  delegate;
	int tagger;
	SEL connectedSelector;
	SEL _reconnectedSelector;	//重连事件处理器
	SEL sendSelector;
	SEL disconnectedSelector;
	SEL errorSelector;
	SEL dataDidSendSelector;	//数据已发送委托
	
	AsyncSocketNnnbSDK *asynSocket;   //异步套接口
	
	NSString  *strServer;      //服务器地址
	int iPort;                 //服务器端口
	
	NSTimer *timer1;	       //心跳定时器
	NSTimer *timer2;           //断开状态报告定时器
	int     counterRC;         //重连计数器
	int     counterHB;         //心跳计数器   
	int     iStatus;           //状态  0:未连接   1:正在连接   2:已连接  
	NSData  *dataHB;           //心跳协议包	
	
	int nMsgId;                //最近接收到的服务器推送过来的MessageId
	NSString* strMsgContent;   //最近接收到的服务器推送过来的Message内容
	
	/**
	 错误，表示在连接过程中是否存在异常，
	 主要用于判断Socket是正常断开还是异常断开,如果异常断开则立即重连，否则由心跳负责重连
	 **/
	BOOL	hasError;
	
	/**
	 重连，当前连接是否与服务器进行重新连接。
	 **/
	BOOL	isReconnect;
	
	/**
	 压缩数据,如果接收的数据为压缩数据则此值为YES，否则为NO。
	 **/
	BOOL    isCompressData;
	
}

@property(nonatomic, assign) int tagger;
@property(nonatomic, assign) int nMsgId;
@property(nonatomic, retain) NSString *strMsgContent;
@property(nonatomic) BOOL isReconnect;

/**
	初始化Socket对象
	@param dele 委托对象，用于委托Socket对象的相应事件
	@param ta Socket
	@param onServerConnected 服务器连接事件处理器
	@param onServerReconnected 服务器重连事件处理器
	@param onDataReceived 数据接收事件处理器
	@param onDataSent 数据发送事件处理器
	@param onServerDisconnected 服务器断开链接事件处理器
	@param onServerError 服务器异常事件处理器
	@returns Socket对象
 */
- (id) initWithDelegate:(id)dele
					Tag:(int)ta
		ConnectSelector:(SEL)onServerConnected
	  ReconnectSelector:(SEL)onServerReconnected
		   DataSelector:(SEL)onDataReceived
		   SendSelector:(SEL)onDataSent
	 DisconnectSelector:(SEL)onServerDisconnected
		  ErrorSelector:(SEL)onServerError;


/**
	连接服务器
	@param server 服务器地址
	@param port 服务器端口
 */
-(void) connectServer:(NSString*)server
				 Port:(NSInteger)port;


-(void) startHB:(NSData*)data;   //开始心跳
-(void) sendData:(NSData*)data tag:(NSInteger)tag;  //发送数据
-(void) disconnectServer;        //断开服务器
-(void) reconnectServer;		 //重连服务器

@end
