//
//  Encrypt.m
//  Hello320
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbEncrypt.h"
#import "NnnbGTMBase64.h"
#import <CommonCrypto/CommonDigest.h>
#import "NSString+NnnbAESCrypt.h"


@implementation NnnbEncrypt

+ (NSString*) sha1:(NSString*)input {
    NSData *data = [input dataUsingEncoding:NSUTF8StringEncoding];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

+ (NSString *) md5:(NSString *)input {
    const char *cStr = [input UTF8String];
    unsigned char digest[16];
    CC_MD5( cStr, strlen(cStr), digest ); // This is the md5 call
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return  output;
    
}

+ (NSString*) sha1base64:(NSString*)input {
    NSData *data = [input dataUsingEncoding:NSUTF8StringEncoding];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSData *dd = [NSData dataWithBytes:(const void *)digest length:(NSUInteger)CC_SHA1_DIGEST_LENGTH];
    NSData *base64 = [NnnbGTMBase64 encodeData:dd];
    NSString *output = [[[NSString alloc] initWithData:base64 encoding:NSUTF8StringEncoding] autorelease];
    return output;
}

+ (NSString*) encryptString:(NSString*)plaintext withKey:(NSString*)key {
    NSString *strCipher = [plaintext TwAES256EncryptWithKey:key];
    return strCipher;
}

+ (NSString*) decryptString:(NSString*)ciphertext withKey:(NSString*)key {
    NSString *strPlain = [ciphertext TwAES256DecryptWithKey:key];
    return strPlain;
}

@end
