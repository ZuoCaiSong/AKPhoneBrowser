//
//  NSString+NnnbAESCrypt.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSData+NnnbAESCrypt.h"

@interface NSString (TwAESCrypt)

- (NSString *)TwAES128EncryptWithKey:(NSString *)key;
- (NSString *)TwAES128DecryptWithKey:(NSString *)key;

- (NSString *)TwAES256EncryptWithKey:(NSString *)key;
- (NSString *)TwAES256DecryptWithKey:(NSString *)key;

@end
