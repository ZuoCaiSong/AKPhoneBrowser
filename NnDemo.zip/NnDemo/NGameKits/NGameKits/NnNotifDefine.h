
#ifndef TwGame_NnNotifDefine_h
#define TwGame_NnNotifDefine_h

//登录成功， 注册并登录成功， 自动注册成功后通知 
#define NN_NOTIF_LOGIN_SUCCESS @"NN_NOTIF_LOGIN_SUCCESS"

//登录成功通知中UserInfo为NSDictionary
//对应的KEY 获取当前用户唯一身份uid
#define KEY_USER_ID    @"nn_user_id"      //NSString
//登陆验证
#define KEY_LOGIN_SIGN   @"nn_login_sign"

//注册成功
#define NN_NOTIF_REGISTER_SUCCESS @"NN_NOTIF_REGISTER_SUCCESS"
//注册失败
#define NN_NOTIF_REGISTER_FAIL @"NN_NOTIF_REGISTER_FAIL"

//初始化成功 失败通知
#define NN_NOTIF_INIT_SUCCESS @"NN_NOTIF_INIT_SUCCESS"

#define NN_NOTIF_LOGOUT_SUCCESS @"NN_NOTIF_LOGOUT_SUCCESS"

#define NN_NOTIF_APPLE   @"NN_NOTIF_APPLE"


#define NN_NOTIF_BINDPHONE_SUCCESS  @"NN_NOTIF_BINDPHONE_SUCCESS"

////实名认证成功通知
//#define NN_NOTIF_CHECKPERSONID_SUCCESS @"NN_NOTIF_CHECKPERSONID_SUCCESS"
//
////安装激活统计
//#define NN_INSTALLACTIVEFLAG   @"NN_INSTALLACTIVEFLAG"
//
////idfa key
//#define NN_IDFA_CHAINKEY       @"nn_idfa_chainkey"
//
//#define NN_BECOMEACTIVE_HANDLE     @"NN_BECOMEACTIVE_HANDLE"

#endif
