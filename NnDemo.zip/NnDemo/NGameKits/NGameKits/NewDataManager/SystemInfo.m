//
//  SystemInfo.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "SystemInfo.h"
#import "UIDevice+Game.h"
#import "NSUserDefaults+Game.h"

@implementation SystemInfo

-(id)init
{
    if (self = [super init])
    {
        self.deviceCode = [UIDevice macaddress];
        self.strAppId = @"1000";
        self.strAppKey = @"1000";
        self.strSessionId = @"";
    }
    
    return self;
}

@end
