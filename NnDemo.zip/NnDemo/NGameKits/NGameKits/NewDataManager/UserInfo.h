//
//  UserInfo.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfo : NSObject

@property (nonatomic) long lUserId;
@property (nonatomic, strong) NSString* strUserName;
@property (nonatomic, strong) NSString *strUserPassWord;
@property (nonatomic, assign) BOOL isBind;
@property (nonatomic, assign) BOOL isCheck;

-(void)importWithServerData:(NSDictionary*)dic;

@end
