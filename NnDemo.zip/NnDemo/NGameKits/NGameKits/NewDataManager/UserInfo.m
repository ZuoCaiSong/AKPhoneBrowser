//
//  UserInfo.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

-(id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.lUserId = 0;
        self.strUserName = nil;
    }
    
    return self;
}

-(void)importWithServerData:(NSDictionary*)dic
{
    if (dic == nil)
    {
        return;
    }
    
    id value = nil;
    
    value = [dic objectForKey:@"uid"];
    if (value != nil && value != [NSNull null])
    {
        NSNumberFormatter *f = [[NSNumberFormatter alloc] init];
        id result;
        result=[f numberFromString:value];
        if(!(result))
        {
            result=value;
        }
         self.lUserId = [result longValue];
    }
    
    value = [dic objectForKey:@"uname"];
    if (value != nil && value != [NSNull null])
    {
        self.strUserName = value;
    }
    
    value = [dic objectForKey:@"bindPhone"];
    if (value != nil && value != [NSNull null])
    {
        if ([value intValue]==1) {
            self.isBind = YES;
        }
        else
        {
            self.isBind = NO;
        }
       
    }
    
    value = [dic objectForKey:@"fcm"];
    if (value != nil && value != [NSNull null])
    {
        if ([value intValue]==1) {
            self.isCheck = YES;
        }
        else
        {
            self.isCheck = NO;
        }
    }
}

@end
