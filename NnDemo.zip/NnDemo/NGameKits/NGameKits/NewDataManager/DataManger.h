//
//  WPDataManger.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SystemInfo.h"
#import "UserInfo.h"

@interface DataManger : NSObject
@property(nonatomic, retain) SystemInfo *systemInfo;
@property(nonatomic, retain) UserInfo *currentUserInfo;

+ (DataManger*)getInstance;

- (void)clear;

@end
