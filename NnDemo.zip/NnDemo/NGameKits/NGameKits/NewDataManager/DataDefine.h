//
//  DataDefine.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#ifndef TwChong_DataDefine_h
#define TwChong_DataDefine_h

typedef enum
{
    eDefault = 0,
    ezChong = 1,
    ewChong = 2,
    eaChong = 3,
    eChTypeMax
}ChValueType;

#endif
