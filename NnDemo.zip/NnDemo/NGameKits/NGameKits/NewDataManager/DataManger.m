//
//  WPDataManger.m
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "DataManger.h"

static DataManger* _sDataMangerInstance = nil;

@implementation DataManger

+ (DataManger*)getInstance
{
    @synchronized(self)
	{
        if (_sDataMangerInstance == nil)
        {
            _sDataMangerInstance = [[DataManger alloc] init];
        }
    }
    
    return _sDataMangerInstance;
}

- (id)init
{
    if (self = [super init])
    {
        _systemInfo = [[SystemInfo alloc] init];
        _currentUserInfo = [[UserInfo alloc] init];
    }
    
    return self;
}

- (void)clear
{
    self.currentUserInfo = [[UserInfo alloc] init];
    self.systemInfo.strSessionId = nil;
}

@end
