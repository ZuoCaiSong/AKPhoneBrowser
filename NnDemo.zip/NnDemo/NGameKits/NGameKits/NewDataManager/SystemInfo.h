//
//  SystemInfo.h
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//系统配置参数
@interface SystemInfo : NSObject
@property(nonatomic, copy) NSString* deviceCode;
@property(nonatomic, copy) NSString* strAppId;
@property(nonatomic, copy) NSString* strAppKey;
@property(nonatomic, copy) NSString* strSessionId;
@end
