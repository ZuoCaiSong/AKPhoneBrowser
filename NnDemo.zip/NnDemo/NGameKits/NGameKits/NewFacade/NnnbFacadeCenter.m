//
//  NnnbFacadeCenter.m
//  

#import "NnnbFacadeCenter.h"
#import "NnnbFacade+Get.h"

typedef void(^TokenManagerBlock)(BOOL,NSNotification *);
@interface NnnbFacadeCenter ()
@property (nonatomic,strong) NnnbAsyncToken *fastRegistToken;   //快速注册的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *registToken;   //注册账号的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *getRegistAccountToken;   //快速注册的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *loginToken;   //快速注册的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *phoneLoginToken;   //手机登录的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *getCodeForPhoneLoginToken;   //获取手机登录验证码的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *getCodeForUserBindToken;   //获取用户验证码的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *getCodeForUserForgetPsdToken;   //获取用户修改密码验证码的网络令牌
@property (nonatomic,strong) NnnbAsyncToken *bindToken;     //绑定手机
@property (nonatomic,strong) NnnbAsyncToken *resetPswToken; //修改密码
@property (nonatomic,strong) NnnbAsyncToken *confirmCodeToken;     //验证账号信息
@property (nonatomic,strong) NnnbAsyncToken *personIdToken;       //实名认证
@property (nonatomic,strong) NnnbAsyncToken *changePsdToken;       //修改密码
@property (nonatomic,strong) NnnbAsyncToken *verifyAccToken;   //验证是否是随机账号

@property (nonatomic,strong) NnnbAsyncToken *dingOrdToken;
@property (nonatomic,strong) NnnbAsyncToken *publicNotToken;
@property (nonatomic,strong) NnnbAsyncToken *haveReadPublicNotToken;
@property (nonatomic,strong) NnnbAsyncToken *packageListToken;
@property (nonatomic,strong) NnnbAsyncToken *getPackageCodeToken;
@property (nonatomic,strong) NnnbAsyncToken *topUpRecordToken;
@property (nonatomic,strong) NnnbAsyncToken *getCodeForAccountLevelUpToken;
@property (nonatomic,strong) NnnbAsyncToken *confirmCodeAccountLevelUpToken;
@property (nonatomic,strong) NnnbAsyncToken *swiToken;
@property (nonatomic,strong) NnnbAsyncToken *deleteTopUpRecordToken;
@property (nonatomic,strong) NnnbAsyncToken *gameConfigToken;
@property (nonatomic,strong) NnnbAsyncToken *downOrdToken;


@property (nonatomic,copy)TokenManagerBlock fastRegistBlock;
@property (nonatomic,copy)TokenManagerBlock registBlock;
@property (nonatomic,copy)TokenManagerBlock getAccountBlock;
@property (nonatomic,copy)TokenManagerBlock loginBlock;
@property (nonatomic,copy)TokenManagerBlock phoneLoginBlock;
@property (nonatomic,copy)TokenManagerBlock verifyCodeForPhoneLoginBlock;
@property (nonatomic,copy)TokenManagerBlock verifyCodeForUserBindBlock;
@property (nonatomic,copy)TokenManagerBlock verifyCodeForUserForgetPsdBlock;
@property (nonatomic,copy)TokenManagerBlock verifyCodeForAccountLevelUpBlock;
@property (nonatomic,copy)TokenManagerBlock bindPhoneBlock;
@property (nonatomic,copy)TokenManagerBlock resetPswBlock;
@property (nonatomic,copy)TokenManagerBlock confirmCodeBlock;
@property (nonatomic,copy)TokenManagerBlock checkRealNameBlock;
@property (nonatomic,copy)TokenManagerBlock changePsdBlock;
@property (nonatomic,copy)TokenManagerBlock verifyAccBlock;


@property (nonatomic,copy)TokenManagerBlock dingOrdBlock;
@property (nonatomic,copy)TokenManagerBlock publicNotBlock;
@property (nonatomic,copy)TokenManagerBlock haveReaduPublicNotBlock;
@property (nonatomic,copy)TokenManagerBlock packageListBlock;
@property (nonatomic,copy)TokenManagerBlock getPackageCodeBlock;
@property (nonatomic,copy)TokenManagerBlock topUpRecordBlock;
@property (nonatomic,copy)TokenManagerBlock confirmCodeAccountLevelUpBlock;
@property (nonatomic,copy)TokenManagerBlock swiBlock;
@property (nonatomic,copy)TokenManagerBlock deleteTopUpRecordBlock;
@property (nonatomic,copy)TokenManagerBlock gameConfigBlock;
@property (nonatomic,copy)TokenManagerBlock downOrdBlock;

@end
@implementation NnnbFacadeCenter

+ (instancetype)defaultFacade {
    static NnnbFacadeCenter *obj = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        obj = [[NnnbFacadeCenter alloc] init];
    });
    return obj;
}

#pragma mark -----------------
- (void)getVersionRequest:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.swiBlock = callBlock;
    if (!_swiToken) {
        _swiToken = [[NnnbFacade getInstance] getVersionRequest];
        
        [_swiToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(swiResultHandler:)];
        [_swiToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(swiErrorHandler:)];
    }
}

- (void)swiResultHandler:(NSNotification*)notifi {
    if (self.swiBlock) {
        self.swiBlock(YES, notifi);
    }
    [self clearSwiToken];
}

- (void)swiErrorHandler:(NSNotification*)notifi {
    if (self.swiBlock) {
        self.swiBlock(NO, notifi);
    }
    [self clearSwiToken];
}

- (void)clearSwiToken {
    if (_swiToken != nil){
        [_swiToken removeObserver:self];
        _swiToken = nil;
    }
    
    if (_swiBlock) {
        _swiBlock = nil;
    }
}

#pragma mark - 获取配置
- (void)getConfig:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.gameConfigBlock = callBlock;
    
    if (!_gameConfigToken) {
        _gameConfigToken = [[NnnbFacade getInstance] getConfig];
        [_gameConfigToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(configResultHandler:)];
        [_gameConfigToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(configResultErrorHandler:)];
    }
}

- (void)configResultHandler:(NSNotification*)notifi {
    if (self.gameConfigBlock) {
        self.gameConfigBlock(YES, notifi);
    }
    
    [self clearGameConfigToken];
}

- (void)configResultErrorHandler:(NSNotification*)notifi{
    if (self.gameConfigBlock) {
        self.gameConfigBlock(NO, notifi);
    }
    
    [self clearGameConfigToken];
}

- (void)clearGameConfigToken {
    if (_gameConfigToken != nil) {
        [_gameConfigToken removeObserver:self];
        _gameConfigToken = nil;
    }
    
    if (_gameConfigBlock) {
        _gameConfigBlock = nil;
    }
}

#pragma mark verify Account
- (void)verifyAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.verifyAccBlock = callBlock;
    if (!_verifyAccToken) {
        _verifyAccToken = [[NnnbFacade getInstance] isRandomAccountOrNot];
        
        [_verifyAccToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                  target:self
                                selector:@selector(verifyAccountResultHandler:)];
        
        [_verifyAccToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                  target:self
                                selector:@selector(verifyAccountErrorHandler:)];
    }
}
- (void)verifyAccountResultHandler:(NSNotification*)notifi {
    if (self.verifyAccBlock) {
        self.verifyAccBlock(YES, notifi);
    }
    [self clearVerifyAccountToken];
    
    
}
- (void)verifyAccountErrorHandler:(NSNotification*)notifi{
    if (self.verifyAccBlock) {
        self.verifyAccBlock(NO, notifi);
    }
    [self clearVerifyAccountToken];
}

- (void)clearVerifyAccountToken {
    if (_verifyAccToken != nil) {
        [_verifyAccToken removeObserver:self];
        _verifyAccToken = nil;
    }
    if (_verifyAccBlock) {
        _verifyAccBlock = nil;
    }
}

#pragma mark confirm account level up
- (void)confirmAccountLevelUp:(NSString *)account
                       andPsd:(NSString *)psd
                  messageCode:(NSString *)code
                       result:(void (^)(BOOL success,NSNotification *notifi))callBlock{
    self.confirmCodeAccountLevelUpBlock = callBlock;
    if (!_confirmCodeAccountLevelUpToken) {
        _confirmCodeAccountLevelUpToken = [[NnnbFacade getInstance] confirmLevelUpWithName:account Pwd:psd Code:code];
        
        [_confirmCodeAccountLevelUpToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                    target:self
                                  selector:@selector(confirmCodeAccountLevelUpResultHandler:)];
        
        [_confirmCodeAccountLevelUpToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                    target:self
                                  selector:@selector(confirmCodeAccountLevelUpErrorHandler:)];
    }
}
- (void)confirmCodeAccountLevelUpResultHandler:(NSNotification*)notifi {
    if (self.confirmCodeAccountLevelUpBlock) {
        self.confirmCodeAccountLevelUpBlock(YES, notifi);
    }
    //清除网络资源
    [self clearConfirmCodeAccountLevelUpToken];
}

-(void)confirmCodeAccountLevelUpErrorHandler:(NSNotification*)notifi {
    if (self.confirmCodeAccountLevelUpBlock) {
        self.confirmCodeAccountLevelUpBlock(NO, notifi);
    }
    //清除网络数据
    [self clearConfirmCodeAccountLevelUpToken];
}

- (void)clearConfirmCodeAccountLevelUpToken {
    if (_confirmCodeAccountLevelUpToken != nil) {
        [_confirmCodeAccountLevelUpToken removeObserver:self];
        _confirmCodeAccountLevelUpToken = nil;
    }
    if (_confirmCodeAccountLevelUpBlock) {
        _confirmCodeAccountLevelUpBlock = nil;
    }
}

#pragma mark Account level Up for verifyCode
- (void)getPhoneCodeForAccountLevelUp:(NSString *)account
                               result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.verifyCodeForAccountLevelUpBlock = callBlock;
    if (!_getCodeForAccountLevelUpToken) {
        _getCodeForAccountLevelUpToken = [[NnnbFacade getInstance] getLevelUpVerifyCodeWithName:account];
        
        [_getCodeForAccountLevelUpToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                      target:self
                                    selector:@selector(getVerifyCodeResultHandler:)];
        
        [_getCodeForAccountLevelUpToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                      target:self
                                    selector:@selector(getVerifyCodeErrorHandler:)];
    }
}
-(void)getVerifyCodeResultHandler:(NSNotification*)notifi {
    if (self.verifyCodeForAccountLevelUpBlock) {
        self.verifyCodeForAccountLevelUpBlock(YES, notifi);
    }
    //清除网络资源
    [self clearGetCodeForAccountLevelUpToken];
}

-(void)getVerifyCodeErrorHandler:(NSNotification*)notifi {
    if (self.verifyCodeForAccountLevelUpBlock) {
        self.verifyCodeForAccountLevelUpBlock(NO, notifi);
    }
    //清除网络资源
    [self clearGetCodeForAccountLevelUpToken];
}

- (void)clearGetCodeForAccountLevelUpToken {
    if (_getCodeForAccountLevelUpToken != nil) {
        [_getCodeForAccountLevelUpToken removeObserver:self];
        _getCodeForAccountLevelUpToken = nil;
    }
    if (_verifyCodeForUserBindBlock) {
        _verifyCodeForUserBindBlock = nil;
    }
}

#pragma Mark 一键注册
- (void)fastRegistWithAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.fastRegistBlock = callBlock;
    if (!_fastRegistToken) {
        //快速注册
        _fastRegistToken = [[NnnbFacade getInstance] fastRegistAccount];
        
        //监听快速注册结果
        [_fastRegistToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                   target:self
                                 selector:@selector(registQuickResultHandler:)];
        
        [_fastRegistToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                   target:self
                                 selector:@selector(registQuickErrorHandler:)];
    }
}
- (void)registQuickResultHandler:(NSNotification*)notifi {
    if (self.fastRegistBlock) {
        self.fastRegistBlock(YES, notifi);
    }
    //清除网络资源
    [self clearRegistQuickToken];
}
- (void)registQuickErrorHandler:(NSNotification*)notifi {
    if (self.fastRegistBlock) {
        self.fastRegistBlock(NO, notifi);
    }
    //清除网络资源
    [self clearRegistQuickToken];
}

- (void)clearRegistQuickToken {
    if (_fastRegistToken != nil){
        [_fastRegistToken removeObserver:self];
        _fastRegistToken = nil;
    }
}
#pragma mark -实名认证
- (void)checkPersonWithRealName:(NSString *)realName
                       personId:(NSString *)personId
                         result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.checkRealNameBlock = callBlock;
    if (!_personIdToken){
        _personIdToken = [[NnnbFacade getInstance] checkPersonWithRealName:realName  personID:personId];
        [_personIdToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                 target:self
                               selector:@selector(checkPersonIdResultHandler:)];
        
        [_personIdToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                 target:self
                               selector:@selector(checkPersonIdErrorHandler:)];
    }
}
- (void)checkPersonIdResultHandler:(NSNotification*)notifi {
    if (self.checkRealNameBlock) {
        self.checkRealNameBlock(YES, notifi);
    }
    //清除网络资源
    [self clearPersonIdToken];
}
- (void)checkPersonIdErrorHandler:(NSNotification*)notifi {
    if (self.checkRealNameBlock) {
        self.checkRealNameBlock(NO, notifi);
    }
    //清除网络资源
    [self clearPersonIdToken];

}
- (void)clearPersonIdToken {
    if (_personIdToken != nil) {
        [_personIdToken removeObserver:self];
        _personIdToken = nil;
    }
    if (_checkRealNameBlock) {
        _checkRealNameBlock = nil;
    }
}
#pragma mark -忘记密码 获取手机验证码
- (void)getPhoneCodeForUserForgetPsd:(NSString *)account
                               phone:(NSString *)phone
                               esult:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.verifyCodeForUserForgetPsdBlock = callBlock;
    if (!_getCodeForUserForgetPsdToken) {
        _getCodeForUserForgetPsdToken = [[NnnbFacade getInstance] getVerifyCodeforForgetPswWithUser:account Phone:phone];
        
        [_getCodeForUserForgetPsdToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                                target:self
                                              selector:@selector(getVerifyCodeForForgetPsdResultHandler:)];
        
        [_getCodeForUserForgetPsdToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                                target:self
                                              selector:@selector(getVerifyCodeForForgetPsdErrorHandler:)];
    }
}
- (void)getVerifyCodeForForgetPsdResultHandler:(NSNotification*)notifi {
    if (self.verifyCodeForUserForgetPsdBlock) {
        self.verifyCodeForUserForgetPsdBlock(YES, notifi);
    }
    //清除网络数据
    [self clearGetVerifyCodeForForgetPsdToken];
    
}

- (void)getVerifyCodeForForgetPsdErrorHandler:(NSNotification*)notifi {
    if (self.verifyCodeForUserForgetPsdBlock) {
        self.verifyCodeForUserForgetPsdBlock(NO, notifi);
    }
    //清除网络数据
    [self clearGetVerifyCodeForForgetPsdToken];
}

- (void)clearGetVerifyCodeForForgetPsdToken {
    if (_getCodeForUserForgetPsdToken != nil) {
        [_getCodeForUserForgetPsdToken removeObserver:self];
        _getCodeForUserForgetPsdToken = nil;
    }
    if (_verifyCodeForUserForgetPsdBlock) {
        _verifyCodeForUserForgetPsdBlock = nil;
    }
}
#pragma mark -验证账号信息
- (void)confirmVerifyCode:(NSString *)msgCode
                  account:(NSString *)account
                    phone:(NSString *)phone
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.confirmCodeBlock = callBlock;
    if (!_confirmCodeToken) {
        _confirmCodeToken = [[NnnbFacade getInstance] confirmVerifyCode:msgCode
                                                                account:account
                                                                  phone:phone];
        
        [_confirmCodeToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                    target:self
                                  selector:@selector(confirmVerifyCodeResultHandler:)];
        
        [_confirmCodeToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                    target:self
                                  selector:@selector(confirmVerifyCodeVerifyCodeErrorHandler:)];
    }
}

-(void)confirmVerifyCodeResultHandler:(NSNotification*)notifi {
    if (self.confirmCodeBlock) {
        self.confirmCodeBlock(YES, notifi);
    }
    //清除网络资源
    [self clearConfirmCodeToken];
}

-(void)confirmVerifyCodeVerifyCodeErrorHandler:(NSNotification*)notifi {
    if (self.confirmCodeBlock) {
        self.confirmCodeBlock(NO, notifi);
    }
    //清除网络数据
    [self clearConfirmCodeToken];
}

- (void)clearConfirmCodeToken {
    if (_confirmCodeToken != nil){
        [_confirmCodeToken removeObserver:self];
        _confirmCodeToken = nil;
    }
    if (_confirmCodeBlock) {
        _confirmCodeBlock = nil;
    }
}
#pragma mark - 重置密码
- (void)resetPassword:(NSString *)phone
               account:(NSString *)account
           messageCode:(NSString *)code
                andPsd:(NSString *)psd
                result:(void (^)(BOOL success,NSNotification *notifi))callBlock{
    
    self.resetPswBlock = callBlock;
    if (!_resetPswToken) {
        _resetPswToken = [[NnnbFacade getInstance] modifyPasswordWithCode:code
                                                                  account:account
                                                                    phone:phone
                                                                 password:psd];
        [_resetPswToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                  target:self
                                selector:@selector(resetPasswordWithCodeResultHandler:)];
        
        [_resetPswToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                  target:self
                                selector:@selector(resetPasswordWithCodeErrorHandler:)];
    }

}

- (void)resetPasswordWithCodeResultHandler:(NSNotification*)notifi {
    if (self.resetPswBlock) {
        self.resetPswBlock(YES, notifi);
    }
    [self cleanResetPswToken];
}

- (void)resetPasswordWithCodeErrorHandler:(NSNotification*)notifi {
    if (self.resetPswBlock) {
        self.resetPswBlock(NO, notifi);
    }
    [self cleanResetPswToken];
}
- (void)cleanResetPswToken {
    if (_resetPswToken){
        [_resetPswToken removeObserver:self];
        _resetPswToken = nil;
    }
    if (_resetPswBlock) {
        _resetPswBlock = nil;
    }
}
#pragma mark 修改密码
- (void)changeOldPsd:(NSString *)oldPsd
           andXinPsd:(NSString *)xinPsd
              result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.changePsdBlock = callBlock;
    if (!_changePsdToken) {
        _changePsdToken = [[NnnbFacade getInstance] modifyPasswordOldPswWithCode:oldPsd password:xinPsd];
        
        
        [_changePsdToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                  target:self
                                selector:@selector(changePasswordResultHandler:)];
        
        [_changePsdToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                  target:self
                                selector:@selector(changePasswordErrorHandler:)];
    }
}
- (void)changePasswordResultHandler:(NSNotification*)notifi {
    if (self.changePsdBlock) {
        self.changePsdBlock(YES, notifi);
    }
    //清除网络资源
    [self clearChangePsdToken];
}
- (void)changePasswordErrorHandler:(NSNotification*)notifi {
    if (self.changePsdBlock) {
        self.changePsdBlock(NO, notifi);
    }
    //清除网络资源
    [self clearChangePsdToken];
}

- (void)clearChangePsdToken {
    if (_changePsdToken != nil) {
        [_changePsdToken removeObserver:self];
        _changePsdToken = nil;
    }
    if (_changePsdBlock) {
        _changePsdBlock = nil;
    }
}


#pragma mark -注册账号
- (void)registWithAccount:(NSString *)account
                   andPsd:(NSString *)psd
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.registBlock = callBlock;
    //注册
    if (!_registToken) {
        _registToken = [[NnnbFacade getInstance] registAccountWithUserName:account Password:psd];
        //监听注册结果
        [_registToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                               target:self
                             selector:@selector(registResultHandler:)];
        [_registToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                               target:self
                             selector:@selector(registErrorHandler:)];
    }
}

- (void)registResultHandler:(NSNotification*)notifi {
    if (self.registBlock) {
        self.registBlock(YES, notifi);
    }
    //清除网络资源
    [self clearRegistToken];
}

- (void)registErrorHandler:(NSNotification*)notifi {
    if (self.registBlock) {
        self.registBlock(NO, notifi);
    }
    //清除网络资源
    [self clearRegistToken];
}

- (void)clearRegistToken {
    if (_registToken != nil) {
        [_registToken removeObserver:self];
        _registToken = nil;
    }
    if (_registBlock) {
        _registBlock = nil;
    }
}

#pragma mark - 绑定手机
- (void)bindPhone:(NSString *)phone
      messageCode:(NSString *)code
           result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.bindPhoneBlock = callBlock;
    if (!_bindToken) {
        _bindToken = [[NnnbFacade getInstance] bindPhoneWithPhoneNum:phone code:code];
        
        [_bindToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                             target:self
                           selector:@selector(bindPhoneResultHandler:)];
        
        [_bindToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                             target:self
                           selector:@selector(bindPhoneErrorHandler:)];
    }
}

- (void)bindPhoneResultHandler:(NSNotification*)notifi {
    if (self.bindPhoneBlock) {
        self.bindPhoneBlock(YES, notifi);
    }
    //清除网络资源
    [self clearBindPhoneToken];
}


- (void)bindPhoneErrorHandler:(NSNotification*)notifi {
    if (self.bindPhoneBlock) {
        self.bindPhoneBlock(NO, notifi);
    }
    //清除网络资源
    [self clearBindPhoneToken];
}
- (void)clearBindPhoneToken {
    if (_bindToken ) {
        [_bindToken removeObserver:self];
        _bindToken = nil;
    }
    if (_bindPhoneBlock) {
        _bindPhoneBlock = nil;
    }
}
#pragma mark - 获取绑定手机的验证码
- (void)getPhoneCodeForUserBind:(NSString *)userName
                      phone:(NSString *)phone
                     result:(void (^)(BOOL success,NSNotification *notifi))callBlock  {
    self.verifyCodeForUserBindBlock = callBlock;
    if (!_getCodeForUserBindToken) {
        _getCodeForUserBindToken = [[NnnbFacade getInstance] getVerifyCodeForBindPhoneWithUser:userName phone:phone];
        
        [_getCodeForUserBindToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                       target:self
                                     selector:@selector(getVerifyCodeForUserResultHandler:)];
        
        [_getCodeForUserBindToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                       target:self
                                     selector:@selector(getVerifyCodeForUserErrorHandler:)];
    }
    
}

- (void)getVerifyCodeForUserResultHandler:(NSNotification*)notifi {
    if (self.verifyCodeForUserBindBlock) {
        self.verifyCodeForUserBindBlock(YES, notifi);
    }
    //清除网络数据
    [self clearGetVerifyCodeForUserToken];
    
}

- (void)getVerifyCodeForUserErrorHandler:(NSNotification*)notifi {
    if (self.verifyCodeForUserBindBlock) {
        self.verifyCodeForUserBindBlock(NO, notifi);
    }
    //清除网络数据
    [self clearGetVerifyCodeForUserToken];
}

- (void)clearGetVerifyCodeForUserToken {
    if (_getCodeForUserBindToken != nil) {
        [_getCodeForUserBindToken removeObserver:self];
        _getCodeForUserBindToken = nil;
    }
    if (_verifyCodeForUserBindBlock) {
        _verifyCodeForUserBindBlock = nil;
    }
}
#pragma mark - 手机登录获取验证码
- (void)getPhoneCodeForPhoneLogin:(NSString *)phone
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.verifyCodeForPhoneLoginBlock = callBlock;

    if (!_getCodeForPhoneLoginToken) {
        _getCodeForPhoneLoginToken = [[NnnbFacade getInstance] getVerifyCodeForPhoneLogin:phone];
        
        [_getCodeForPhoneLoginToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                        target:self
                                      selector:@selector(getPlVerifyCodeForPhoneLoginResultHandler:)];
        
        [_getCodeForPhoneLoginToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                        target:self
                                      selector:@selector(getPlVerifyCodeForPhoneLoginErrorHandler:)];
    }
}
-(void)getPlVerifyCodeForPhoneLoginResultHandler:(NSNotification*)notifi {
    if (self.verifyCodeForPhoneLoginBlock) {
        self.verifyCodeForPhoneLoginBlock(YES, notifi);
    }
    //清除网络资源
    [self clearGetVerifyCodeForPhoneLoginToken];
}

-(void)getPlVerifyCodeForPhoneLoginErrorHandler:(NSNotification*)notifi {
    
    if (self.verifyCodeForPhoneLoginBlock) {
        self.verifyCodeForPhoneLoginBlock(NO, notifi);
    }
    //清除网络资源
    [self clearGetVerifyCodeForPhoneLoginToken];
}

- (void)clearGetVerifyCodeForPhoneLoginToken {
    if (_getCodeForPhoneLoginToken != nil) {
        [_getCodeForPhoneLoginToken removeObserver:self];
        _getCodeForPhoneLoginToken = nil;
    }
    if (_verifyCodeForPhoneLoginBlock) {
        _verifyCodeForPhoneLoginBlock = nil;
    }
}
#pragma mark - 手机登录方法
- (void)phoneloginNumber:(NSString *)phone
             messageCode:(NSString *)code
                  result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.phoneLoginBlock = callBlock;
    if (!_phoneLoginToken) {
        _phoneLoginToken = [[NnnbFacade getInstance] phoneLoginWithPhone:phone message:code];
        
        [_phoneLoginToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                   target:self
                                 selector:@selector(phoneLoginResultHandler:)];
        
        [_phoneLoginToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                   target:self
                                 selector:@selector(phoneLoginErrorHandler:)];
    }
}
//登录成功
- (void)phoneLoginResultHandler:(NSNotification*)notifi {
    if (self.phoneLoginBlock) {
        self.phoneLoginBlock( YES, notifi);
    }
    //清除网络资源
    [self clearPhoneLoginToken];
   
}

//登录失败
- (void)phoneLoginErrorHandler:(NSNotification*)notifi {
    if (self.phoneLoginBlock){
        self.phoneLoginBlock( NO, notifi);
    }
    //清除网络资源
    [self clearPhoneLoginToken];

}

//清除网络令牌
- (void)clearPhoneLoginToken
{
    if (_phoneLoginToken != nil){
        [_phoneLoginToken removeObserver:self];
        _phoneLoginToken = nil;
    }
    if (_phoneLoginBlock) {
        _phoneLoginBlock = nil;
    }
}



#pragma mark - 账号登录
- (void)loginWithName:(NSString*)userName
             password:(NSString*)password
               result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.loginBlock = callBlock;
    if (!_loginToken) {
        _loginToken = [[NnnbFacade getInstance] loginWithUserName:userName Password:password];
        
        [_loginToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(loginResultHandler:)];
        
        [_loginToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(loginErrorHandler:)];
    }
}

- (void)loginResultHandler:(NSNotification*)notifi {
    if (self.loginBlock){
        self.loginBlock(YES, notifi);
    }
    //清除网络资源
    [self clearloginToken];
}

- (void)loginErrorHandler:(NSNotification*)notifi {
    if (self.loginBlock){
        self.loginBlock(NO, notifi);
    }
    //清除网络资源
    [self clearloginToken];
}

- (void)clearloginToken {
    if (_loginToken != nil){
        [_loginToken removeObserver:self];
        _loginToken = nil;
    }
    if (_loginBlock) {
        _loginBlock = nil;
    }
}

#pragma mark - 获取注册账号方法
- (void)getRegistAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.getAccountBlock = callBlock;
    //快速注册
    if (!_getRegistAccountToken) {
        _getRegistAccountToken = [[NnnbFacade getInstance] getRegistAccount];
        //监听快速注册结果
        [_getRegistAccountToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                                         target:self
                                       selector:@selector(getRegistAccountSuccessHandler:)];
        
        [_getRegistAccountToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                                         target:self
                                       selector:@selector(rgetRegistAccountErrorHandler:)];
    }
}
- (void)getRegistAccountSuccessHandler:(NSNotification *)notifi {
    
    if (self.getAccountBlock){
        self.getAccountBlock(YES,notifi);
    }
    //清除网络资源
    [self clearGetRegistAccountToken];
}
- (void)rgetRegistAccountErrorHandler:(NSNotification *)notifi {

    if (self.getAccountBlock){
        self.getAccountBlock(NO,notifi);
    }
    //清除网络资源
    [self clearGetRegistAccountToken];
    
}
- (void)clearGetRegistAccountToken{
    if (_getRegistAccountToken != nil){
        [_getRegistAccountToken removeObserver:self];
        _getRegistAccountToken = nil;
    }
    if (_getAccountBlock) {
        _getAccountBlock = nil;
    }
}
#pragma mark PublicNot
- (void)getPublicNotDataWithType:(NSInteger)notType
                          result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.publicNotBlock = callBlock;
    _publicNotToken = [[NnnbFacade getInstance] getPublicNotDataWithType:notType];
    
    [_publicNotToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(publicNotResultHandler:)];
    
    [_publicNotToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(publicNotErrorHandler:)];
}
- (void)publicNotResultHandler:(NSNotification*)notifi {
    if (self.publicNotBlock) {
        self.publicNotBlock(YES, notifi);
    }
    //清除网络资源
    [self clearPublicNotToken];
}

- (void)publicNotErrorHandler:(NSNotification*)notifi {
    if (self.publicNotBlock) {
        self.publicNotBlock(NO, notifi);
    }
    //清除网络资源
    [self clearPublicNotToken];
}

- (void)clearPublicNotToken {
    if (_publicNotToken != nil){
        [_publicNotToken removeObserver:self];
        _publicNotToken = nil;
    }
    if (_publicNotBlock) {
        _publicNotBlock = nil;
    }
}
#pragma mark read publicNot
- (void)haveReadPublicNot:(NSInteger)pubNotId
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.haveReaduPublicNotBlock = callBlock;
    if (!_haveReadPublicNotToken) {
        _haveReadPublicNotToken = [[NnnbFacade getInstance] reportPublicIsReadWithNoticeID:pubNotId];

        [_haveReadPublicNotToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(haveReadPublicNotResultHandler:)];

        [_haveReadPublicNotToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(haveReadPublicNotErrorHandler:)];
    }
}
- (void)haveReadPublicNotResultHandler:(NSNotification*)notifi {
    if (self.haveReaduPublicNotBlock) {
        self.haveReaduPublicNotBlock(YES, notifi);
    }
    [self cleanHaveReadPublicNotToken];
}
- (void)haveReadPublicNotErrorHandler:(NSNotification*)notifi {
    if (self.haveReaduPublicNotBlock) {
        self.haveReaduPublicNotBlock(NO, notifi);
    }
    [self cleanHaveReadPublicNotToken];
}
- (void)cleanHaveReadPublicNotToken {
    if (_haveReadPublicNotToken != nil){
        [_haveReadPublicNotToken removeObserver:self];
        _haveReadPublicNotToken = nil;
    }
    if (_haveReaduPublicNotBlock) {
        _haveReaduPublicNotBlock = nil;
    }
}
#pragma mark /////////////
- (void)getPackageListData:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.packageListBlock = callBlock;
    if (!_packageListToken) {
        _packageListToken = [[NnnbFacade getInstance] getPackageListData];
        [_packageListToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(packageListResultHandler:)];
        
        [_packageListToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(packageListErrorHandler:)];
    }
}
- (void)packageListResultHandler:(NSNotification*)notifi {
    
    if (self.packageListBlock) {
        self.packageListBlock(YES, notifi);
    }
    [self clearpackageListToken];
}

- (void)packageListErrorHandler:(NSNotification*)notifi {
    if (self.packageListBlock) {
        self.packageListBlock(NO, notifi);
    }
    [self clearpackageListToken];
}

- (void)clearpackageListToken {
    if (_packageListToken != nil){
        [_packageListToken removeObserver:self];
        _packageListToken = nil;
    }
    if (_packageListBlock) {
        _packageListBlock = nil;
    }
}
#pragma mark - 理煲码
- (void)getPageageCode:(NSInteger)codeType
                 hdStr:(NSString *)hdstr
                result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.getPackageCodeBlock = callBlock;
    if (!_getPackageCodeToken) {
        _getPackageCodeToken = [[NnnbFacade getInstance] getPackageCodeDataWithCodeType:codeType hdStr:hdstr];
        
        [_getPackageCodeToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(packageCodeResultHandler:)];
        
        [_getPackageCodeToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(packageCodeErrorHandler:)];
    }
}
- (void)packageCodeResultHandler:(NSNotification*)notifi {
    if (self.getPackageCodeBlock) {
        self.getPackageCodeBlock(YES, notifi);
    }
    [self clearpackageCodeToken];
   
}

- (void)packageCodeErrorHandler:(NSNotification*)notifi {
    if (self.getPackageCodeBlock) {
        self.getPackageCodeBlock(NO, notifi);
    }
    [self clearpackageCodeToken];
}
- (void)clearpackageCodeToken {
    if (_getPackageCodeToken != nil){
        [_getPackageCodeToken removeObserver:self];
        _getPackageCodeToken = nil;
    }
    if (_getPackageCodeBlock) {
        _getPackageCodeBlock = nil;
    }
}
#pragma mark - topUpRecord
- (void)getTopUpRecordWithDateStr:(NSString *)dateStr
                result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.topUpRecordBlock = callBlock;
    if(!_topUpRecordToken) {
        _topUpRecordToken = [[NnnbFacade getInstance] getTopUpRecordDataWithDate:dateStr];
        
        [_topUpRecordToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(topUpRecordResultHandler:)];
        
        [_topUpRecordToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(topUpRecordErrorHandler:)];
    }
}
- (void)topUpRecordResultHandler:(NSNotification*)notifi{
    if (self.topUpRecordBlock) {
        self.topUpRecordBlock(YES, notifi);
    }
    [self clearTopUpRecordToken];
}
- (void)topUpRecordErrorHandler:(NSNotification*)notifi {
    if (self.topUpRecordBlock) {
        self.topUpRecordBlock(NO, notifi);
    }
    [self clearTopUpRecordToken];
}

- (void)clearTopUpRecordToken {
    if (_topUpRecordToken != nil){
        [_topUpRecordToken removeObserver:self];
        _topUpRecordToken = nil;
    }
    if (_topUpRecordBlock) {
        _topUpRecordBlock = nil;
    }
}

#pragma mark delete topUpRecord
- (void)deleteTopUpRecord:(NSString *)recordId
                           result:(void (^)(BOOL success,NSNotification *notifi))callBlock {
    self.deleteTopUpRecordBlock = callBlock;
    if(!_deleteTopUpRecordToken) {
        _deleteTopUpRecordToken = [[NnnbFacade getInstance] deleteTopUpRecord:recordId];
        
        [_deleteTopUpRecordToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(deleteTopUpRecordResultHandler:)];
        
        [_deleteTopUpRecordToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(deleteTopUpRecordErrorHandler:)];
    }
}
- (void)deleteTopUpRecordResultHandler:(NSNotification*)notifi{
    if (self.deleteTopUpRecordBlock) {
        self.deleteTopUpRecordBlock(YES, notifi);
    }
    [self clearDeleteTopUpRecordToken];
}
- (void)deleteTopUpRecordErrorHandler:(NSNotification*)notifi {
    if (self.deleteTopUpRecordBlock) {
        self.deleteTopUpRecordBlock(NO, notifi);
    }
    [self clearDeleteTopUpRecordToken];
}
- (void)clearDeleteTopUpRecordToken {
    if (_deleteTopUpRecordToken != nil){
        [_deleteTopUpRecordToken removeObserver:self];
        _deleteTopUpRecordToken = nil;
    }
    if (_deleteTopUpRecordBlock) {
        _deleteTopUpRecordBlock = nil;
    }
}

#pragma mark - PM
- (void)dingOrdFuby:(ChValueType)type
             bill:(double)iBill
          subject:(CGFloat)fSubject
           result:(void (^)(BOOL success,NSNotification *notifi))callBlock
{
    self.dingOrdBlock = callBlock;
    if (!_dingOrdToken)
    {
        _dingOrdToken = [[NnnbFacade getInstance] fuBy:type
                                                bill:iBill
                                             subject:fSubject
                                            userData:nil];
        
        [_dingOrdToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                              target:self
                            selector:@selector(getDingOrdResultHandler:)];
        
        [_dingOrdToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                              target:self
                            selector:@selector(getDingOrdErrorHandler:)];
    }
}

- (void)getDingOrdResultHandler:(NSNotification*)notifi
{
    if (self.dingOrdBlock)
    {
        self.dingOrdBlock(YES, notifi);
    }
    
    [self clearDingOrdToken];
}

- (void)getDingOrdErrorHandler:(NSNotification*)notifi
{
    if (self.dingOrdBlock)
    {
        self.dingOrdBlock(NO, notifi);
    }
    
    [self clearDingOrdToken];
}

- (void)clearDingOrdToken
{
    if (_dingOrdToken != nil)
    {
        [_dingOrdToken removeObserver:self];
        _dingOrdToken = nil;
    }
    
    if (_dingOrdBlock)
    {
        _dingOrdBlock = nil;
    }
}

#pragma mark - IAP
- (void)downOrd:(void (^)(BOOL success,NSNotification *notifi))callBlock{
    self.downOrdBlock = callBlock;
    if (!_downOrdToken) {
        _downOrdToken = [[NnnbFacade getInstance] downOrd];
        
        [_downOrdToken addNotification:NOTIF_WP_HTTP_TOKEN_RESULT target:self selector:@selector(downOrdResultHandler:)];
        [_downOrdToken addNotification:NOTIF_WP_HTTP_TOKEN_ERROR target:self selector:@selector(downOrdErrorHandler:)];
    }
}

- (void)downOrdResultHandler:(NSNotification*)notifi {
    if (self.downOrdBlock) {
        self.downOrdBlock(YES, notifi);
    }
    [self clearDownOrdToken];
}

- (void)downOrdErrorHandler:(NSNotification*)notifi {
    if (self.downOrdBlock) {
        self.downOrdBlock(NO, notifi);
    }
    [self clearDownOrdToken];
}

- (void)clearDownOrdToken {
    if (_downOrdToken != nil){
        [_downOrdToken removeObserver:self];
        _downOrdToken = nil;
    }
    
    if (_downOrdBlock) {
        _downOrdBlock = nil;
    }
}

@end
