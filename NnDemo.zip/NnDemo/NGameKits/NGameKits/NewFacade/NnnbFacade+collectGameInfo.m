//
//  NnnbFacade+init.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade+collectGameInfo.h"

@implementation NnnbFacade (collectGameInfo)

- (NnnbAsyncToken *)collectGameInfoWithServerID:(NSInteger)serverID
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"loginlog"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"server_id" intValue:serverID]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(collectGameInfoResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)collectGameInfoResultHandler:(NSNumber*)tag
                            response:(NSDictionary*)response
                            userData:(id)userData
                               token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [self isResultSuccess:response])
    {
        NSLog(@"记录成功！");
    }
    else
    {
        NSLog(@"记录失败！");
    }
}

- (NnnbAsyncToken *)installActiveStatistics
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    
    [arrLoadData addObject:[self attributeWithKey:@"action" strValue:@"install"]];
    [arrLoadData addObject:[self attributeWithKey:@"appid" strValue:[DataManger getInstance].systemInfo.strAppId]];
    [arrLoadData addObject:[self attributeWithKey:@"agent_id" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"site_id" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"adid" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"imei" strValue:[DataManger getInstance].systemInfo.deviceCode]];
    [arrLoadData addObject:[self attributeWithKey:@"model" strValue:[NnnbCommons GetDevideModel]]];
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *strFlag = [NSString stringWithFormat:@"%@%@%@", [DataManger getInstance].systemInfo.strAppId, [DataManger getInstance].systemInfo.strAppKey,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"flag" strValue:[NnnbEncrypt md5:strFlag]]];
    
    return [self postData:arrLoadData
                      url:INSTALL_REPORT_URL
                 userData:nil
                   target:self
            resultHandler:@selector(installActiveStatisticsResultHandle:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)installActiveStatisticsResultHandle:(NSNumber*)tag
                                   response:(NSDictionary*)response
                                   userData:(id)userData
                                      token:(NnnbAsyncToken*)token
{
    if ((response != nil) && [NnnbCommons isNSDictionaryObject:response] && [self isResultSuccess:response]) {
        NSString *strKey = [NSString stringWithFormat:@"%@%@", NN_INSTALLACTIVEFLAG, [DataManger getInstance].systemInfo.strAppId];
        NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
        [keyChain kcSetObject:@"1" forKey:strKey];
        NSLog(@"安装激活！");
    }
}

- (NnnbAsyncToken *)submitGameData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    
    [arrLoadData addObject:[self attributeWithKey:@"action" strValue:@"UserInfo"]];
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *strFlag = [NSString stringWithFormat:@"%@%@%@", [[NSString stringWithFormat:@"%f",time] substringToIndex:10], [DataManger getInstance].systemInfo.strAppId, [DataManger getInstance].systemInfo.strAppKey];
    [arrLoadData addObject:[self attributeWithKey:@"flag" strValue:[NnnbEncrypt md5:strFlag]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"appid" strValue:[DataManger getInstance].systemInfo.strAppId]];
    
    [arrLoadData addObject:[self attributeWithKey:@"agent_id" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"site_id" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"userid" strValue:strUserID]];
    [arrLoadData addObject:[self attributeWithKey:@"dataType" strValue:strDataType]];
    [arrLoadData addObject:[self attributeWithKey:@"serverID" intValue:iServerID]];
    [arrLoadData addObject:[self attributeWithKey:@"serverName" strValue:strServerName]];
    [arrLoadData addObject:[self attributeWithKey:@"roleID" strValue:strRoleID]];
    [arrLoadData addObject:[self attributeWithKey:@"roleName" strValue:strRoleName]];
    [arrLoadData addObject:[self attributeWithKey:@"roleLevel" strValue:strRoleLevel]];
    [arrLoadData addObject:[self attributeWithKey:@"roleM" strValue:strJinNum]];
    
    NSString *signStr = [NSString stringWithFormat:@"%@%@",[DataManger getInstance].systemInfo.strAppId,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"sign" strValue:[NnnbEncrypt md5:signStr]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"imei" strValue:[DataManger getInstance].systemInfo.deviceCode]];
    [arrLoadData addObject:[self attributeWithKey:@"model" strValue:[NnnbCommons GetDevideModel]]];
    
    return [self postData:arrLoadData
                      url:INSTALL_REPORT_URL
                 userData:nil
                   target:self
            resultHandler:@selector(submitExtendDataStatisticsResultHandle:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)submitExtendDataStatisticsResultHandle:(NSNumber*)tag
                                      response:(NSDictionary*)response
                                      userData:(id)userData
                                         token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [self isResultSuccess:response])
    {
        NSLog(@"数据上报统计成功");
    }
    else
    {
        NSLog(@"数据上报统计失败");
    }
}

@end
