//
//  NnnbHttpRequester.m
//  iAroundHD
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbHttpRequester.h"
#import "NSObject+Additions.h"

@implementation NnnbHttpRequester

@synthesize tag=_tag;
@synthesize requestData=_requestData;
@synthesize url=_url;
@synthesize userData=_userData;
@synthesize asyncToken=_asyncToken;

-(id)initWithType:(TwHttpRequestType)type 
			  url:(NSString *)url 
	  requestData:(id)requestData 
		 userData:(id)userData 
		   target:(id)target 
	resultHandler:(SEL)resultHandler 
	 faultHandler:(SEL)faultHandler 
	cancelHandler:(SEL)cancelHandler
{
	if(self = [super init])
    {
		_url = [url retain];
		_requestData=[requestData retain];
		_userData=[userData retain];
		
		_target=target;
		_resultHandler=resultHandler;
		_faultHandler=faultHandler;
		_cancelHandler=cancelHandler;
		
		_asyncToken=[[NnnbAsyncToken alloc] initWithType:type];
	}
	return self;
}

-(void)dealloc
{
	[_asyncToken release];
	[_url release];
	[_requestData release];
	[_userData release];
	
	[super dealloc];
}

-(void)result:(NSDictionary *)response
{
	if (_resultHandler!=nil && [_target respondsToSelector:_resultHandler])
    {
		[_target performSelector:_resultHandler
                      withObject:[NSNumber numberWithInt:_tag]
                      withObject:response
                      withObject:_userData
                      withObject:_asyncToken];
	}
}

-(void)resultWithStr:(NSString *)response
{
	if (_resultHandler!=nil && [_target respondsToSelector:_resultHandler])
    {
		[_target performSelector:_resultHandler
                      withObject:[NSNumber numberWithInt:_tag]
                      withObject:response
                      withObject:_userData
                      withObject:_asyncToken];
	}
}

-(void)fault
{
	if (_faultHandler!=nil && [_target respondsToSelector:_faultHandler])
    {
		[_target performSelector:_faultHandler
                      withObject:[NSNumber numberWithInt:_tag]
                      withObject:_userData
                      withObject:_asyncToken];
	}
}

-(void)cancel
{
	if (_cancelHandler!=nil && [_target respondsToSelector:_cancelHandler])
    {
		[_target performSelector:_cancelHandler
                      withObject:[NSNumber numberWithInt:_tag]
                      withObject:_userData
                      withObject:_asyncToken];
	}
}

@end
