//
//  NnnbFacade+bandPhoneUpdateTimer.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade.h"

@interface NnnbFacade (bandPhoneUpdateTimer)

/****************************************************
 *  函数名:  bandPhoneUpdateTimerSetTimerPara
 *  功  能:  设置定时器参数
 *  入  参:
 *         (SEL)TimerHandler                定时器的回调函数
 *         (id)obj                          那个类调用的
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerSetTimerPara:(SEL)TimerHandler object:(id)obj;

/****************************************************
 *  函数名:  bandPhoneUpdateTimerStartTimer
 *  功  能:  验证码开始倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerStartTimer;

/****************************************************
 *  函数名:  bandPhoneUpdateTimerStopTimer
 *  功  能:  停止验证码倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerStopTimer;

@end
