//
//  NnnbFacade+init.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade.h"

@interface NnnbFacade (collectGameInfo)

/****************************************************
 *  函数名:  collectGameInfo
 *  功  能:  初始化协议
 *  入  参:
 *			 (id *) userData 				用户数据
 *  出  参:
 *  		网络令牌
 *  说  明:
 ****************************************************/
- (NnnbAsyncToken *)collectGameInfoWithServerID:(NSInteger)serverID;

//安装激活统计
- (NnnbAsyncToken *)installActiveStatistics;

//数据上报统计
- (NnnbAsyncToken *)submitGameData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum;

@end
