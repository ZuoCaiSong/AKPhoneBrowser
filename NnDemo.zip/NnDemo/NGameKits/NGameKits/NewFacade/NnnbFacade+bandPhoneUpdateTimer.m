//
//  NnnbFacade+bandPhoneUpdateTimer.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade+bandPhoneUpdateTimer.h"

@implementation NnnbFacade (bandPhoneUpdateTimer)
//倒计时
#define DEFAULT_TIME        1 //1秒
#define UPDATA_COUNT        40

/****************************************************
 *  函数名:  bandPhoneUpdateTimerSetTimerPara
 *  功  能:  设置定时器参数
 *  入  参:
 *         (SEL)TimerHandler                定时器的回调函数
 *         (id)obj                          那个类调用的
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerSetTimerPara:(SEL)TimerHandler object:(id)obj
{
    _bandPhoneFunctionCallBack = TimerHandler;
    _BandPhoneFunctionObj = obj;
}

/****************************************************
 *  函数名:  bandPhoneUpdateTimerStartTimer
 *  功  能:  验证码开始倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerStartTimer
{
    _bandPhoneUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:DEFAULT_TIME
                                                             target:self
                                                           selector:@selector(bandPhoneUpdateTimerHandler)
                                                           userInfo:nil
                                                            repeats:YES];
}

/****************************************************
 *  函数名:  bandPhoneUpdateTimerStopTimer
 *  功  能:  停止验证码倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerStopTimer
{
    if (_bandPhoneUpdateTimer != nil)
    {
        [_bandPhoneUpdateTimer invalidate];
        _bandPhoneUpdateTimer = nil;
    }
    
    _bandPhoneFunctionCallBack = nil;
    _BandPhoneFunctionObj = nil;
    _iBandPhoneUpdateCount = 0;
}

/****************************************************
 *  函数名:  bandPhoneUpdateTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)bandPhoneUpdateTimerHandler
{
    ++_iBandPhoneUpdateCount;
    
    if (_iBandPhoneUpdateCount >= UPDATA_COUNT)
    {
        //超时
        if (_BandPhoneFunctionObj != nil)
        {
            [_BandPhoneFunctionObj performSelector:_bandPhoneFunctionCallBack
                                        withObject:[NSNumber numberWithInteger:_iBandPhoneUpdateCount]];
        }
        
        _iBandPhoneUpdateCount = 0;
        
        //停止定时器
        [self bandPhoneUpdateTimerStopTimer];
    }
    else
    {
        if (_BandPhoneFunctionObj != nil)
        {
            [_BandPhoneFunctionObj performSelector:_bandPhoneFunctionCallBack
                                        withObject:[NSNumber numberWithInteger:_iBandPhoneUpdateCount]];
        }
    }
}

@end
