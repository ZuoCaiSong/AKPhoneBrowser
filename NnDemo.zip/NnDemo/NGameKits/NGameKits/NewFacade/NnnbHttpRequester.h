//
//  NnnbHttpRequester.h
//  iAroundHD
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NnnbHttpRequester : NSObject {
	//请求
	NSInteger _tag;
	//请求的数据
	id _requestData;
	//请求地址
	NSString *_url;
	//附加数据
	id _userData;
	//接收消息的目标
	id _target;
	//回复处理器
	SEL _resultHandler;
	//错误处理器
	SEL _faultHandler;
	//取消处理器
	SEL _cancelHandler;
	//异步令牌，用于监听接口返回状态
	NnnbAsyncToken *_asyncToken;
}

@property (nonatomic) NSInteger tag;
@property (nonatomic,retain,readonly) id requestData;
@property (nonatomic,retain,readonly) NSString *url;
@property (nonatomic,retain,readonly) id userData;
@property (nonatomic,retain,readonly) NnnbAsyncToken *asyncToken;

/**
	初始化请求
	@param type 请求类型
	@param url 请求地址
	@param requestData 请求数据
	@param userData 附加数据
	@param target 委托对象
	@param resultHandler 返回事件处理器
	@param faultHandler 错误事件处理器
	@param cancelHandler 取消事件处理器
	@returns 请求对象
 */
-(id)initWithType:(TwHttpRequestType)type
			  url:(NSString *)url
	   requestData:(id)requestData
		 userData:(id)userData
		   target:(id)target
	resultHandler:(SEL)resultHandler
	 faultHandler:(SEL)faultHandler
	cancelHandler:(SEL)cancelHandler;


//返回
-(void)result:(NSDictionary *)response;
//失败
-(void)fault;
//取消
-(void)cancel;

-(void)resultWithStr:(NSString *)response;

@end
