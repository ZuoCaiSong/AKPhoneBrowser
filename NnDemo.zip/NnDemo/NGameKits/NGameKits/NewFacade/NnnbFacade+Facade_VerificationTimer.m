//
//  NnnbFacade+Facade_VerificationTimer.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade+Facade_VerificationTimer.h"

@implementation NnnbFacade (Facade_VerificationTimer)
//倒计时
#define DEFAULT_TIME        1 //1秒
#define UPDATA_COUNT        40

/****************************************************
 *  函数名:  verificationSetTimerPara
 *  功  能:  设置定时器参数
 *  入  参:
 *         (SEL)verificationTimerHandler   定时器的回调函数
 *         (id)obj                         那个类调用的
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)verificationSetTimerPara:(SEL)TimerHandler object:(id)obj
{
    _functionCallBack = TimerHandler;
    _functionObj = obj;
}

/****************************************************
  *  函数名:  verificationStartTimer
  *  功  能:  验证码开始倒计时
  *  入  参: 
  *         无
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)verificationStartTimer
{   
    _findPswUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:DEFAULT_TIME
                                                           target:self
                                                         selector:@selector(verificationTimerHandler)
                                                         userInfo:nil
                                                          repeats:YES];
}

/****************************************************
  *  函数名:  verificationStopTimer
  *  功  能:  停止验证码倒计时
  *  入  参: 
  *         无
  *  出  参: 
  *  		无
  *  说  明: 
 ****************************************************/
- (void)verificationStopTimer
{
    if (_findPswUpdateTimer != nil)
    {
        [_findPswUpdateTimer invalidate];
        _findPswUpdateTimer = nil;
    }
    
    _functionCallBack = nil;
    _functionObj = nil;
    _iFindPswUpdateCount = 0;
}

/****************************************************
 *  函数名:  verificationTimerHandler
 *  功  能:  倒计时的定时器响应函数
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)verificationTimerHandler
{
    ++_iFindPswUpdateCount;
    
    if (_iFindPswUpdateCount >= UPDATA_COUNT)
    {
        //超时
        if (_functionObj != nil)
        {
            [_functionObj performSelector:_functionCallBack withObject:[NSNumber numberWithInteger:_iFindPswUpdateCount]];
        }
        
        _iFindPswUpdateCount = 0;
        
        //停止定时器
        [self verificationStopTimer];
    }
    else
    {
        if (_functionObj != nil)
        {
            [_functionObj performSelector:_functionCallBack withObject:[NSNumber numberWithInteger:_iFindPswUpdateCount]];
        }
    }
}


@end
