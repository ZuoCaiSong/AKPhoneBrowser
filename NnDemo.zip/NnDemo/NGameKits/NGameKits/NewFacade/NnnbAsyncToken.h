//
//  NnnbAsyncToken.h
//  iAroundHD
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NnnbErrorCode.h"

/**
	请求类型
 */
typedef enum
{
	TwHttpRequestTypeHttp,		/**< HTTP */
	TwHttpRequestTypeUpload,	/**< 上传 */
	TwHttpRequestTypeDownload	/**< 下载  */
}TwHttpRequestType;

@interface NnnbAsyncToken : NSObject
{
@private
	NSNotificationCenter *_notificationCenter;
	TwHttpRequestType _type;
}

/**
	初始化令牌
	@param type 请求类型
	@returns 令牌对象
 */
- (id)initWithType:(TwHttpRequestType)type;


//取消请求
-(void)cancel;

//排放通知
- (void) postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo;
//添加通知监听
- (void) addNotification:(NSString *)notificationName target:(id)target selector:(SEL)selector;
//删除通知监听
- (void) removeNotification:(NSString*)notificationName target:(id)target;
//删除所有监听
- (void) removeObserver:(id)target;

@end
