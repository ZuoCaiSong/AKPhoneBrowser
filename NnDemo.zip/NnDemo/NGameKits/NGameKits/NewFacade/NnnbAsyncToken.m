//
//  NnnbAsyncToken.m
//  iAroundHD
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbAsyncToken.h"

@implementation NnnbAsyncToken

- (id)initWithType:(TwHttpRequestType)type
{
	if (self = [super init])
    {
		_notificationCenter = [[NSNotificationCenter alloc] init];
		_type = type;
	}
	return self;
}

-(void)dealloc
{
	[_notificationCenter release];
	[super dealloc];
}

//取消请求
-(void)cancel
{
	switch (_type)
	{
		case TwHttpRequestTypeHttp:

			break;
		case TwHttpRequestTypeUpload:

			break;
		default:
			break;
	}
}

#pragma mark - Notification
- (void)postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo
{
	[_notificationCenter postNotificationName:name object:self userInfo:userInfo];
}

- (void)addNotification:(NSString *)notificationName target:(id)target selector:(SEL)selector
{
	[_notificationCenter addObserver:target selector:selector name:notificationName object:self];
}

- (void)removeNotification:(NSString*)notificationName target:(id)target
{
	[_notificationCenter removeObserver:target name:notificationName object:self];
}

- (void)removeObserver:(id)target
{
	[_notificationCenter removeObserver:target];
}

@end
