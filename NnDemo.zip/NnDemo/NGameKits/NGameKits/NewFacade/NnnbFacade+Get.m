//
//  NnnbFacade+Get.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade+Get.h"
#import "NSString+Game.h"

@implementation NnnbFacade (Get)

-(NnnbAsyncToken*)fuBy:(ChValueType)value
                  bill:(double)iBill
               subject:(CGFloat)fSubject
              userData:(id)userData
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    
    if (value== ewChong )
    {
        [arrLoadData addObject:[self attributeWithKey:@"op" strValue:@"goi_w_htm"]];
    }
    else if (value == ezChong)
    {
        [arrLoadData addObject:[self attributeWithKey:@"op" strValue:@"goi_w_ym"]];
    }
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *signStr = [NSString stringWithFormat:@"%@%@",[DataManger getInstance].systemInfo.strAppKey,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"sign" strValue:[NnnbEncrypt md5:signStr]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"os" strValue:@"ios"]];
    [arrLoadData addObject:[self attributeWithKey:@"gmi" strValue:_dataManger.systemInfo.strAppId]];
    [arrLoadData addObject:[self attributeWithKey:@"agi" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"sti" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"oiM" floatValue:iBill]];
    [arrLoadData addObject:[self attributeWithKey:@"uri" longValue:[DataManger getInstance].currentUserInfo.lUserId]];
    [arrLoadData addObject:[self attributeWithKey:@"urN" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"rli" strValue:[CommonData GetCommonDataInstance].roleID]];
    [arrLoadData addObject:[self attributeWithKey:@"rlN" strValue:[CommonData GetCommonDataInstance].roleName]];
    [arrLoadData addObject:[self attributeWithKey:@"srvri" intValue:[CommonData GetCommonDataInstance].defaultServerId]];
    [arrLoadData addObject:[self attributeWithKey:@"srvrN" strValue:[CommonData GetCommonDataInstance].strServerName]];
    [arrLoadData addObject:[self attributeWithKey:@"ext" strValue:[CommonData GetCommonDataInstance].strExtInfo]];
    [arrLoadData addObject:[self attributeWithKey:@"prdti" strValue:[CommonData GetCommonDataInstance].strProductId]];
    [arrLoadData addObject:[self attributeWithKey:@"prdtN" strValue:[CommonData GetCommonDataInstance].strProductName]];
    [arrLoadData addObject:[self attributeWithKey:@"prdtD" strValue:[CommonData GetCommonDataInstance].strProductDes]];
    
    return [self postData:arrLoadData
                      url:PM_URL
                 userData:userData
                   target:self
            resultHandler:@selector(PmResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)PmResultHandler:(NSNumber*)tag
               response:(id)response
               userData:(id)userData
                  token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [self isResultSuccess:response])
    {
        [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                       userInfo:response];
    }
    else
    {
        [self dealErrorResponse:tag response:response userData:userData token:token];
    }
}

-(NnnbAsyncToken *)downOrd
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    [arrLoadData addObject:[self attributeWithKey:@"op" strValue:@"get_oi_pg"]];
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *signStr = [NSString stringWithFormat:@"%@%@",[DataManger getInstance].systemInfo.strAppKey,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"sign" strValue:[NnnbEncrypt md5:signStr]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"os" strValue:@"ios"]];
    [arrLoadData addObject:[self attributeWithKey:@"gmi" strValue:[DataManger getInstance].systemInfo.strAppId]];
    [arrLoadData addObject:[self attributeWithKey:@"agi" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"sti" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"oiM" intValue:[CommonData GetCommonDataInstance].ijin]];
    [arrLoadData addObject:[self attributeWithKey:@"uri" longValue:[DataManger getInstance].currentUserInfo.lUserId]];
    [arrLoadData addObject:[self attributeWithKey:@"urN" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"rli" strValue:[CommonData GetCommonDataInstance].roleID]];
    [arrLoadData addObject:[self attributeWithKey:@"rlN" strValue:[CommonData GetCommonDataInstance].roleName]];
    [arrLoadData addObject:[self attributeWithKey:@"srvri" intValue:[CommonData GetCommonDataInstance].defaultServerId]];
    [arrLoadData addObject:[self attributeWithKey:@"srvrN" strValue:[CommonData GetCommonDataInstance].strServerName]];
    [arrLoadData addObject:[self attributeWithKey:@"ext" strValue:[CommonData GetCommonDataInstance].strExtInfo]];
    [arrLoadData addObject:[self attributeWithKey:@"prdti" strValue:[CommonData GetCommonDataInstance].strProductId]];
    [arrLoadData addObject:[self attributeWithKey:@"prdtN" strValue:[CommonData GetCommonDataInstance].strProductName]];
    [arrLoadData addObject:[self attributeWithKey:@"prdtD" strValue:[CommonData GetCommonDataInstance].strProductDes]];
    [arrLoadData addObject:[self attributeWithKey:@"pgPrdti" strValue:[CommonData GetCommonDataInstance].strProductId]];
    
    return [self postData:arrLoadData
                      url:PM_URL
                 userData:nil
                   target:self
            resultHandler:@selector(IoResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)IoResultHandler:(NSNumber*)tag
               response:(id)response
               userData:(id)userData
                  token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) &&[self isResultSuccess:response])
    {
        [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT
                       userInfo:response];
    }
    else
    {
        [self dealErrorResponse:tag response:response userData:userData token:token];
    }
}

@end
