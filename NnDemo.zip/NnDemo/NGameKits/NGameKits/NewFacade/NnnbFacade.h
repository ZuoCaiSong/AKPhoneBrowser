//
//  NnnbFacade.h
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommunicatorFactory.h"
#import "NnnbHttpRequester.h"
#import "DataManger.h"

@interface NnnbFacade : NSObject
{
    id<ICommunicator>   _comm;
    DataManger        *_dataManger;
    
    NSMutableArray      *_httpRequesterPool;            //HTTP请求缓冲池
    
    NSNotificationCenter    *_notifactionCenter;
    
    //忘记密码的验证码倒计时
    NSTimer                     *_findPswUpdateTimer;
    NSInteger                   _iFindPswUpdateCount;
    SEL                         _functionCallBack;
    id                          _functionObj;
    
    //绑定的验证码倒计时
    NSTimer                     *_bandPhoneUpdateTimer;
    NSInteger                   _iBandPhoneUpdateCount;
    SEL                         _bandPhoneFunctionCallBack;
    id                          _BandPhoneFunctionObj;
}

+(NnnbFacade*)getInstance;

#pragma mark - 通知
//排放通知
- (void)postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo;
//添加通知监听
- (void)addNotification:(NSString *)notificationName target:(id)target selector:(SEL)selector;
//删除通知监听
- (void)removeNotification:(NSString*)notificationName target:(id)target;
//删除所有监听
- (void)removeObserver:(id)target;

#pragma mark - 添加参数方式
-(NSArray*)attributeWithKey:(NSString*)strKey strValue:(NSString*)strValue;
-(NSArray*)attributeWithKey:(NSString*)strKey intValue:(NSInteger)iValue;
-(NSArray*)attributeWithKey:(NSString*)strKey floatValue:(double)fValue;
-(NSArray*)attributeWithKey:(NSString*)strKey longValue:(long)lValue;

#pragma mark - 公共参数
- (NSMutableArray *)setPublicParameters;

#pragma mark - 网络请求方式
-(NnnbAsyncToken *)postData:(NSArray *)data
                        url:(NSString*)strUrl
                   userData:(id)userData
                     target:(id)target
              resultHandler:(SEL)resultHandler
               faultHandler:(SEL)faultHandler
              cancelHandler:(SEL)cancelHandler;

- (NnnbAsyncToken *)getData:(NSArray *)data
                        url:(NSString *)strUrl
                   userData:(id)userData
                     target:(id)target
              resultHandler:(SEL)resultHandler
               faultHandler:(SEL)faultHandler
              cancelHandler:(SEL)cancelHandler;

#pragma mark - 网络请求后处理方式
- (void)httpTokenFaultHandler:(NSNumber *)tag
                     userData:(id)userData
                        token:(NnnbAsyncToken *)token;

- (void)httpTokenCancelHandler:(NSNumber *)tag
                      userData:(id)userData
                         token:(NnnbAsyncToken *)token;

-(BOOL)isResultSuccess:(NSDictionary*)response;

- (void)dealErrorResponse:(NSNumber *)tag
                 response:(NSDictionary *)response
                 userData:(id)userData
                    token:(NnnbAsyncToken *)token;

#pragma mark - 安装激活统计
- (void)nnInstallActive;

#pragma mark - 获取配置
- (NnnbAsyncToken *)getConfig;

#pragma mark - 登录
//账号登录
-(NnnbAsyncToken*)loginWithUserName:(NSString*)userName Password:(NSString*)password;

//获取手机登录的验证码
-(NnnbAsyncToken*)getVerifyCodeForPhoneLogin:(NSString*)strPhone;

//手机登录
-(NnnbAsyncToken*)phoneLoginWithPhone:(NSString *)strPhone message:(NSString *)code;

#pragma mark - 注册
//获取注册账号
-(NnnbAsyncToken*)getRegistAccount;

//账号注册
-(NnnbAsyncToken*)registAccountWithUserName:(NSString*)userName Password:(NSString*)password;

//快速注册
-(NnnbAsyncToken*)fastRegistAccount;

#pragma mark - 忘记密码
//获取忘记密码的验证码
-(NnnbAsyncToken*)getVerifyCodeforForgetPswWithUser:(NSString*)strAccount Phone:(NSString*)strPhoneNum;

//确认按钮
-(NnnbAsyncToken*)confirmVerifyCode:(NSString*)strCode
                            account:(NSString*)strAccount
                              phone:(NSString*)strPhoneNum;

//确认重置密码
-(NnnbAsyncToken*)modifyPasswordWithCode:(NSString*)strCode
                                 account:(NSString*)strAccount
                                   phone:(NSString*)strPhoneNum
                                password:(NSString*)strNewPsw;

#pragma mark - 修改密码
-(NnnbAsyncToken*)modifyPasswordOldPswWithCode:(NSString*)strCode
                                      password:(NSString*)strNewPsw;

#pragma mark - 绑定手机
//获取绑定手机的验证码
-(NnnbAsyncToken*)getVerifyCodeForBindPhoneWithUser:(NSString*)strAccount
                                              phone:(NSString*)strPhoneNum;

//确认绑定手机
-(NnnbAsyncToken*)bindPhoneWithPhoneNum:(NSString*)strPhoneNum
                                   code:(NSString*)strCode;

#pragma mark - 实名认证
-(NnnbAsyncToken*)checkPersonWithRealName:(NSString *)realName
                                 personID:(NSString *)personId;

#pragma mark - 公告
//获取公告数据,type = 1返回公告数据，其他则不返回
-(NnnbAsyncToken*)getPublicNotDataWithType:(NSInteger)type;

//上报已读公告
-(NnnbAsyncToken*)reportPublicIsReadWithNoticeID:(NSInteger)noticeID;

#pragma mark - 理煲
//获取列表数据
-(NnnbAsyncToken*)getPackageListData;

//获取理煲码
-(NnnbAsyncToken*)getPackageCodeDataWithCodeType:(NSInteger)codeStr hdStr:(NSString *)hdstr;

#pragma mark - 相关记录
-(NnnbAsyncToken*)getTopUpRecordDataWithDate:(NSString *)dateStr;

-(NnnbAsyncToken*)getVersionRequest;

- (NnnbAsyncToken*)deleteTopUpRecord:(NSString *)recordId;

#pragma mark - 账号升级
//验证是否是随机账号
-(NnnbAsyncToken *)isRandomAccountOrNot;

-(NnnbAsyncToken *)getLevelUpVerifyCodeWithName:(NSString *)nameStr;

-(NnnbAsyncToken *)confirmLevelUpWithName:(NSString *)nameStr Pwd:(NSString *)pwdStr Code:(NSString *)codeStr;

#pragma mark - 采集游戏数据
- (void)collectGameData:(NSInteger)iServerID;

#pragma mark - 数据上报统计
-(void)submitExtendData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum;

@end
