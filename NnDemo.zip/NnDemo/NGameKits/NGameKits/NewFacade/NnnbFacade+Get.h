//
//  NnnbFacade+Get.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade.h"
#import "DataDefine.h"


@interface NnnbFacade (Get)

-(NnnbAsyncToken*)fuBy:(ChValueType)value
                 bill:(double)iBill
              subject:(CGFloat)fSubject
             userData:(id)userData;

-(NnnbAsyncToken *)downOrd;
@end
