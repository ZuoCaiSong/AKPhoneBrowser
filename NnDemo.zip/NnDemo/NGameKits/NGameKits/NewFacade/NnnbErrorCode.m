//
//  NnnbErrorCode.m
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbErrorCode.h"

@implementation NnnbErrorCode

+(NSString*)getErrorWithRseponse:(NSDictionary *)response
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [response objectForKey:@"msg"])
    {
        return [response objectForKey:@"msg"];
    }
    else
    {
        return @"未知错误(请检测网络是否异常)!";
    }
}

@end
