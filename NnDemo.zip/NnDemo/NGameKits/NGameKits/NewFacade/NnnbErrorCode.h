//
//  NnnbErrorCode.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import <Foundation/Foundation.h>

//错误码
@interface NnnbErrorCode : NSObject

+(NSString*)getErrorWithRseponse:(NSDictionary *)response;

@end
