//
//  NnnbFacade.m
//
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade.h"
#import "NotificationDefinition.h"
#import "NnnbFacade+Facade_VerificationTimer.h"
#import "NnnbFacade+bandPhoneUpdateTimer.h"
#import "NnnbFacade+collectGameInfo.h"
#import "NSString+Game.h"

static NnnbFacade* _sNnnbFacadeInstance = nil;
#define TW_INTERNET_ERROR -5679

@interface NnnbFacade(private)

//判断是否请求成功
//PS:非用户接口，请勿调用
- (BOOL)isResultSuccess:(NSDictionary*)response;

//根据tag获取请求参数
//PS:非用户接口，请勿调用
- (id)getHTTPRequestParametersByTag:(NSInteger)tag;

//根据tag获取请求信息
//PS:非用户接口，请勿调用
- (NnnbHttpRequester *)getHTTPRequestInfoByTag:(NSInteger)tag;

//根据tag删除请求信息
//PS:非用户接口，请勿调用
- (void)removeHTTPRequestInfoByTag:(NSInteger)tag;

//取消请求
//PS:非用户接口，请勿调用
- (void)cancelHTTPRequest:(NnnbAsyncToken *)token;

-(void)activeResultHandler:(NSNotification*)notif;
-(void)activeErrorHandler:(NSNotification*)notif;
-(NSArray*)attributeWithKey:(NSString*)strKey floatValue:(double)fValue;

@end

@implementation NnnbFacade

+(NnnbFacade*)getInstance
{
    @synchronized(self)
    {
        if (_sNnnbFacadeInstance == nil)
        {
            _sNnnbFacadeInstance = [[NnnbFacade alloc]init];
        }
    }
    
    return _sNnnbFacadeInstance;
}

-(id)init
{
    self = [super init];
    if (self != nil)
    {
        _httpRequesterPool = [[NSMutableArray alloc]initWithCapacity:0];
        
        _dataManger = [DataManger getInstance];
        _comm = [CommunicatorFactory getCommunicator];
        
        _notifactionCenter = [[NSNotificationCenter alloc]init];
        
        [_comm addNotificationTarget:self
                            selector:@selector(onHttpPostDone:)
                    notificationName:NOTIF_HTTP_POST_DONE];
        
        [_comm addNotificationTarget:self
                            selector:@selector(onHttpPostError:)
                    notificationName:NOTIF_HTTP_POST_ERROR];
        
        [_comm addNotificationTarget:self
                            selector:@selector(onHttpPostCancel:)
                    notificationName:NOTIF_HTTP_POST_CANCEL];
    }
    
    return self;
}

-(void)dealloc
{
    //删除所有监听
    [_comm removeAllNotification:self];
    
    [_notifactionCenter release];
    
    _dataManger = nil;
    _comm = nil;
    
    [_httpRequesterPool release];
    
    //停止定时器
    [self verificationStopTimer];
    [self bandPhoneUpdateTimerStopTimer];
    
    [super dealloc];
}

#pragma mark - 通知
- (void) postNotification:(NSString *)name userInfo:(NSDictionary *)userInfo
{
    [_notifactionCenter postNotificationName:name object:self userInfo:userInfo];
}

- (void) addNotification:(NSString *)notificationName target:(id)target selector:(SEL)selector
{
    [_notifactionCenter addObserver:target selector:selector name:notificationName object:self];
}

- (void) removeNotification:(NSString*)notificationName target:(id)target
{
    [_notifactionCenter removeObserver:target name:notificationName object:self];
}

-(void)removeObserver:(id)target
{
    [_notifactionCenter removeObserver:target];
}

#pragma mark - 根据tag进行请求处理
-(id)getHTTPRequestParametersByTag:(NSInteger)tag
{
    NnnbHttpRequester *requester=[self getHTTPRequestInfoByTag:tag];
    if (requester!=nil)
    {
        return requester.requestData;
    }
    return nil;
}

-(NnnbHttpRequester *)getHTTPRequestInfoByTag:(NSInteger)tag
{
    for (NSInteger i=0; i<[_httpRequesterPool count]; i++)
    {
        NnnbHttpRequester *info=[_httpRequesterPool objectAtIndex:i];
        if (info.tag==tag)
        {
            return info;
        }
    }
    return nil;
}

-(void)removeHTTPRequestInfoByTag:(NSInteger)tag
{
    for (NSInteger i=0; i<[_httpRequesterPool count]; i++)
    {
        NnnbHttpRequester *info=[_httpRequesterPool objectAtIndex:i];
        if (info.tag==tag)
        {
            [_httpRequesterPool removeObjectAtIndex:i];
            break;
        }
    }
}

-(void)cancelHTTPRequest:(NnnbAsyncToken *)token
{
    for (NSInteger i = 0; i < [_httpRequesterPool count]; i++)
    {
        NnnbHttpRequester *info=[_httpRequesterPool objectAtIndex:i];
        if (info.asyncToken==token)
        {
            [_comm cancelHttpRequest:info.tag];
            break;
        }
    }
}

#pragma mark - 添加参数方式
-(NSArray*)attributeWithKey:(NSString*)strKey strValue:(NSString*)strValue
{
    if ([strKey length] > 0)
    {
        return [NSArray arrayWithObjects:strKey, (strValue != nil ? strValue : @""), nil];
    }
    else
    {
        return [NSArray array];
    }
}

-(NSArray*)attributeWithKey:(NSString*)strKey intValue:(NSInteger)iValue
{
    if ([strKey length] > 0)
    {
        NSString* strVal = [NSString stringWithFormat:@"%ld", (long)iValue];
        return [NSArray arrayWithObjects:strKey, strVal, nil];
    }
    else
    {
        return [NSArray array];
    }
}

-(NSArray*)attributeWithKey:(NSString*)strKey floatValue:(double)fValue
{
    if ([strKey length] > 0)
    {
        NSString* strVal = [NSString stringWithFormat:@"%.00f", fValue];
        return [NSArray arrayWithObjects:strKey, strVal, nil];
    }
    else
    {
        return [NSArray array];
    }
}

-(NSArray*)attributeWithKey:(NSString*)strKey longValue:(long)lValue
{
    if ([strKey length] > 0)
    {
        NSString* strVal = [NSString stringWithFormat:@"%ld", lValue];
        return [NSArray arrayWithObjects:strKey, strVal, nil];
    }
    else
    {
        return [NSArray array];
    }
}

#pragma mark - 网络请求方式
-(NnnbAsyncToken *)postData:(NSArray *)data
                        url:(NSString*)strUrl
                   userData:(id)userData
                     target:(id)target
              resultHandler:(SEL)resultHandler
               faultHandler:(SEL)faultHandler
              cancelHandler:(SEL)cancelHandler
{
    NSInteger tag = [_comm postData:data ToServer:strUrl];
    
    NnnbHttpRequester *requestInfo = [[NnnbHttpRequester alloc] initWithType:TwHttpRequestTypeHttp
                                                                         url:strUrl
                                                                 requestData:data
                                                                    userData:userData
                                                                      target:target
                                                               resultHandler:resultHandler
                                                                faultHandler:faultHandler
                                                               cancelHandler:cancelHandler];
    requestInfo.tag = tag;
    [_httpRequesterPool addObject:requestInfo];
    [requestInfo release];
    
    return [[requestInfo.asyncToken retain] autorelease];
}

- (NnnbAsyncToken *)getData:(NSArray *)data
                        url:(NSString *)strUrl
                   userData:(id)userData
                     target:(id)target
              resultHandler:(SEL)resultHandler
               faultHandler:(SEL)faultHandler
              cancelHandler:(SEL)cancelHandler
{
    
    NSInteger tag = [_comm requestServerByGetMethod2:data ToServer:strUrl];
    
    NnnbHttpRequester *requestInfo = [[NnnbHttpRequester alloc] initWithType:TwHttpRequestTypeHttp
                                                                         url:strUrl
                                                                 requestData:data
                                                                    userData:userData
                                                                      target:target
                                                               resultHandler:resultHandler
                                                                faultHandler:faultHandler
                                                               cancelHandler:cancelHandler];
    
    requestInfo.tag = tag;
    [_httpRequesterPool addObject:requestInfo];
    
    return requestInfo.asyncToken;
    
}

#pragma mark - 网络请求后通用处理
- (void)onHttpPostDone:(NSNotification *)notif
{
    NSDictionary* response = [notif.userInfo objectForKey:@"response"];
    
    //****************处理非JSON格式数据
    if ([[notif.userInfo objectForKey:@"response"] isKindOfClass:[NSString class]]) {
        NSInteger tag = [[notif.userInfo objectForKey:@"tag"]integerValue];
        
        NSString* responseStr = [notif.userInfo objectForKey:@"response"];
        
        NnnbHttpRequester *info=[self getHTTPRequestInfoByTag:tag];
        if (info != nil)
        {
            [info resultWithStr:responseStr];
            //删除请求
            [self removeHTTPRequestInfoByTag:tag];
        }
    }
    //********************************
    else
    {
        NSInteger tag = [[notif.userInfo objectForKey:@"tag"]integerValue];
        
        NnnbHttpRequester *info=[self getHTTPRequestInfoByTag:tag];
        if (info != nil)
        {
            [info result:response];
            //删除请求
            [self removeHTTPRequestInfoByTag:tag];
        }
    }
}

-(void)onHttpPostError1:(NSNotification *)notif
{
    NSInteger tag=[(NSNumber *)[[notif userInfo] objectForKey:@"tag"] intValue];
    
    NnnbHttpRequester *info=[self getHTTPRequestInfoByTag:tag];
    if (info!=nil)
    {
        [info fault];
        [self removeHTTPRequestInfoByTag:tag];
    }
}

-(void)onHttpPostError:(NSNotification *)notif
{
    [self performSelector:@selector(onHttpPostError1:) withObject:notif afterDelay:0.5];
}

-(void)onHttpPostCancel:(NSNotification *)notif
{
    NSInteger tag=[(NSNumber *)[[notif userInfo] objectForKey:@"tag"] intValue];
    
    NnnbHttpRequester *info = [self getHTTPRequestInfoByTag:tag];
    if (info!=nil)
    {
        [info cancel];
        [self removeHTTPRequestInfoByTag:tag];
    }
}

- (void)dealErrorResponse:(NSNumber *)tag
                 response:(NSDictionary *)response
                 userData:(id)userData
                    token:(NnnbAsyncToken *)token
{
    NSNumber *errorNumber = [[NSNumber alloc] init];
    NSString *errorString = [NSString new];
    
    if ((response != nil) && [NnnbCommons isNSDictionaryObject:response]) {
        id value = [response objectForKey:@"error"];
        errorNumber = [NSNumber numberWithInt:[value intValue]];
        errorString = [NnnbErrorCode getErrorWithRseponse:response];
    } else {
        errorNumber = [NSNumber numberWithInt:TW_INTERNET_ERROR];
        errorString = [NnnbErrorCode getErrorWithRseponse:response];
    }
    
    [token postNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                   userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                             errorString,
                             KEY_ERROR_TEXT,
                             errorNumber,
                             KEY_ERROR_CODE,
                             userData,
                             KEY_USER_DATA,
                             nil]];
}

#pragma mark - 网络请求后的结果通用处理
- (void)httpTokenSuccessHandler:(NSNumber*)tag
                       response:(NSDictionary *)response
                       userData:(id)userData
                          token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [self isResultSuccess:response])
    {
        [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT userInfo:response];
    }
    else
    {
        [self dealErrorResponse:tag response:response userData:userData token:token];
    }
}

- (void)httpTokenFaultHandler:(NSNumber *)tag
                     userData:(id)userData
                        token:(NnnbAsyncToken *)token
{
    [token postNotification:NOTIF_WP_HTTP_TOKEN_ERROR
                   userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                             @"网络不可用，请检查网络",
                             KEY_ERROR_TEXT,
                             userData,
                             KEY_USER_DATA,
                             nil]];
}

- (void)httpTokenCancelHandler:(NSNumber *)tag
                      userData:(id)userData
                         token:(NnnbAsyncToken *)token
{
    [token postNotification:NOTIF_WP_HTTP_TOKEN_CANCEL
                   userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                             userData,
                             KEY_USER_DATA,
                             nil]];
}

#pragma mark - 是否请求成功的通用处理方法
-(BOOL)isResultSuccess:(NSDictionary*)response
{
    int status = [(NSNumber *)[response objectForKey:@"ret"] intValue];
    return status == 1 ? YES : NO;
}

#pragma mark - 安装激活统计
- (void)nnInstallActive
{
    NSString *strKey = [NSString stringWithFormat:@"%@%@", NN_INSTALLACTIVEFLAG, [DataManger getInstance].systemInfo.strAppId];
    NnnbKeyChain *keyChain = [NnnbKeyChain standardKeyChain];
    NSString *strInstallAC = [keyChain kcObjectForKey:strKey];
    if (strInstallAC && [strInstallAC isEqualToString:@"1"]) {
        return;
    }
    
    [self installActiveStatistics];
}

#pragma mark - 公共参数
- (NSMutableArray *)setPublicParameters
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    
    [arrLoadData addObject:[self attributeWithKey:@"appid" strValue:[DataManger getInstance].systemInfo.strAppId]];
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *signStr = [NSString stringWithFormat:@"%@%@",[DataManger getInstance].systemInfo.strAppKey,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"sign" strValue:[NnnbEncrypt md5:signStr]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"os" strValue:@"ios"]];
    [arrLoadData addObject:[self attributeWithKey:@"version" strValue:NN_CURRENT_VERSION]];
    [arrLoadData addObject:[self attributeWithKey:@"devicebrand" strValue:@"Apple"]];
    [arrLoadData addObject:[self attributeWithKey:@"model" strValue:[NnnbCommons GetDevideModel]]];
    [arrLoadData addObject:[self attributeWithKey:@"system_version" strValue:[UIDevice currentDevice].systemVersion]];
    [arrLoadData addObject:[self attributeWithKey:@"mnos" strValue:[NnnbCommons GetInternetStatus]]];
    [arrLoadData addObject:[self attributeWithKey:@"mtype" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"uuid" strValue:[DataManger getInstance].systemInfo.deviceCode]];
    
    NSString *version = [[[NSBundle mainBundle]infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [arrLoadData addObject:[self attributeWithKey:@"app_version" strValue:version]];
    
    return arrLoadData;
}

#pragma mark - 获取配置
- (NnnbAsyncToken *)getConfig
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"update"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 登录
//账号登录
-(NnnbAsyncToken*)loginWithUserName:(NSString*)userName Password:(NSString*)password
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"login"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:userName]];
    [arrLoadData addObject:[self attributeWithKey:@"pwd" strValue:password]];
    [arrLoadData addObject:[self attributeWithKey:@"type" strValue:@"1"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(loginResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//获取手机登录的验证码
-(NnnbAsyncToken*)getVerifyCodeForPhoneLogin:(NSString*)strPhone{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"get_login_phone_code"]];
    [arrLoadData addObject:[self attributeWithKey:@"phone" strValue:strPhone]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//手机登录
-(NnnbAsyncToken*)phoneLoginWithPhone:(NSString *)strPhone message:(NSString *)code{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"check_login_phone_code"]];
    [arrLoadData addObject:[self attributeWithKey:@"code" strValue:code]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(loginResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)loginResultHandler:(NSNumber*)tag
                  response:(NSDictionary*)response
                  userData:(id)userData
                     token:(NnnbAsyncToken*)token
{
    //再次确认
    [self nnInstallActive];
    
    if ((response != nil) && [NnnbCommons isNSDictionaryObject:response] && [self isResultSuccess:response])
    {
        _dataManger.systemInfo.strSessionId = [response objectForKey:@"sessionid"];
        [_dataManger.currentUserInfo importWithServerData:response];
        
        [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT userInfo:response];
    }
    else
    {
        [self dealErrorResponse:tag response:response userData:userData token:token];
    }
}

#pragma mark - 注册
//获取注册账号
-(NnnbAsyncToken*)getRegistAccount{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"get_reg_user"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//账号注册
-(NnnbAsyncToken*)registAccountWithUserName:(NSString*)userName Password:(NSString*)password
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"reg"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:userName]];
    [arrLoadData addObject:[self attributeWithKey:@"pwd" strValue:password]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(registSuccessResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//快速注册
-(NnnbAsyncToken*)fastRegistAccount
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"fastreg"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(registSuccessResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)registSuccessResultHandler:(NSNumber*)tag
                          response:(NSDictionary *)response
                          userData:(id)userData
                             token:(NnnbAsyncToken*)token
{
    if ((response != nil) && ([NnnbCommons isNSDictionaryObject:response]) && [self isResultSuccess:response])
    {
        _dataManger.systemInfo.strSessionId = [response objectForKey:@"sessionid"];
        [_dataManger.currentUserInfo importWithServerData:response];
        
        //保存到本地
        NSUserDefaults *userDef = [NSUserDefaults standardUserDefaults];
        //新注册的用户清除绑定手机的
        [userDef setBool:NO forKey:kBingFlag];
        [userDef synchronize];
        
        [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT userInfo:response];
        
        NSDictionary* dicUserInfo  = [NSDictionary dictionaryWithObjectsAndKeys:
                                      [response objectForKey:@"uid"], KEY_USER_ID, [response objectForKey:@"sessionid"], KEY_LOGIN_SIGN,
                                      nil];
        
        [self performSelector:@selector(postRegisterMsg:)
                   withObject:dicUserInfo
                   afterDelay:0.6];
    }
    else
    {
        [self dealErrorResponse:tag response:response userData:userData token:token];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_REGISTER_FAIL
                                                            object:nil];
    }
}

//抛出注册成功的消息
-(void)postRegisterMsg:(NSDictionary*) dicUserInfo
{
    [[NSNotificationCenter defaultCenter] postNotificationName:NN_NOTIF_REGISTER_SUCCESS object:nil userInfo:dicUserInfo];
}

#pragma mark - 忘记密码
//获取忘记密码的验证码
-(NnnbAsyncToken*)getVerifyCodeforForgetPswWithUser:(NSString*)strAccount Phone:(NSString*)strPhoneNum
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"getpwd_mobile_code"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:strAccount]];
    [arrLoadData addObject:[self attributeWithKey:@"phone" strValue:strPhoneNum]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//确认按钮
-(NnnbAsyncToken*)confirmVerifyCode:(NSString*)strCode
                            account:(NSString*)strAccount
                              phone:(NSString*)strPhoneNum
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"getpwd_mobile_check"]];
    [arrLoadData addObject:[self attributeWithKey:@"code" strValue:strCode]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
    
}

//确认重置密码
-(NnnbAsyncToken*)modifyPasswordWithCode:(NSString*)strCode
                                 account:(NSString*)strAccount
                                   phone:(NSString*)strPhoneNum
                                password:(NSString*)strNewPsw
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"getpwd_mobile_reset"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:strAccount]];
    [arrLoadData addObject:[self attributeWithKey:@"newpwd" strValue:strNewPsw]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 修改密码
-(NnnbAsyncToken*)modifyPasswordOldPswWithCode:(NSString*)strPldPsw
                                      password:(NSString*)strNewPsw
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"password"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"pwd" strValue:strPldPsw]];
    [arrLoadData addObject:[self attributeWithKey:@"newpwd" strValue:strNewPsw]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 绑定手机
//获取绑定手机的验证码
-(NnnbAsyncToken*)getVerifyCodeForBindPhoneWithUser:(NSString*)strAccount
                                              phone:(NSString*)strPhoneNum
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"bind_phone_code"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:strAccount]];
    [arrLoadData addObject:[self attributeWithKey:@"phone" strValue:strPhoneNum]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//确认绑定手机
-(NnnbAsyncToken*)bindPhoneWithPhoneNum:(NSString*)strPhoneNum
                                   code:(NSString*)strCode{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"bind_phone"]];
    [arrLoadData addObject:[self attributeWithKey:@"code" strValue:strCode]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 实名认证
-(NnnbAsyncToken*)checkPersonWithRealName:(NSString *)realName
                                 personID:(NSString *)personId{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"setFcm"]];
    [arrLoadData addObject:[self attributeWithKey:@"truename" strValue:realName]];
    [arrLoadData addObject:[self attributeWithKey:@"idcard" strValue:personId]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 公告
//获取公告数据,type = 1返回公告数据，其他则不返回
-(NnnbAsyncToken*)getPublicNotDataWithType:(NSInteger)type{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"get_gg"]];
    [arrLoadData addObject:[self attributeWithKey:@"type" intValue:type]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//上报已读公告
-(NnnbAsyncToken*)reportPublicIsReadWithNoticeID:(NSInteger)noticeID{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"notice_read"]];
    [arrLoadData addObject:[self attributeWithKey:@"notice_id" intValue:noticeID]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 理煲
//获取列表数据
-(NnnbAsyncToken*)getPackageListData{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"gamecode"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

//获取理煲码
-(NnnbAsyncToken*)getPackageCodeDataWithCodeType:(NSInteger)codeStr hdStr:(NSString *)hdstr{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"get_gamecode"]];
    [arrLoadData addObject:[self attributeWithKey:@"hd" strValue:hdstr]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 相关记录
- (NnnbAsyncToken*)deleteTopUpRecord:(NSString *)recordId {
    NSMutableArray *arrLoadData = [self setPublicParameters];

    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"del_yb_ord"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"oi" strValue:recordId]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

-(NnnbAsyncToken*)getTopUpRecordDataWithDate:(NSString *)dateStr{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"get_yb_list"]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:_dataManger.currentUserInfo.strUserName]];
    [arrLoadData addObject:[self attributeWithKey:@"date" strValue:dateStr]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

-(NnnbAsyncToken*)getVersionRequest
{
    NSMutableArray *arrLoadData = [NSMutableArray array];
    
    [arrLoadData addObject:[self attributeWithKey:@"op" strValue:@"cz"]];
    
    NSTimeInterval time = [[NSDate date]timeIntervalSince1970];
    [arrLoadData addObject:[self attributeWithKey:@"time" longValue:time]];
    
    NSString *signStr = [NSString stringWithFormat:@"%@%@",[DataManger getInstance].systemInfo.strAppKey,[[NSString stringWithFormat:@"%f",time] substringToIndex:10]];
    [arrLoadData addObject:[self attributeWithKey:@"sign" strValue:[NnnbEncrypt md5:signStr]]];
    
    [arrLoadData addObject:[self attributeWithKey:@"gmi" strValue:[DataManger getInstance].systemInfo.strAppId]];
    [arrLoadData addObject:[self attributeWithKey:@"agi" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"sti" strValue:@""]];
    [arrLoadData addObject:[self attributeWithKey:@"srN" strValue:_dataManger.currentUserInfo.strUserName]];
    
    return [self postData:arrLoadData
                      url:PM_SWI_URL
                 userData:nil
                   target:self
            resultHandler:@selector(swiResultHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

- (void)swiResultHandler:(NSNumber*)tag
                response:(NSDictionary*)response
                userData:(id)userData
                   token:(NnnbAsyncToken*)token
{
    [token postNotification:NOTIF_WP_HTTP_TOKEN_RESULT userInfo:response];
}

#pragma mark - 账号升级
-(NnnbAsyncToken *)isRandomAccountOrNot
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"accountUp"]];
    [arrLoadData addObject:[self attributeWithKey:@"type" strValue:@"1"]];
    [arrLoadData addObject:[self attributeWithKey:@"uid" longValue:[DataManger getInstance].currentUserInfo.lUserId]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

-(NnnbAsyncToken *)getLevelUpVerifyCodeWithName:(NSString *)nameStr
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"accountUpCode"]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

-(NnnbAsyncToken *)confirmLevelUpWithName:(NSString *)nameStr Pwd:(NSString *)pwdStr Code:(NSString *)codeStr
{
    NSMutableArray *arrLoadData = [self setPublicParameters];
    
    [arrLoadData addObject:[self attributeWithKey:@"do" strValue:@"accountUp"]];
    [arrLoadData addObject:[self attributeWithKey:@"type" strValue:@"2"]];
    [arrLoadData addObject:[self attributeWithKey:@"uid" longValue:[DataManger getInstance].currentUserInfo.lUserId]];
    [arrLoadData addObject:[self attributeWithKey:@"uname" strValue:nameStr]];
    [arrLoadData addObject:[self attributeWithKey:@"pwd" strValue:pwdStr]];
    [arrLoadData addObject:[self attributeWithKey:@"phone_code" strValue:codeStr]];
    
    return [self postData:arrLoadData
                      url:GENEREL_URL
                 userData:nil
                   target:self
            resultHandler:@selector(httpTokenSuccessHandler:response:userData:token:)
             faultHandler:@selector(httpTokenFaultHandler:userData:token:)
            cancelHandler:@selector(httpTokenCancelHandler:userData:token:)];
}

#pragma mark - 采集游戏数据
- (void)collectGameData:(NSInteger)iServerID
{
    [self collectGameInfoWithServerID:iServerID];
}

#pragma mark - 数据上报统计
-(void)submitExtendData:(NSString *)strDataType roleName:(NSString *)strRoleName serverID:(NSInteger)iServerID serverName:(NSString *)strServerName roleLevel:(NSString *)strRoleLevel userID:(NSString *)strUserID roleID:(NSString*)strRoleID jinNum:(NSString *)strJinNum
{
    [self submitGameData:strDataType roleName:strRoleName serverID:iServerID serverName:strServerName roleLevel:strRoleLevel userID:strUserID roleID:strRoleID jinNum:strJinNum];
}

@end
