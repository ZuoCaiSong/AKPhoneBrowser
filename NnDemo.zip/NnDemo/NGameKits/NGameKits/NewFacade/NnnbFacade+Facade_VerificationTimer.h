//
//  NnnbFacade+Facade_VerificationTimer.h
//  
//
//  Created by kafi on 2018/5/22.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "NnnbFacade.h"

@interface NnnbFacade (Facade_VerificationTimer)

/****************************************************
 *  函数名:  verificationSetTimerPara
 *  功  能:  设置定时器参数
 *  入  参:
 *         (SEL)verificationTimerHandler   定时器的回调函数
 *         (id)obj                         那个类调用的
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)verificationSetTimerPara:(SEL)TimerHandler object:(id)obj;

/****************************************************
 *  函数名:  verificationStartTimer
 *  功  能:  验证码开始倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)verificationStartTimer;

/****************************************************
 *  函数名:  verificationStopTimer
 *  功  能:  停止验证码倒计时
 *  入  参:
 *         无
 *  出  参:
 *  		无
 *  说  明:
 ****************************************************/
- (void)verificationStopTimer;

@end
