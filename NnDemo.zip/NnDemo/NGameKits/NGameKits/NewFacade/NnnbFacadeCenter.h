//
//  NnnbFacadeCenter.h
//

#import <Foundation/Foundation.h>
#import "DataDefine.h"

@interface NnnbFacadeCenter : NSObject

+ (instancetype)defaultFacade;

- (void)getVersionRequest:(void (^)(BOOL success,NSNotification *notifi))callBlock;
- (void)getConfig:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 verifyAccount

 @param callBlock callBlock 
 */
- (void)verifyAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 一键注册

 @param callBlock callBlock
 */
- (void)fastRegistWithAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 注册账号
 @param account account
 @param psd psd
 @param callBlock callBlock
 */
- (void)registWithAccount:(NSString *)account
                   andPsd:(NSString *)psd
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 账号登录
 @param userName 账号
 @param password userName
 @param callBlock password
 */
- (void)loginWithName:(NSString*)userName
             password:(NSString*)password
               result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 获取注册账号

 @param callBlock callBlock
 */
- (void)getRegistAccount:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 手机登录获取验证码

 @param phone phone
 @param callBlock callBlock
 */
- (void)getPhoneCodeForPhoneLogin:(NSString *)phone
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 手机登录

 @param phone phone
 @param code code
 @param callBlock callBlock
 */
- (void)phoneloginNumber:(NSString *)phone
             messageCode:(NSString *)code
                  result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 绑定手机

 @param phone phone
 @param code code
 @param callBlock callBlock
 */
- (void)bindPhone:(NSString *)phone
      messageCode:(NSString *)code
           result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 绑定手机，获取验证码

 @param userName userName
 @param phone phone
 @param callBlock callBlock
 */
- (void)getPhoneCodeForUserBind:(NSString *)userName
                      phone:(NSString *)phone
                     result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 重置密码，获取手机验证码

 @param account account
 @param phone phone
 @param callBlock callBlock
 */
- (void)getPhoneCodeForUserForgetPsd:(NSString *)account
                               phone:(NSString *)phone
                               esult:(void (^)(BOOL success,NSNotification *notifi))callBlock;


/**
 重置密码，验证账号

 @param msgCode msgCode
 @param account account
 @param phone phone
 @param callBlock callBlock
 */
- (void)confirmVerifyCode:(NSString *)msgCode
                  account:(NSString *)account
                    phone:(NSString *)phone
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 重置密码

 @param phone phone
 @param account account
 @param code code
 @param psd psd
 @param callBlock callBlock 
 */
- (void)resetPassword:(NSString *)phone
               account:(NSString *)account
           messageCode:(NSString *)code
                andPsd:(NSString *)psd
                result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 修改密码
 
 @param oldPsd oldPsd
 @param xinPsd xinPsd
 @param callBlock callBlock
 */
- (void)changeOldPsd:(NSString *)oldPsd
           andXinPsd:(NSString *)xinPsd
              result:(void (^)(BOOL success,NSNotification *notifi))callBlock;
/**
 实名认证

 @param realName realName
 @param personId personId
 @param callBlock callBlock
 */
- (void)checkPersonWithRealName:(NSString *)realName
                       personId:(NSString *)personId
                         result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;


/**
 PublicNot

 @param callBlock callBlock 
 */
- (void)getPublicNotDataWithType:(NSInteger)notType
                          result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 已读

 @param pubNotId pubNotId
 @param callBlock callBlock
 */
- (void)haveReadPublicNot:(NSInteger)pubNotId
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

/**
 list data
 @param callBlock callBlock
 */
- (void)getPackageListData:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 理煲码

 @param codeType codeType
 @param hdstr hdstr 
 @param callBlock callBlock
 */
- (void)getPageageCode:(NSInteger)codeType
                 hdStr:(NSString *)hdstr
                result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 获取...

 @param dateStr dateStr
 @param callBlock callBlock 
 */
- (void)getTopUpRecordWithDateStr:(NSString *)dateStr
                           result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 删除

 @param recordId recordId 
 @param callBlock callBlock
 */
- (void)deleteTopUpRecord:(NSString *)recordId
                   result:(void (^)(BOOL success,NSNotification *notifi))callBlock ;

/**
 Account level Up for verifyCode

 @param account account
 @param callBlock callBlock 
 */
- (void)getPhoneCodeForAccountLevelUp:(NSString *)account
                               result:(void (^)(BOOL success,NSNotification *notifi))callBlock;


/**
 confirmAccountLevelUp

 @param account account
 @param psd psd
 @param code code
 @param callBlock callBlock 
 */
- (void)confirmAccountLevelUp:(NSString *)account
                       andPsd:(NSString *)psd
                  messageCode:(NSString *)code
                       result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

- (void)dingOrdFuby:(ChValueType)type
               bill:(double)iBill
            subject:(CGFloat)fSubject
             result:(void (^)(BOOL success,NSNotification *notifi))callBlock;

#pragma mark - IAP
- (void)downOrd:(void (^)(BOOL success,NSNotification *notifi))callBlock;

@end
