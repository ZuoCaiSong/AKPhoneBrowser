//
//  TopUpViewController.m
//  NnDemo
//
//  Created by kafi on 2018/5/23.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "TopUpViewController.h"
#import "NnGameKit.h"
#import "NnNotifDefine.h"

@interface TopUpViewController ()

@end

@implementation TopUpViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor= [UIColor lightGrayColor];
    
    //登录游戏日志记录
    UIButton* collectBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    collectBtn.backgroundColor = [UIColor whiteColor];
    [collectBtn setTitle:@"登陆游戏日志记录" forState:UIControlStateNormal];
    [collectBtn addTarget:self action:@selector(collectClick:) forControlEvents:UIControlEventTouchUpInside];
    collectBtn.frame = CGRectMake(10, 5, 140, 44);
    collectBtn.tag = 102;
    [self.view addSubview:collectBtn];
    
    //创建角色
    UIButton* submitBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    submitBtn.backgroundColor = [UIColor whiteColor];
    [submitBtn setTitle:@"创建角色" forState:UIControlStateNormal];
    [submitBtn addTarget:self action:@selector(subitDataClick:) forControlEvents:UIControlEventTouchUpInside];
    submitBtn.frame = CGRectMake(10, 160, 100, 44);
    [self.view addSubview:submitBtn];
    
    //6元
    UIButton* vitualBtn6 = [UIButton buttonWithType:UIButtonTypeSystem];
    vitualBtn6.backgroundColor = [UIColor whiteColor];
    [vitualBtn6 setTitle:@"6元" forState:UIControlStateNormal];
    [vitualBtn6 addTarget:self action:@selector(chargeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    vitualBtn6.frame = CGRectMake(10, self.view.frame.size.height - 60, 60, 44);
    vitualBtn6.tag = 1;
    [self.view addSubview:vitualBtn6];
    
    //30元
    UIButton* vitualBtn30 = [UIButton buttonWithType:UIButtonTypeSystem];
    vitualBtn30.backgroundColor = [UIColor whiteColor];
    [vitualBtn30 setTitle:@"30元" forState:UIControlStateNormal];
    [vitualBtn30 addTarget:self action:@selector(chargeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    vitualBtn30.frame = CGRectMake(10 * 2 + 60 * 1, self.view.frame.size.height - 60, 60, 44);
    vitualBtn30.tag = 30;
    [self.view addSubview:vitualBtn30];
    
    //50元
    UIButton* vitualBtn50 = [UIButton buttonWithType:UIButtonTypeSystem];
    vitualBtn50.backgroundColor = [UIColor whiteColor];
    [vitualBtn50 setTitle:@"50元" forState:UIControlStateNormal];
    [vitualBtn50 addTarget:self action:@selector(chargeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    vitualBtn50.frame = CGRectMake(10 * 3 + 60 * 2, self.view.frame.size.height - 60, 60, 44);
    vitualBtn50.tag = 50;
    [self.view addSubview:vitualBtn50];
    
    //98元
    UIButton* vitualBtn98 = [UIButton buttonWithType:UIButtonTypeSystem];
    vitualBtn98.backgroundColor = [UIColor whiteColor];
    [vitualBtn98 setTitle:@"98元" forState:UIControlStateNormal];
    [vitualBtn98 addTarget:self action:@selector(chargeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    vitualBtn98.frame = CGRectMake(10 * 4 + 60 * 3, self.view.frame.size.height - 60, 60, 44);
    vitualBtn98.tag = 98;
    [self.view addSubview:vitualBtn98];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(jiaoyiResult:)
                                                name:NN_NOTIF_APPLE
                                              object:nil];
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(loginOutSuccess:)
                                                name:NN_NOTIF_LOGOUT_SUCCESS
                                              object:nil];
}

//绑定手机号
- (void)bindClick:(id)sender{
    
    [[NnGameKit GetInstance] bindPhone];
}

//登陆游戏日志记录
- (void)collectClick:(id)sender
{
    [[NnGameKit GetInstance] submitServerID:1];
}

- (void)subitDataClick:(id)sender
{
    /**
     说明：
     [[NnGameKit GetInstance] submitExtendData:@"统计类型" roleName:@"角色名字" serverID:1 serverName:@"服务器名字" roleLevel:@"角色等级" userID:@"分配的用户id" roleID:@"角色id" jinNum:@"当前角色身上拥有的游戏币数量"];
     */
    
    [[NnGameKit GetInstance] submitExtendData:@"2" roleName:@"独孤求败" serverID:1 serverName:@"黑暗之矛" roleLevel:@"11" userID:@"100000" roleID:@"123456789" jinNum:@"100"];
}

- (void)loginOutSuccess:(NSNotification *)notif
{
    [self.navigationController popViewControllerAnimated:YES];
    NSLog(@"123");
}

- (void)chargeBtnClick:(id)sender
{
    if (sender == nil)
    {
        return;
    }
    
    NSInteger tag = [sender tag];
    
    //strExtraInfo 为自定义数据，长度小于100字符，这个数据前后两次发送的一定不能相同，数据会原样从我们服务器返回给游戏服务器
    NSString *productId = [NSString stringWithFormat:@"com.cqjxtw.AppStore_%ld",(long)tag*10];
    
    [[NnGameKit GetInstance] AppleIap:[self getOutTradeNo] jin:tag serverID:123456789 serverName:@"游戏82区-行云流水" roleName:@"皇甫武神" roleID:@"123456789" productId:productId productName:[NSString stringWithFormat:@"%ld元宝",(long)tag*10] productDes:[NSString stringWithFormat:@"%ld元宝",(long)tag*10]];
}

-(void)jiaoyiResult:(NSNotification*)notif
{
    NSString *state = [[notif userInfo] objectForKey:@"stateFlag"];
    if ([state isEqualToString: @"1"]) {
        NSLog(@"成功!");
    }else{
        NSLog(@"失败!");
    }
}


- (NSString*)getOutTradeNo
{
    NSDate *  senddate=[NSDate date];
    NSDateFormatter  *dateformatter=[[NSDateFormatter alloc] init];
    [dateformatter setDateFormat:@"YYYYMMddhhmmssSS"];
    NSString *  strCustomInfo=[dateformatter stringFromDate:senddate];
    NSLog(@"locationString:%@",strCustomInfo);
    return strCustomInfo;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
