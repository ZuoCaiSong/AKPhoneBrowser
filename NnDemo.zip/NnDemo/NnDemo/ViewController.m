//
//  ViewController.m
//  NnDemo
//
//  Created by kafi on 2018/5/23.
//  Copyright © 2018年 kafi. All rights reserved.
//

#import "ViewController.h"
#import "NnGameKit.h"
#import "NnNotifDefine.h"
#import "TopUpViewController.h"

/*
 *分配的参数：appid
 *分配的参数：appkey
 */
#define  GAME_APPID       (@"1")
#define  GAME_APPKEY      (@"yWpx3hWQHFhSnTCj#1#6KuRKuaAjLJ5sYRy")

@interface ViewController ()

@end

@implementation ViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor= [UIColor lightGrayColor];
    
    if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)])
    {
        // iOS 7
        [self prefersStatusBarHidden];
        [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
    }
    
    UIButton* loginBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    loginBtn.backgroundColor = [UIColor whiteColor];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn addTarget:self action:@selector(loginClick:) forControlEvents:UIControlEventTouchUpInside];
    
    loginBtn.center = self.view.center;
    loginBtn.bounds = CGRectMake(0, 0, 100, 44);
    [self.view addSubview:loginBtn];
    
    //监听
    //登陆成功消息
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(loginSuccess:)
                                                name:NN_NOTIF_LOGIN_SUCCESS
                                              object:nil];
    
    //初始化完成
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(initSuccess:)
                                                name:NN_NOTIF_INIT_SUCCESS
                                              object:nil];
    
    //注销成功消息
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(loginOutSuccess:)
                                                name:NN_NOTIF_LOGOUT_SUCCESS
                                              object:nil];
    
    //监听注册成功和失败消息
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(registerSuccess:)
                                                name:NN_NOTIF_REGISTER_SUCCESS
                                              object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(registerFail:)
                                                name:NN_NOTIF_REGISTER_FAIL
                                              object:nil];
    
    [[NnGameKit GetInstance] Init:GAME_APPID Appkey:GAME_APPKEY];
}

//进入登陆界面
-(void)loginClick:(id)sender
{
    [[NnGameKit GetInstance] login];
}

-(void)entryChargeCenter
{
    TopUpViewController *controller = [[TopUpViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

//登陆成功
-(void)loginSuccess:(NSNotification*)notif
{
    NSDictionary *dic = [notif userInfo];
    NSLog(@"%@",dic);
    NSString* strUserId = [dic objectForKey:KEY_USER_ID];
    NSString* strSessionId = [dic objectForKey:KEY_LOGIN_SIGN];
    
    NSString* strTips =[NSString stringWithFormat:@"登录成功\nuid:%@\nsignKey:%@",strUserId,strSessionId];
    
    UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:@"提示"
                                                       message:strTips
                                                      delegate:self
                                             cancelButtonTitle:@"知道了"
                                             otherButtonTitles:nil];
    [alertView show];
    
    [self performSelector:@selector(entryChargeCenter) withObject:nil afterDelay:0.2];
}

//初始化成功，可使用登陆，无需提示用户
-(void)initSuccess:(NSNotification*)notif
{
    NSLog(@"初始化成功");
}

//注销成功后，需要重启游戏或者退出游戏
-(void)loginOutSuccess:(NSNotification*)notif
{
    NSLog(@"注销成功");
}

//注册成功
-(void)registerSuccess:(NSNotification*)notif
{
    NSDictionary *dic = [notif userInfo];
    NSLog(@"%@",dic);
    NSString* strUserId = [dic objectForKey:KEY_USER_ID];
    NSString* strSessionId = [dic objectForKey:KEY_LOGIN_SIGN];
    NSLog(@"%@%@",strUserId, strSessionId);
    NSLog(@"注册成功");
}

//注册失败
-(void)registerFail:(NSNotification*)notif
{
    NSLog(@"注册失败");
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
